-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2026 at 07:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `armful_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `user_name`, `action`, `details`, `description`, `ip_address`, `created_at`) VALUES
(1, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 19:38:51'),
(2, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 19:40:06'),
(3, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 19:40:52'),
(4, 3, 'Edrian Faderon', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 19:41:01'),
(5, 3, 'Edrian Faderon', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 19:41:10'),
(6, 3, 'Edrian Faderon', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 19:41:18'),
(7, 3, 'Edrian Faderon', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 19:41:40'),
(8, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 19:41:49'),
(9, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 19:42:44'),
(10, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 19:42:47'),
(11, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 19:57:59'),
(12, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 19:58:07'),
(13, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 20:07:47'),
(14, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 20:07:50'),
(15, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 20:37:16'),
(16, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 20:37:20'),
(17, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 20:40:03'),
(18, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 20:40:10'),
(19, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 20:47:56'),
(20, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 20:48:00'),
(21, 4, 'Benedict', 'Add Instagram Influencer', 'Added new Instagram influencer: Edrian', NULL, '::1', '2026-01-27 20:52:14'),
(22, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 20:56:28'),
(23, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 20:56:32'),
(24, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 20:56:54'),
(25, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 20:56:59'),
(26, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 14', NULL, '::1', '2026-01-27 22:09:53'),
(27, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Not Qualified\' for influencer ID: 14', NULL, '::1', '2026-01-27 22:10:06'),
(28, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 14', NULL, '::1', '2026-01-27 22:11:37'),
(29, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Not Qualified\' for influencer ID: 14', NULL, '::1', '2026-01-27 22:11:48'),
(30, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 14', NULL, '::1', '2026-01-27 22:12:01'),
(31, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 22:23:26'),
(32, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 22:23:31'),
(33, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 22:51:00'),
(34, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 22:51:32'),
(35, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 22:51:55'),
(36, 5, 'Edrian Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 22:52:05'),
(37, 5, 'Edrian Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 22:52:31'),
(38, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 22:52:34'),
(39, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 22:53:34'),
(40, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 22:53:40'),
(41, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 14', NULL, '::1', '2026-01-27 23:06:20'),
(42, 5, 'Edrian Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:08:19'),
(43, 5, 'Edrian Benedict', 'Bulk Delete', 'Deleted 1 influencers via bulk action', NULL, '::1', '2026-01-27 23:09:36'),
(44, 5, 'Edrian Benedict', 'Add Instagram Influencer', 'Added new Instagram influencer: _superedrian', NULL, '::1', '2026-01-27 23:10:35'),
(45, 5, 'Edrian Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 15', NULL, '::1', '2026-01-27 23:10:40'),
(46, 5, 'Edrian Benedict', 'Add Instagram Influencer', 'Added new Instagram influencer: lifeofayemami', NULL, '::1', '2026-01-27 23:12:00'),
(47, 5, 'Edrian Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 16', NULL, '::1', '2026-01-27 23:12:08'),
(48, 5, 'Edrian Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:13:26'),
(49, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:13:38'),
(50, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:14:39'),
(51, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:16:01'),
(52, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:16:10'),
(53, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:16:35'),
(54, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:20:56'),
(55, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:21:12'),
(56, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:22:49'),
(57, 6, 'Manager', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:23:02'),
(58, 6, 'Manager', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:27:27'),
(59, 6, 'Manager', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:27:49'),
(60, 6, 'Manager', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:33:14'),
(61, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:33:23'),
(62, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-27 23:49:37'),
(63, 6, 'Manager', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-27 23:49:51'),
(64, 6, 'Manager', 'Logout', 'User logged out.', NULL, '::1', '2026-01-28 00:03:24'),
(65, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-28 00:03:38'),
(66, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 17', NULL, '::1', '2026-01-28 01:31:57'),
(67, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 18', NULL, '::1', '2026-01-28 01:32:42'),
(68, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Not Qualified\' for influencer ID: 18', NULL, '::1', '2026-01-28 01:32:50'),
(69, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 18', NULL, '::1', '2026-01-28 01:32:59'),
(70, 4, 'Benedict', 'Delete Influencer', 'Deleted influencer: Panlasang Pinoy (ID: 19)', NULL, '::1', '2026-01-28 02:15:51'),
(71, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 18', NULL, '::1', '2026-01-28 02:28:05'),
(72, 4, 'Benedict', 'Bulk Delete', 'Deleted 4 influencers via bulk action', NULL, '::1', '2026-01-28 02:52:36'),
(73, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 21', NULL, '::1', '2026-01-28 02:54:19'),
(74, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-28 16:38:25'),
(75, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-28 20:17:51'),
(76, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 23', NULL, '::1', '2026-01-28 20:18:53'),
(77, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-28 20:43:09'),
(78, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-29 00:42:26'),
(79, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-29 17:05:08'),
(80, 4, 'Benedict', 'Bulk Delete', 'Deleted 7 influencers via bulk action', NULL, '::1', '2026-01-29 17:19:55'),
(81, 4, 'Benedict', 'Update Detail', 'Updated details for influencer ID: 27', NULL, '::1', '2026-01-29 17:36:18'),
(82, 4, 'Benedict', 'Edit Influencer', 'Edited influencer (Manual): Papa Shoutout ()', NULL, '::1', '2026-01-29 18:50:21'),
(83, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 29', NULL, '::1', '2026-01-29 18:50:25'),
(84, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Not Qualified\' for influencer ID: 30', NULL, '::1', '2026-01-29 19:25:02'),
(85, 4, 'Benedict', 'Bulk Delete', 'Deleted 4 influencers via bulk action', NULL, '::1', '2026-01-29 19:33:11'),
(86, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Not Qualified\' for influencer ID: 31', NULL, '::1', '2026-01-29 19:40:32'),
(87, 4, 'Benedict', 'Bulk Delete', 'Deleted 1 influencers via bulk action', NULL, '::1', '2026-01-29 19:40:48'),
(88, 4, 'Benedict', 'Logout', 'User logged out.', NULL, '::1', '2026-01-29 21:51:01'),
(89, 1, 'admin', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-29 21:51:05'),
(90, 1, 'admin', 'Logout', 'User logged out.', NULL, '::1', '2026-01-29 21:52:49'),
(91, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-29 22:04:52'),
(92, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Qualified\' for influencer ID: 32', NULL, '::1', '2026-01-29 22:56:57'),
(93, 4, 'Benedict', 'Update Detail', 'Updated details for influencer ID: 32', NULL, '::1', '2026-01-29 23:24:03'),
(94, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-29 23:35:06'),
(95, 4, 'Benedict', 'Update Assessment', 'Updated assessment to \'Not Qualified\' for influencer ID: 34', NULL, '::1', '2026-01-29 23:48:06'),
(96, 4, 'Benedict', 'Bulk Delete', 'Deleted 1 influencers via bulk action', NULL, '::1', '2026-01-30 00:13:12'),
(97, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-30 02:55:33'),
(98, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-30 06:21:28'),
(99, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-30 17:23:53'),
(100, 4, 'Benedict', 'Login', 'User logged in successfully.', NULL, '::1', '2026-01-31 17:07:49');

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `id` int(11) NOT NULL,
  `goals` text DEFAULT NULL,
  `sales_target` decimal(10,2) DEFAULT NULL,
  `conversion_rate` decimal(5,2) DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `status` enum('draft','active','completed') DEFAULT 'draft',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`id`, `goals`, `sales_target`, `conversion_rate`, `budget`, `status`, `created_by`, `created_at`) VALUES
(1, 'matapos na ito ', 1.00, 1.00, 1000.00, 'active', 6, '2026-01-28 06:58:40');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_assignments`
--

CREATE TABLE `campaign_assignments` (
  `id` int(11) NOT NULL,
  `campaign_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `campaign_assignments`
--

INSERT INTO `campaign_assignments` (`id`, `campaign_id`, `user_id`, `assigned_at`) VALUES
(1, 1, 4, '2026-01-28 06:58:40');

-- --------------------------------------------------------

--
-- Table structure for table `collaborations`
--

CREATE TABLE `collaborations` (
  `id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `pipeline_status` varchar(100) DEFAULT 'For Outreach',
  `campaign_type` varchar(100) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `order_number` varchar(100) DEFAULT NULL,
  `product_cost` decimal(10,2) DEFAULT NULL,
  `discount_code` varchar(100) DEFAULT NULL,
  `affiliate_link` varchar(255) DEFAULT NULL,
  `tracking_link` varchar(255) DEFAULT NULL,
  `assessment` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `collaborations`
--

INSERT INTO `collaborations` (`id`, `profile_id`, `account_id`, `pipeline_status`, `campaign_type`, `product_name`, `order_number`, `product_cost`, `discount_code`, `affiliate_link`, `tracking_link`, `assessment`, `created_at`) VALUES
(32, 29, 11, 'Delivered', 'Gifting', '', '', NULL, '', '', '', 'Qualified', '2026-01-30 03:41:13'),
(33, 30, 28, '', '', '', '', NULL, '', '', '', '', '2026-01-30 07:42:46'),
(34, 31, 29, '', '', '', '', NULL, '', '', '', 'Not Qualified', '2026-01-30 07:47:37');

-- --------------------------------------------------------

--
-- Table structure for table `email_conversations`
--

CREATE TABLE `email_conversations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `influencer_id` int(11) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `direction` enum('inbound','outbound') NOT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `email_conversations`
--

INSERT INTO `email_conversations` (`id`, `user_id`, `influencer_id`, `sender_email`, `recipient_email`, `subject`, `body`, `direction`, `message_id`, `is_read`, `created_at`) VALUES
(1, 1, 12, 'zdanica439@gmail.com', 'me@instroom.com', 'Dummy Inquiry #2098', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccf9c961', 1, '2026-01-27 04:11:11'),
(2, 1, 10, 'ezyarandia@gmail.com', 'me@instroom.com', 'Dummy Inquiry #4924', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccf9dc84', 1, '2026-01-27 04:11:11'),
(3, 1, 10, 'ezyarandia@gmail.com', 'me@instroom.com', 'Dummy Inquiry #7581', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccf9f1db', 1, '2026-01-27 04:11:11'),
(4, 1, 10, 'ezyarandia@gmail.com', 'me@instroom.com', 'Dummy Inquiry #7038', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccfa0faa', 1, '2026-01-27 04:11:11'),
(5, 1, 9, 'hardenfaderon@gmail.com', 'me@instroom.com', 'Dummy Inquiry #3143', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccfa30be', 0, '2026-01-27 04:11:11'),
(6, 1, 9, 'hardenfaderon@gmail.com', 'me@instroom.com', 'Dummy Inquiry #8472', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccfa427e', 0, '2026-01-27 04:11:11'),
(7, 1, 9, 'hardenfaderon@gmail.com', 'me@instroom.com', 'Dummy Inquiry #3518', '<p>This is a dummy unread email for testing notifications.</p>', 'inbound', 'dummy-69782ccfa54c3', 0, '2026-01-27 04:11:11'),
(8, 3, 13, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', 'oy', 'pre', 'outbound', NULL, 1, '2026-01-27 04:19:19'),
(9, 3, 1, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', 'Re: oy', '<div dir=\"ltr\"><div dir=\"ltr\">bakit??</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\"><br></div></div></div>\r\n', 'inbound', '<CAK6riDVCkXU-dLRMcPNJjcSqxWiz9Aqcqhxn_xaNVrJfXzebZw@mail.gmail.com>', 0, '2026-01-27 04:19:49'),
(10, 3, 13, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', 'Following up: Collaboration Opportunity', 'Hi Edrian,\r\n\r\nI just wanted to bump this to the top of your inbox in case you missed my previous email.\r\n\r\nWe\'re still very interested in working with you and would love to discuss a potential collaboration.\r\n\r\nLooking forward to hearing from you!\r\n\r\nBest,\r\n[Your Name]', 'outbound', NULL, 1, '2026-01-27 04:24:51'),
(11, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: Following up: Collaboration Opportunity', '<div dir=\"ltr\">okay<div><br></div></div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 11:24 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">Hi Edrian,\r\n\r\nI just wanted to bump this to the top of your inbox in case you missed my previous email.\r\n\r\nWe&#39;re still very interested in working with you and would love to discuss a potential collaboration.\r\n\r\nLooking forward to hearing from you!\r\n\r\nBest,\r\n[Your Name]\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDVLoxEe3-hTJNom+YVXdOuOF4LuhojPvW_TSvMp0EBgUQ@mail.gmail.com>', 1, '2026-01-27 04:25:15'),
(12, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Following up: Collaboration Opportunity', 'Hi Edrian,\n\nI just wanted to bump this to the top of your inbox in case you missed my previous email.\n\nWe\'re still very interested in working with you and would love to discuss a potential collaboration.\n\nLooking forward to hearing from you!\n\nBest,\n[Your Name]\r\n', 'inbound', '<69782ffeb73a6@gmail.com>', 1, '2026-01-27 04:24:46'),
(13, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'oy', 'pre\r\n', 'inbound', '<69782eb2a68c2@gmail.com>', 1, '2026-01-27 04:19:14'),
(14, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: pre', '<div dir=\"ltr\">oo nga</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 10:56 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">pre system ko to\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDVOL_AGwckqo=VPu6x9_mvkamvdrsEZ1AvwEseq=g+avQ@mail.gmail.com>', 1, '2026-01-27 03:57:22'),
(15, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'pre', 'pre system ko to\r\n', 'inbound', '<69782975df51c@gmail.com>', 1, '2026-01-27 03:56:53'),
(16, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: pre', '<div dir=\"ltr\"><div dir=\"ltr\">sa ilaya ako </div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\"><br></div></div></div>\r\n', 'inbound', '<CAK6riDUSgxroUAfuMNZ4cp-1bs2-kGGoqBiZv8s+QCnVDXmAvA@mail.gmail.com>', 1, '2026-01-27 03:11:04'),
(17, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'pre ', 'pre tagasan ka\r\n', 'inbound', '<69781e9c818f3@gmail.com>', 1, '2026-01-27 03:10:36'),
(18, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: bakit', '<div dir=\"ltr\"><div dir=\"ltr\">wala lang hinahanap lang kita <div><br></div></div><br></div>\r\n', 'inbound', '<CAK6riDVmhc1BHNOZODMXa3AO6Ns-QCvVrkqg05kKFFo50U5mvw@mail.gmail.com>', 1, '2026-01-27 03:07:18'),
(19, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'bakit ', 'bakit pre mo natanong\r\n', 'inbound', '<69781db7c17ef@gmail.com>', 1, '2026-01-27 03:06:47'),
(20, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: edrian', '<div dir=\"ltr\">sa sitc ako</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 10:05 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">pre nasan ka\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDWEGm0_0bb191-OGY-UokhM+sF31g-0PNUQdAQj83VnBA@mail.gmail.com>', 1, '2026-01-27 03:05:41'),
(21, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'edrian', 'pre nasan ka\r\n', 'inbound', '<69781d5e54e10@gmail.com>', 1, '2026-01-27 03:05:18'),
(22, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: fads', '<div dir=\"ltr\">bakit pre</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 10:01 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">pre pre\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDVKFL-2zHNT3m_45TgNLw+QYxyGMMJ-nktNw9-0Wv7ngw@mail.gmail.com>', 1, '2026-01-27 03:02:48'),
(23, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'fads', 'pre pre\r\n', 'inbound', '<69781c8bdd044@gmail.com>', 1, '2026-01-27 03:01:47'),
(24, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'hello', 'hello pre\r\n', 'inbound', '<69781c7a0758e@gmail.com>', 1, '2026-01-27 03:01:30'),
(25, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: fads', '<div dir=\"ltr\">dito sa SITC</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 9:59 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">fads san ka galing\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDVwWXLW6sGz=8_iCMWmKPwexWcY+kYaJbZUXmMSi1qrNA@mail.gmail.com>', 1, '2026-01-27 02:59:37'),
(26, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'fads', 'fads san ka galing\r\n', 'inbound', '<69781bf42d373@gmail.com>', 1, '2026-01-27 02:59:16'),
(27, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: ezekiel', '<div dir=\"ltr\">oy reply na </div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 9:49 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">dapat daw nakaka reply ha\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDWOCAdqMjKLg6mfYR9=+ooZZR+ojGuo1Bq5pWZkoQMfnQ@mail.gmail.com>', 1, '2026-01-27 02:49:50'),
(28, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'ezekiel', 'dapat daw nakaka reply ha\r\n', 'inbound', '<6978199b0e272@gmail.com>', 1, '2026-01-27 02:49:15'),
(29, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: oy', '<div dir=\"ltr\">hi too</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 9:36 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">si fads\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDWnSguxHZpbKkFWUWs1qNUtvLu-cB6GRBpMeWMjn12YjA@mail.gmail.com>', 1, '2026-01-27 02:36:57'),
(30, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'oy', 'si fads\r\n', 'inbound', '<6978169068229@gmail.com>', 1, '2026-01-27 02:36:16'),
(31, 3, 13, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', 'Thank you for the amazing content!', 'Hi Edrian,\r\n\r\nWe just saw your post and we love it! Thank you so much for the amazing content.\r\n\r\nWe\'d love to work with you again in the future.\r\n\r\nBest,\r\n[Your Name]', 'outbound', NULL, 1, '2026-01-27 04:27:41'),
(32, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: Thank you for the amazing content!', '<div dir=\"ltr\">k</div><br><div class=\"gmail_quote gmail_quote_container\"><div dir=\"ltr\" class=\"gmail_attr\">On Tue, Jan 27, 2026 at 11:27 AM Instroom System &lt;<a href=\"mailto:hardenfaderon@gmail.com\">hardenfaderon@gmail.com</a>&gt; wrote:<br></div><blockquote class=\"gmail_quote\" style=\"margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex\">Hi Edrian,\r\n\r\nWe just saw your post and we love it! Thank you so much for the amazing content.\r\n\r\nWe&#39;d love to work with you again in the future.\r\n\r\nBest,\r\n[Your Name]\r\n</blockquote></div>\r\n', 'inbound', '<CAK6riDW-fJUOuU5ADsNf8YSctEDEOVpCZsMPCz2kRkGXw28+9g@mail.gmail.com>', 1, '2026-01-27 04:28:07'),
(33, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Thank you for the amazing content!', 'Hi Edrian,\n\nWe just saw your post and we love it! Thank you so much for the amazing content.\n\nWe\'d love to work with you again in the future.\n\nBest,\n[Your Name]\r\n', 'inbound', '<697830adefbfd@gmail.com>', 1, '2026-01-27 04:27:41'),
(34, 3, 13, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', '.', '.', 'outbound', NULL, 1, '2026-01-27 04:29:13'),
(35, 3, 1, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', '.', '.\r\n', 'inbound', '<697831096f0bc@gmail.com>', 0, '2026-01-27 04:29:13'),
(36, 3, 13, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', 'Thank you for the amazing content!', 'Hi Edrian,\r\n\r\nWe just saw your post and we love it! Thank you so much for the amazing content.\r\n\r\nWe\'d love to work with you again in the future.\r\n\r\nBest,\r\n[Your Name]', 'outbound', NULL, 1, '2026-01-27 04:33:47'),
(37, 3, 13, '\"FADERON EDRIAN F.\" <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Re: Thank you for the amazing content!', '<div dir=\"ltr\"><div dir=\"ltr\"><br></div><br><div class=\"gmail_quote gmail_quote_container\"><div class=\"gmail_attr\">okay</div><div class=\"gmail_attr\"><br></div></div></div>\r\n', 'inbound', '<CAK6riDXEuLbC8Quqv2iD1GZe2G-4D02ZRBBT-sD_rZ9FjJhBhQ@mail.gmail.com>', 1, '2026-01-27 04:34:13'),
(38, 3, 13, 'Instroom System <hardenfaderon@gmail.com>', 'hardenfaderon@gmail.com', 'Thank you for the amazing content!', 'Hi Edrian,\n\nWe just saw your post and we love it! Thank you so much for the amazing content.\n\nWe\'d love to work with you again in the future.\n\nBest,\n[Your Name]\r\n', 'inbound', '<6978321b186f8@gmail.com>', 1, '2026-01-27 04:33:47'),
(39, 4, 27, 'hardenfaderon@gmail.com', 'hardenfaderon@gmail.com', 'Thank you for the amazing content!', 'Hi _superedrian,\r\n\r\nWe just saw your post and we love it! Thank you so much for the amazing content.\r\n\r\nWe\'d love to work with you again in the future.\r\n\r\nBest,\r\n[Your Name]', 'outbound', NULL, 1, '2026-01-30 01:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `influencers`
--

CREATE TABLE `influencers` (
  `id` int(11) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `ig_username` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_info` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `niche` varchar(100) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `followers` int(11) DEFAULT 0,
  `eng_rate` float DEFAULT 0,
  `avg_video_views` int(11) DEFAULT 0,
  `gmv` decimal(10,2) DEFAULT 0.00,
  `est_post_rate` decimal(10,2) DEFAULT 0.00,
  `status` varchar(50) DEFAULT 'For Outreach',
  `pipeline_status` varchar(100) DEFAULT 'For Outreach',
  `campaign_type` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `order_number` varchar(100) DEFAULT NULL,
  `product_cost` decimal(10,2) DEFAULT NULL,
  `discount_code` varchar(100) DEFAULT NULL,
  `affiliate_link` varchar(255) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `tracking_link` varchar(255) DEFAULT NULL,
  `assessment` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `influencers`
--

INSERT INTO `influencers` (`id`, `platform`, `ig_username`, `username`, `full_name`, `first_name`, `last_name`, `contact_number`, `email`, `contact_info`, `location`, `niche`, `profile_image`, `followers`, `eng_rate`, `avg_video_views`, `gmv`, `est_post_rate`, `status`, `pipeline_status`, `campaign_type`, `notes`, `product_name`, `order_number`, `product_cost`, `discount_code`, `affiliate_link`, `shipping_address`, `tracking_link`, `assessment`, `created_by`, `created_at`) VALUES
(10, NULL, NULL, '', 'edrian faderon', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Active', 'For Order Creation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-25 08:35:49'),
(11, NULL, NULL, '', 'edrian faderon', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Active', 'For Order Creation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-25 09:05:59'),
(12, 'Instagram', NULL, 'edrian', 'edrian faderon', NULL, NULL, NULL, 'edrianfaderon@yahoo.com', NULL, 'ilaya', 'Fashion', NULL, 100000, 12, 0, 0.00, 0.00, 'Active', 'For Order Creation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Qualified', NULL, '2026-01-25 09:09:56'),
(13, 'Instagram', NULL, 'danica', 'danica', NULL, NULL, NULL, 'danicazamora@gmail.com', NULL, 'Tawiran', 'Tech', NULL, 100000, 12, 0, 0.00, 0.00, 'Active', 'Campaign Completed', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Qualified', NULL, '2026-01-26 03:03:31'),
(14, 'youtube', NULL, 'skincare_317', 'SkinCare Creator 1', NULL, NULL, NULL, NULL, NULL, NULL, 'SkinCare', 'https://ui-avatars.com/api/?name=skincare_317&background=random', 1132843, 0, 0, 0.00, 0.00, 'For Outreach', 'For Outreach', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '2026-01-28 09:30:18');

-- --------------------------------------------------------

--
-- Table structure for table `influencer_accounts`
--

CREATE TABLE `influencer_accounts` (
  `id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `niche` varchar(100) DEFAULT NULL,
  `followers` int(11) DEFAULT 0,
  `eng_rate` float DEFAULT 0,
  `avg_video_views` int(11) DEFAULT 0,
  `gmv` decimal(10,2) DEFAULT 0.00,
  `est_post_rate` decimal(10,2) DEFAULT 0.00,
  `status` varchar(50) DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `influencer_accounts`
--

INSERT INTO `influencer_accounts` (`id`, `profile_id`, `platform`, `username`, `profile_image`, `niche`, `followers`, `eng_rate`, `avg_video_views`, `gmv`, `est_post_rate`, `status`) VALUES
(1, 1, 'Instagram', 'edrian', '', 'Fashion', 100000, 12, 0, 0.00, 0.00, 'Active'),
(2, 2, 'Instagram', 'Danica', '', 'Fashion', 1300, 1, 0, 0.00, 0.00, 'Active'),
(3, 3, 'Instagram', 'kingkong', '', 'Fashion', 1230, 12, 0, 0.00, 0.00, 'Active'),
(4, 4, 'Instagram', 'bide', '', 'Travel', 200, 1, 0, 0.00, 0.00, 'Active'),
(5, 5, 'Instagram', 'edriano', '', 'Fashion', 123, 12, 0, 0.00, 0.00, 'Active'),
(6, 6, 'Instagram', 'Nica', '', 'Fashion', 100000, 1, 0, 0.00, 0.00, 'Active'),
(7, 1, 'Instagram', 'Edrians', '', 'Travel', 123, 111, 0, 0.00, 0.00, 'Active'),
(8, 7, 'Instagram', 'Ezekiel', '', 'Fashion', 123, 1, 0, 0.00, 0.00, 'Active'),
(9, 8, 'Instagram', 'Vinser', '', 'Fashion', 500, 1, 0, 0.00, 0.00, 'Active'),
(10, 9, 'Instagram', 'Edrian', '', 'Tech', 122, 1, 0, 0.00, 0.00, 'Active'),
(11, 29, 'instagram', '_superedrian', 'https://scontent.fcrk3-3.fna.fbcdn.net/v/t51.82787-15/565542354_18290258593260267_5156685838200252160_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=7d201b&_nc_eui2=AeFszzFSF6zn23pBKFZqCJukFt_djvbJo2wW392O9smjbFGs5d1tw1QYXgB1wpz8SiQ6OzWfIGg7tp1QCcFDA27o&_nc_ohc=4Tt3Yz', '', 163, 5.67, 0, 0.00, 0.00, 'Active'),
(12, 11, 'Instagram', 'lifeofayemami', '', 'Fashion', 120, 1, 0, 0.00, 0.00, 'Active'),
(13, 12, 'youtube', 'skincare_317', 'https://ui-avatars.com/api/?name=skincare_317&background=random', 'SkinCare', 1132843, 0, 0, 0.00, 0.00, 'For Outreach'),
(14, 13, 'youtube', 'fitness_772', 'https://ui-avatars.com/api/?name=fitness_772&background=random', 'Fitness', 1951057, 0, 0, 0.00, 0.00, 'Active'),
(15, 14, 'youtube', 'Panlasang Pinoy', 'https://yt3.ggpht.com/ytc/AIdro_lxERz5AzUpDZOQoI9csVM_J_iusXdNb84onbBwUMbi-gU=s88-c-k-c0xffffffff-no-rj-mo', '', 7400000, 0, 0, 0.00, 0.00, 'For Outreach'),
(16, 15, 'youtube', 'SYNTETIKO', 'https://yt3.ggpht.com/dw0RzBTZ8Y4cRVv9auBlZITsxJt3ili5qRruCjUvAx2BX5AlGrMcBknyJqn6NDsglSw6jLZgSg=s88-c-k-c0xffffffff-no-rj-mo', '', 48900, 0, 0, 0.00, 0.00, 'For Outreach'),
(17, 16, 'youtube', 'Pinoy Food Lab.', 'https://yt3.ggpht.com/ytc/AIdro_nSOIeuVqqoRFhnXtu_KDda9Bmi3l0lSUp0KTsDSGEAqg=s88-c-k-c0xffffffff-no-rj-mo', '', 1680, 0, 0, 0.00, 0.00, 'For Outreach'),
(20, 19, 'youtube', 'PINOY FOOD VIBES', 'https://yt3.ggpht.com/Kdufd2Qt7UM5Y5OcLfSqqpL1S1zxzaBPdqAcrVvfKmBKu4iaUS5Gst_gftlR_W92yv9AEQSPMw=s88-c-k-c0xffffffff-no-rj-mo', '', 505, 0, 0, 0.00, 0.00, 'Active'),
(21, 20, 'youtube', 'Paola Barro', 'https://yt3.ggpht.com/ytc/AIdro_m3Dc4EYzmrjw06xJgv85hcHvidQESLcKoXbHOP73gerN4=s88-c-k-c0xffffffff-no-rj-mo', '', 415000, 0, 160276, 0.00, 0.00, 'Active'),
(22, 21, 'youtube', 'NIKE channel', 'https://yt3.ggpht.com/ytc/AIdro_k2c-svdMub4V-d5R5wrQQug-F1yAKOxr52NDLno4gjZw=s88-c-k-c0xffffffff-no-rj-mo', '', 586000, 0, 4595988, 0.00, 0.00, 'Active'),
(23, 22, 'instagram', 'blythe', 'https://scontent.fcrk3-4.fna.fbcdn.net/v/t51.2885-15/486305521_1760583207845387_6766879967883414965_n.jpg?_nc_cat=1&ccb=1-7&_nc_sid=7d201b&_nc_eui2=AeESLCWPYBbmtQKj-Sf21kYCF-GMugRuabIX4Yy6BG5psiYQ0RLkcb0r27ThNnuTYcPPHOLAltkxkIDfaqPkQHGU&_nc_ohc=wGx5zxwubc', '', 14594004, 0, 0, 0.00, 0.00, 'Active'),
(24, 23, 'instagram', 'realjennycoox', 'https://scontent.fcrk3-4.fna.fbcdn.net/v/t51.82787-15/529655768_17936588649062726_8779477508254753841_n.jpg?_nc_cat=1&ccb=1-7&_nc_sid=7d201b&_nc_eui2=AeEVl7Fj64PDHpyT6Cmpv0xWwDaJo9zj_IbANomj3OP8hrSBGG6WPQBncZRJ_eCXpKXpzDlKTOnlOCoQCD2yFMCu&_nc_ohc=_XA6AD4l', '', 498630, 0, 0, 0.00, 0.00, 'Active'),
(25, 25, 'youtube', 'Cong TV', 'https://yt3.ggpht.com/ytc/AIdro_lU5D54Y0dz4mEx78Qqz_YL8UKoVehxhEl1PSFzJFKsK9E=s88-c-k-c0xffffffff-no-rj-mo', '', 12600000, 0, 3362614, 0.00, 0.00, 'Active'),
(26, 26, NULL, 'Papa Shoutout', 'https://yt3.ggpht.com/ytc/AIdro_nYEp0NJb-KHZHjEqh1LTsrE_bUs-RUQyK6R6--0TRaVA=s88-c-k-c0xffffffff-no-rj-mo', '', 1100000, 0, 437316, 0.00, 0.00, 'Active'),
(27, 27, 'instagram', 'viycortez', 'https://scontent.fcrk3-4.fna.fbcdn.net/v/t51.82787-15/619815301_18558267484054520_2096323089447754922_n.jpg?_nc_cat=1&ccb=1-7&_nc_sid=7d201b&_nc_eui2=AeFyrZhdwtvG626IvQINZ9yYswWtOzNRFDOzBa07M1EUM6Hqrts-MndI1JDJp9lK6d3U0kA6jPnAZumgbOHuE-HQ&_nc_ohc=1pzv7eD4', '', 3526756, 0.31, 0, 0.00, 0.00, 'Active'),
(28, 30, 'instagram', 'nianaguerrero', 'https://ui-avatars.com/api/?name=nianaguerrero&background=random&color=fff', '', 0, 0, 0, 0.00, 0.00, 'Active'),
(29, 31, 'instagram', 'zeinab_harake', 'https://ui-avatars.com/api/?name=zeinab_harake&background=random&color=fff', '', 16000000, 0, 0, 0.00, 0.00, 'Active'),
(30, 32, 'instagram', 'mariacarmell4', 'https://ui-avatars.com/api/?name=mariacarmell4&background=random&color=fff', '', 263, 0, 0, 0.00, 0.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `influencer_profiles`
--

CREATE TABLE `influencer_profiles` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `contact_info` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `influencer_profiles`
--

INSERT INTO `influencer_profiles` (`id`, `full_name`, `first_name`, `last_name`, `email`, `contact_number`, `contact_info`, `location`, `shipping_address`, `notes`, `created_at`) VALUES
(1, 'edrian faderon', '', '', 'hardenfaderon@gmail.com', '', '', 'balite', '', 'dad', '2026-01-25 08:35:49'),
(2, 'Danica', '', '', 'zdanica439@gmail.com', '', '', 'Tawiran', '', '', '2026-01-26 03:03:31'),
(3, 'king', '', '', 'king@yahoo.com', '', '', 'balite', '', '', '2026-01-26 10:57:01'),
(4, 'bide', '', '', 'bide@yahoo.com', '', '', 'balite', '', '', '2026-01-26 11:11:41'),
(5, 'Benedict', '', '', 'edrianfaderon@gmail.com', '', '', 'Ilaya', '', '', '2026-01-26 16:26:00'),
(6, 'Nica Zamora', '', '', 'zdanica439@gmail.com', '', '', 'Tawiran', '', '', '2026-01-27 09:33:45'),
(7, 'ezekiel arandia', '', '', 'ezyarandia@gmail.com', '', '', 'balite', '', '', '2026-01-27 09:38:19'),
(8, 'VInsey Constantino', '', '', 'managerconstantino@gmail.com', '', '', 'Nacoco', '', '', '2026-01-27 09:42:26'),
(9, 'Edrian Benedict', '', '', 'hardenfaderon@gmail.com', '', '', 'Korea', '', 'sa', '2026-01-27 11:18:27'),
(10, 'Edrian Benedict Faderon', '', '', 'hardenfaderon@gmail.com', '', '', 'Balite', '', '', '2026-01-28 14:10:35'),
(11, 'Danica Zamora', '', '', 'zdanica@gmail.com', '', '', 'Calapan', '', '', '2026-01-28 14:12:00'),
(12, 'SkinCare Creator 1', '', '', '', '', '', '', '', '', '2026-01-28 16:31:49'),
(13, 'Fitness Creator 1', '', '', '', '', '', '', '', 'wala', '2026-01-28 16:32:35'),
(14, 'Panlasang Pinoy', '', '', '', '', '', '', '', '', '2026-01-28 17:14:23'),
(15, 'SYNTETIKO', '', '', '', '', 'https://www.youtube.com/channel/UCRMvF5U0-sfilnLPNMFYCNQ', '', '', '', '2026-01-28 17:51:32'),
(16, 'Pinoy Food Lab.', '', '', '', '', 'https://www.youtube.com/channel/UCG6a763XZLhFrekF-1D9o7w', '', '', '', '2026-01-28 17:52:49'),
(19, 'PINOY FOOD VIBES', '', '', '', '', 'https://www.youtube.com/channel/UCwPvRPUvtpnkQvU4g28qmBw', '', '', '', '2026-01-28 18:03:45'),
(20, 'Paola Barro', '', '', '', '', 'https://www.youtube.com/channel/UCl6XiyTh_Y3KDckkmoNdREg', '', '', '...', '2026-01-29 11:18:28'),
(21, 'NIKE channel', '', '', '', '', 'https://www.youtube.com/channel/UC5Lxlc7YV1xfSR0mUnK3Y1w', 'ID', '', 'Hi...Welcome to our Channel \nThere are variety of Full HD videos about play and learn for children, Toys, \nthe recitation of short surahs in Quran, Vlog, Culinary, and many more. \nNike Putri Maulida i...', '2026-01-29 16:58:19'),
(22, 'Andrea Brillantes', '', '', '', '', '', '', '', 'Source: Instagram Graph API', '2026-01-29 17:59:50'),
(23, 'Jenny Cox', '', '', '', '', '', '', '', 'Source: Instagram Graph API', '2026-01-30 08:19:41'),
(24, '???????????????????????? ????????????????????????????????', '', '', 'hardenfaderon@gmail.com', '', '', 'Global', '', 'Source: Instagram Graph API', '2026-01-30 08:30:47'),
(25, 'Cong TV', '', '', '', '', 'https://www.youtube.com/channel/UC73zqrs0Th_a9dFUivEmv2A', 'PH', '', 'bat ka umaabot dito? walang meron dito.  gago ka ba?...', '2026-01-30 09:28:27'),
(26, 'Papa Shoutout', NULL, NULL, '', '', 'https://www.youtube.com/channel/UCEdEtSL8hAl3qmbmEAq-oTw', 'ilaya', '', '', '2026-01-30 09:49:31'),
(27, 'Viy Cortez-Velasquez', '', '', '', '', 'https://instagram.com/viycortez', '', '', 'a', '2026-01-30 10:24:18'),
(28, '???????????????????????? ????????????????????????????????', '', '', '', '', 'https://instagram.com/_superedrian', '', '', ',', '2026-01-30 10:33:24'),
(29, '???????????????????????? ????????????????????????????????', '', '', '', '', 'https://instagram.com/_superedrian', '', '', 'Direct Lookup via Instagram Graph API', '2026-01-30 10:41:13'),
(30, 'nianaguerrero', '', '', '', '', 'https://www.instagram.com/nianaguerrero/', '', '', '16M Followers, 1,868 Following, 1,324 Posts - See Instagram photos and videos from niana (@nianaguer...', '2026-01-30 14:42:46'),
(31, 'zeinab_harake', '', '', '', '', 'https://www.instagram.com/zeinab_harake/', '', '', 's', '2026-01-30 14:47:37'),
(32, 'niana', '', '', '', '', 'https://www.instagram.com/mariacarmell4/', '', '', '263K followers Followers...', '2026-01-30 14:57:45');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `search_history`
--

CREATE TABLE `search_history` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `platform` varchar(50) DEFAULT 'instagram',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `search_history`
--

INSERT INTO `search_history` (`id`, `user_id`, `keyword`, `platform`, `created_at`) VALUES
(1, 4, '_superedrian', 'instagram', '2026-01-30 05:47:04'),
(2, 4, '_superedrian', 'instagram', '2026-01-30 06:05:00'),
(3, 4, '_superedrian', 'instagram', '2026-01-30 06:06:08'),
(4, 4, '_superedrian', 'instagram', '2026-01-30 06:17:09'),
(5, 4, '_superedrian', 'instagram', '2026-01-30 06:21:27'),
(6, 4, '_superedrian', 'instagram', '2026-01-30 06:40:56'),
(7, 4, '_superedrian', 'instagram', '2026-01-30 06:56:36'),
(8, 4, 'Cong tv', 'youtube', '2026-01-30 07:11:20'),
(9, 4, 'Cong tv', 'youtube', '2026-01-30 07:18:39'),
(10, 4, 'travel', 'instagram', '2026-01-30 07:21:22'),
(11, 4, 'travel blogger', 'instagram', '2026-01-30 07:35:31'),
(12, 4, 'Raffy', 'youtube', '2026-01-30 07:40:51'),
(13, 4, 'Cong tv', 'instagram', '2026-01-30 10:55:45'),
(14, 4, '_superedrian', 'instagram', '2026-01-30 10:56:12'),
(15, 4, 'Cong tv', 'youtube', '2026-01-30 10:56:24'),
(16, 4, '_superedrian', 'instagram', '2026-01-30 14:33:40'),
(17, 4, 'armfulmediaofficial', 'instagram', '2026-01-30 14:36:16'),
(18, 4, 'armfulmediaofficial', 'instagram', '2026-01-30 14:37:40'),
(19, 4, 'armfulmediaofficial', 'instagram', '2026-01-30 14:37:56'),
(20, 4, 'armfulmediaofficial', 'instagram', '2026-01-31 01:24:01'),
(21, 4, '_superedrian', 'instagram', '2026-01-31 01:24:13'),
(22, 4, '_superedrian', 'instagram', '2026-01-31 01:24:23'),
(23, 4, '_superedrian', 'instagram', '2026-01-31 01:24:36'),
(24, 4, '_superedrian', 'instagram', '2026-01-31 02:47:36'),
(25, 4, 'Cong tv', 'youtube', '2026-01-31 02:48:32'),
(26, 4, 'Cong tv', 'youtube', '2026-01-31 03:06:53'),
(27, 4, 'dance', 'tiktok', '2026-01-31 03:07:04'),
(28, 4, 'edrianfaderon', 'tiktok', '2026-01-31 03:15:40'),
(29, 4, 'dance', 'tiktok', '2026-01-31 03:18:03'),
(30, 4, 'edrianfaderon', 'tiktok', '2026-01-31 03:18:11'),
(31, 4, 'edrianfaderon', 'tiktok', '2026-01-31 03:27:22'),
(32, 4, 'vza.mee5', 'tiktok', '2026-01-31 03:28:16'),
(33, 4, '_superedrian', 'instagram', '2026-02-01 01:07:56'),
(34, 4, 'Cong tv', 'youtube', '2026-02-01 01:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','employee') DEFAULT 'employee',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`, `created_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$H3QBdqOAElaq89lmLULsA.3JcVkzT.YaNrRtd96pF8GFAsE4UdCES', 'admin', 'active', '2026-01-23 00:10:35'),
(4, 'Benedict', 'benedict@gmail.com', '$2y$10$DLYtYvporvjMrxydmR8vd.nIvYSDE/1rtwZ4WDGizMWuvew8M4y/S', 'employee', 'active', '2026-01-28 02:42:32'),
(6, 'Manager', 'Manager@gmail.com', '$2y$10$6N7DIda0xUhXub.SUXZjyO9vmjDI5Xw/w1tJxrvZvFubIt3CIStjy', 'manager', 'active', '2026-01-28 06:22:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaign_assignments`
--
ALTER TABLE `campaign_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `campaign_id` (`campaign_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `collaborations`
--
ALTER TABLE `collaborations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile_id` (`profile_id`),
  ADD KEY `idx_collaborations_profile_id` (`profile_id`),
  ADD KEY `idx_collaborations_account_id` (`account_id`),
  ADD KEY `idx_collaborations_pipeline_status` (`pipeline_status`);

--
-- Indexes for table `email_conversations`
--
ALTER TABLE `email_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `influencer_id` (`influencer_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_direction` (`direction`),
  ADD KEY `idx_is_read` (`is_read`),
  ADD KEY `idx_unread_counts` (`direction`,`is_read`,`influencer_id`);

--
-- Indexes for table `influencers`
--
ALTER TABLE `influencers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `influencer_accounts`
--
ALTER TABLE `influencer_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile_id` (`profile_id`),
  ADD KEY `idx_influencer_accounts_username` (`username`),
  ADD KEY `idx_influencer_accounts_platform` (`platform`);

--
-- Indexes for table `influencer_profiles`
--
ALTER TABLE `influencer_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_influencer_profiles_email` (`email`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `campaign_assignments`
--
ALTER TABLE `campaign_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `collaborations`
--
ALTER TABLE `collaborations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `email_conversations`
--
ALTER TABLE `email_conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `influencers`
--
ALTER TABLE `influencers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `influencer_accounts`
--
ALTER TABLE `influencer_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `influencer_profiles`
--
ALTER TABLE `influencer_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `campaign_assignments`
--
ALTER TABLE `campaign_assignments`
  ADD CONSTRAINT `campaign_assignments_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `campaign_assignments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
