<?php
// Test script for Facebook/Instagram Graph API
// Run this via CLI: php test_facebook_api.php

$token = 'IGAARaZApCgl1dBZAGFfRW9aZA3Y3d1JOaHJ5ZAG1sZA0xiZA3E5SFB2VXU2NFRSdnF0SDhNSEgtWVA3SndEaHZA6OXpUT3k3Nlltclc0SzQwN3pub1BxUnp0bDVtNldoRlFaQUZA6TDRvT1BvMFFuQ0xsbmQ5WWVUMnh5ZAW15WXZAUMEZArTQZDZD';

echo "Testing Facebook/Instagram API Token...\n";

// 1. Get Me (Basic Info)
$url = "https://graph.instagram.com/me?fields=id,username,account_type,media_count&access_token=" . $token;
echo "\n1. Testing /me Endpoint: $url\n";
$response = make_request($url);
echo "Response: " . substr($response, 0, 500) . "...\n";

// 2. Test Graph API (Business Discovery Capability)
// Try to get associated pages or business accounts
$url_graph = "https://graph.facebook.com/v18.0/me/accounts?access_token=" . $token;
echo "\n2. Testing Facebook Graph API /me/accounts: $url_graph\n";
$response_graph = make_request($url_graph);
echo "Response: " . substr($response_graph, 0, 500) . "...\n";

// 3. Try Direct Business Discovery (Hypothetical - requires ID)
// We need an IG Business ID first, which we don't have yet.
// But let's see if the token is even valid for graph.facebook.com
$url_me_fb = "https://graph.facebook.com/v18.0/me?access_token=" . $token;
echo "\n3. Testing Facebook Graph API /me: $url_me_fb\n";
$response_me_fb = make_request($url_me_fb);
echo "Response: " . substr($response_me_fb, 0, 500) . "...\n";

function make_request($url) {
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30
    ]);
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    
    if ($err) {
        return "Error: " . $err;
    }
    return $response;
}
