<?php
// Script to brute-force check endpoints for Instagram Scraper Stable API
// Focusing on endpoints that previously timed out, with longer timeout and User-Agent
$key = 'f200d783a0msh467bb1c1792baafp1ecf56jsnbf34e24f46a1';
$host = 'instagram-scraper-stable-api.p.rapidapi.com';
$keyword = 'nike';

$endpoints = [
    "/ig/search_users?query=$keyword",
    "/user/info?user=$keyword",
    "/ig/search?query=$keyword",
    "/search?query=$keyword"
];

echo "Testing Host: $host with 60s timeout and User-Agent\n";

foreach ($endpoints as $path) {
    $url = "https://" . $host . $path;
    echo "Testing $path ... ";
    
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 60, // Increased timeout to 60s
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: " . $host,
            "X-RapidAPI-Key: " . $key,
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        ],
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_PROXY => ""
    ]);

    $response = curl_exec($curl);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);
    curl_close($curl);

    if ($err) {
        echo "Error: $err\n";
    } else {
        echo "HTTP $http_code\n";
        if ($http_code == 200) {
            echo "SUCCESS! Response: " . substr($response, 0, 200) . "...\n";
        } else {
             echo "Response ($http_code): " . substr($response, 0, 200) . "...\n";
        }
    }
    echo "--------------------------------------------------\n";
}
