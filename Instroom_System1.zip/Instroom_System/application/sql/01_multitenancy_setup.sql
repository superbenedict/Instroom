-- Multi-Tenancy Setup Script
-- Run this in MySQL Workbench

-- 1. Create Tenants Table
CREATE TABLE IF NOT EXISTS `tenants` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `subdomain` VARCHAR(50) DEFAULT NULL, -- Optional for domain-based routing
    `status` ENUM('active', 'inactive') DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 2. Add Default Tenant (System Owner)
INSERT INTO `tenants` (`id`, `name`) VALUES (1, 'Default Organization');

-- 3. Update Users Table
-- Check if column exists before adding (MySQL specific syntax workarounds or manual check)
-- Assuming fresh run or just alter:
ALTER TABLE `users` 
ADD COLUMN `tenant_id` INT(11) DEFAULT 1 AFTER `id`,
ADD INDEX `idx_user_tenant` (`tenant_id`),
ADD CONSTRAINT `fk_user_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON DELETE CASCADE;

-- 4. Update Other Major Tables (Example: Collaborations)
ALTER TABLE `collaborations` 
ADD COLUMN `tenant_id` INT(11) DEFAULT 1 AFTER `id`,
ADD INDEX `idx_collab_tenant` (`tenant_id`),
ADD CONSTRAINT `fk_collab_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON DELETE CASCADE;

ALTER TABLE `influencer_profiles` 
ADD COLUMN `tenant_id` INT(11) DEFAULT 1 AFTER `id`,
ADD INDEX `idx_profile_tenant` (`tenant_id`),
ADD CONSTRAINT `fk_profile_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON DELETE CASCADE;

ALTER TABLE `campaigns` 
ADD COLUMN `tenant_id` INT(11) DEFAULT 1 AFTER `id`,
ADD INDEX `idx_campaign_tenant` (`tenant_id`),
ADD CONSTRAINT `fk_campaign_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants`(`id`) ON DELETE CASCADE;

-- 5. Update Activity Logs
ALTER TABLE `activity_logs` 
ADD COLUMN `tenant_id` INT(11) DEFAULT 1 AFTER `id`,
ADD INDEX `idx_log_tenant` (`tenant_id`);
