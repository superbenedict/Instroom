<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property User_model $User_model
 * @property Activity_log_model $Activity_log_model
 * @property CI_Form_validation $form_validation
 * @property CI_Session $session
 * @property CI_Loader $load
 * @property CI_Input $input
 */
class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Activity_log_model'); // Load Activity Logger
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function index() {
        redirect('auth/login');
    }

    public function login() {
        if ($this->session->userdata('user_id')) {
            // If already logged in, redirect based on role
            $role = $this->session->userdata('role');
            if ($role === 'admin') {
                redirect('admin');
            } elseif ($role === 'manager') {
                redirect('manager');
            } else {
                redirect('welcome');
            }
        }

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('auth/login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $user = $this->User_model->login($email, $password);

            if ($user === 'inactive') {
                $this->session->set_flashdata('error', 'Your account is inactive. Please contact administrator.');
                redirect('auth/login');
            } elseif ($user) {
                $session_data = array(
                    'user_id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => isset($user->role) ? $user->role : 'employee',
                    'logged_in' => TRUE
                );
                $this->session->set_userdata($session_data);
                
                // Log Activity
                $this->Activity_log_model->log_activity(
                    $user->id,
                    $user->name,
                    'Login',
                    'User logged in successfully.'
                );

                // Redirect based on role
                if (isset($user->role)) {
                    if ($user->role === 'admin') {
                        redirect('admin');
                    } elseif ($user->role === 'manager') {
                        redirect('manager');
                    } else {
                        redirect('welcome');
                    }
                } else {
                    redirect('welcome');
                }
            } else {
                $this->session->set_flashdata('error', 'Invalid email or password');
                redirect('auth/login');
            }
        }
    }

    public function register() {
        if ($this->session->userdata('user_id')) {
            redirect('welcome');
        }

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('auth/register');
        } else {
            $data = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            );

            if ($this->User_model->register($data)) {
                $this->session->set_flashdata('success', 'Registration successful! Please login.');
                redirect('auth/login');
            } else {
                $this->session->set_flashdata('error', 'Something went wrong. Please try again.');
                redirect('auth/register');
            }
        }
    }

    public function logout() {
        if ($this->session->userdata('user_id')) {
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Logout',
                'User logged out.'
            );
        }
        $this->session->sess_destroy();
        redirect('auth/login');
    }

    public function forgot_password() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('auth/forgot_password');
        } else {
            $email = $this->input->post('email');
            
            // Check if email exists
            if ($this->User_model->email_exists($email)) {
                // Generate token
                $token = bin2hex(random_bytes(32));
                
                // Save token to password_resets table (assuming you created this table)
                // If not, you can create it or just skip this step for demo
                $this->User_model->save_password_reset_token($email, $token);

                // Send Email (Mock implementation)
                // $this->email->to($email);
                // $this->email->subject('Reset Password');
                // $this->email->message('Click here to reset: ' . site_url('auth/reset_password/' . $token));
                // $this->email->send();

                // For demo purposes, we'll just show success
                $this->session->set_flashdata('success', 'Password reset link has been sent to your email.');
            } else {
                $this->session->set_flashdata('error', 'Email not found.');
            }
            redirect('auth/forgot_password');
        }
    }
}
