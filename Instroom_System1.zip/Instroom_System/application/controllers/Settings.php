<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Session $session
 * @property CI_Loader $load
 */
class Settings extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
    }

    public function index() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_email'] = $this->session->userdata('email');
        $data['user_role'] = $this->session->userdata('role');
        $this->load->view('settings', $data);
    }
}
