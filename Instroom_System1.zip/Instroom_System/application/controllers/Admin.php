<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Session $session
 * @property CI_Input $input
 * @property CI_Loader $load
 * @property User_model $User_model
 * @property Influencer_model $Influencer_model
 * @property Activity_log_model $Activity_log_model
 */
class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        
        // Check if user is logged in
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
        
        // Check if user is admin
        $role = $this->session->userdata('role');
        if ($role !== 'admin') {
            show_error('You are not authorized to access this page.', 403, 'Forbidden');
        }
    }

    public function index() {
        $this->load->model('Activity_log_model');
        $this->load->model('User_model');
        $this->load->model('Influencer_model');

        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        
        // Fetch real stats
        $data['total_users'] = $this->User_model->count_all_users(); // Need to ensure this method exists or use db->count_all
        $data['total_influencers'] = $this->Influencer_model->count_influencers();
        $data['growth_trend'] = $this->Influencer_model->get_influencer_growth_trend(7); // Get last 7 days trend
        $data['recent_logs'] = $this->Activity_log_model->get_logs(5);
        
        $this->load->view('admin/dashboard', $data);
    }

    public function users() {
        $this->load->model('User_model');
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['users'] = $this->User_model->get_all_users();
        $this->load->view('admin/users', $data);
    }

    public function activity_logs() {
        $this->load->model('Activity_log_model');
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['logs'] = $this->Activity_log_model->get_logs(100);
        $this->load->view('admin/activity_logs', $data);
    }

    public function settings() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $this->load->view('admin/settings', $data);
    }

    public function save_user() {
        $this->load->model('User_model');
        
        $id = $this->input->post('user_id');
        $data = array(
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'role' => $this->input->post('role'),
            'status' => $this->input->post('status')
        );

        $password = $this->input->post('password');
        if (!empty($password)) {
            $data['password'] = password_hash($password, PASSWORD_BCRYPT);
        }

        if ($id) {
            $this->User_model->update_user($id, $data);
        } else {
            // Check if email exists
            if ($this->User_model->email_exists($data['email'])) {
                echo json_encode(['status' => 'error', 'message' => 'Email already exists']);
                return;
            }
            // Ensure status is set for new users if not provided
            if (empty($data['status'])) {
                $data['status'] = 'active';
            }
            $this->User_model->register($data);
        }

        echo json_encode(['status' => 'success']);
    }

    public function toggle_status($id) {
        $this->load->model('User_model');
        $user = $this->User_model->get_user_by_id($id);
        
        if ($user) {
            $new_status = ($user->status === 'active') ? 'inactive' : 'active';
            $this->User_model->update_user($id, ['status' => $new_status]);
            echo json_encode(['status' => 'success', 'new_status' => $new_status]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'User not found']);
        }
    }

    public function delete_user($id) {
        $this->load->model('User_model');
        // Prevent deleting self
        if ($id == $this->session->userdata('user_id')) {
            echo json_encode(['status' => 'error', 'message' => 'Cannot delete your own account']);
            return;
        }
        
        if ($this->User_model->delete_user($id)) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete user']);
        }
    }
}
