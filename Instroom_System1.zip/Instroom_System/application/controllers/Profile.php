<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Session $session
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Form_validation $form_validation
 * @property User_model $User_model
 */
class Profile extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('User_model');
        $this->load->library('form_validation');

        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
    }

    public function index() {
        $user_id = $this->session->userdata('user_id');
        $data['user'] = $this->User_model->get_user_by_id($user_id);
        $data['user_name'] = $data['user']->name;
        
        $this->load->view('profile', $data);
    }

    public function update() {
        $user_id = $this->session->userdata('user_id');
        
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('profile');
        } else {
            $data = [
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email')
            ];

            // Check if email is already taken by another user
            // This logic is simple; ideally, we should check if email exists for ID != user_id
            // For now, assuming email change is allowed without uniqueness check on update for simplicity
            // or we can implement email_exists_for_other($email, $id) in model.
            
            // Let's rely on basic update for now.

            if ($this->User_model->update_user($user_id, $data)) {
                // Update session data
                $this->session->set_userdata('name', $data['name']);
                $this->session->set_userdata('email', $data['email']);
                
                $this->session->set_flashdata('success', 'Profile updated successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to update profile.');
            }
            redirect('profile');
        }
    }

    public function change_password() {
        $user_id = $this->session->userdata('user_id');

        $this->form_validation->set_rules('current_password', 'Current Password', 'required');
        $this->form_validation->set_rules('new_password', 'New Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[new_password]');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('profile');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password');

            if ($this->User_model->check_password($user_id, $current_password)) {
                $data = ['password' => password_hash($new_password, PASSWORD_BCRYPT)];
                if ($this->User_model->update_user($user_id, $data)) {
                    $this->session->set_flashdata('success', 'Password changed successfully!');
                } else {
                    $this->session->set_flashdata('error', 'Failed to update password.');
                }
            } else {
                $this->session->set_flashdata('error', 'Incorrect current password.');
            }
            redirect('profile');
        }
    }
}
