<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {
    public $session;
    public $input;
    public $email;
    public $db;
    public $Email_model;
    public $Influencer_model;

    public function __construct() {
        parent::__construct();
        $this->load->model('Email_model');
        $this->load->model('Influencer_model'); // To get influencer details
        $this->load->library('email');
        $this->load->library('session');
        
        // Allow CLI execution to bypass session check
        if (is_cli()) {
            return;
        }
        
        if (!$this->session->userdata('user_id')) {
            echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
            exit;
        }
    }

    // Configure your SMTP settings here or load from database/config
    private function _get_email_config() {
        return array(
            'protocol' => 'smtp',
            'smtp_host' => 'smtp.gmail.com',
            'smtp_port' => 587,
            'smtp_user' => 'hardenfaderon@gmail.com',
            'smtp_pass' => str_replace(' ', '', 'keip omxc dhzg dleq'), // Remove spaces just in case
            'smtp_crypto' => 'tls',
            'mailtype' => 'html',
            'charset' => 'utf-8',
            'newline' => "\r\n",
            'crlf' => "\r\n", // Add this for consistency
            'wordwrap' => TRUE,
            'validation' => FALSE // Skip strict validation
        );
    }

    public function send() {
        $influencer_id = $this->input->post('influencer_id');
        $subject = $this->input->post('subject');
        $body = $this->input->post('body');

        if (!$influencer_id || !$subject || !$body) {
            echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
            return;
        }

        $influencer = $this->Influencer_model->get_influencer($influencer_id);
        if (!$influencer) {
            echo json_encode(['status' => 'error', 'message' => 'Influencer not found']);
            return;
        }

        $config = $this->_get_email_config();
        $this->email->initialize($config);

        $this->email->from($config['smtp_user'], 'Instroom System'); // Or user's name
        $this->email->to($influencer['email']);
        $this->email->subject($subject);
        $this->email->message($body);

        // Optimistic Success: Save to DB first to make UI fast
        $data = array(
            'user_id' => $this->session->userdata('user_id'),
            'influencer_id' => $influencer_id,
            'sender_email' => $config['smtp_user'],
            'recipient_email' => $influencer['email'],
            'subject' => $subject,
            'body' => $body,
            'direction' => 'outbound',
            'is_read' => 1,
            'created_at' => date('Y-m-d H:i:s')
        );

        // Try to send email
        if ($this->email->send()) {
            // Save ONLY if sent successfully to ensure data integrity
            if ($this->Email_model->save_email($data)) {
                echo json_encode(['status' => 'success', 'message' => 'Email sent successfully']);
            } else {
                 log_message('error', 'Email sent but failed to save to DB: ' . $this->db->error()['message']);
                 echo json_encode(['status' => 'success', 'message' => 'Email sent, but history could not be saved.']);
            }
        } else {
            // Log error but don't save to DB
            $error = strip_tags($this->email->print_debugger());
            log_message('error', 'Email Send Error: ' . $error);
            echo json_encode(['status' => 'error', 'message' => 'Failed to send email. Check SMTP settings.']);
        }
    }

    public function history($influencer_id) {
        $emails = $this->Email_model->get_emails_by_influencer($influencer_id);
        echo json_encode(['status' => 'success', 'data' => $emails]);
    }

    // Helper to decode IMAP body
    private function _get_part($imap, $uid, $mimetype, $structure = false, $partNumber = false) {
        if (!$structure) {
            $structure = imap_fetchstructure($imap, $uid, FT_UID);
        }
        if ($structure) {
            if ($mimetype == $this->_get_mime_type($structure)) {
                if (!$partNumber) {
                    $partNumber = 1;
                }
                $text = imap_fetchbody($imap, $uid, $partNumber, FT_UID);
                switch ($structure->encoding) {
                    case 3: $text = base64_decode($text); break;
                    case 4: $text = quoted_printable_decode($text); break;
                }
                
                // Handle charset
                $charset = 'UTF-8';
                if (isset($structure->parameters)) {
                    foreach ($structure->parameters as $param) {
                        if (strtoupper($param->attribute) == 'CHARSET') {
                            $charset = strtoupper($param->value);
                            break;
                        }
                    }
                }
                
                // Convert to UTF-8 if needed
                if ($charset != 'UTF-8' && $charset != 'DEFAULT') {
                     // mb_convert_encoding is robust
                     $text = mb_convert_encoding($text, 'UTF-8', $charset);
                }
                
                return $text;
            }

            // Multipart
            if ($structure->type == 1) {
                foreach ($structure->parts as $index => $subStruct) {
                    $prefix = "";
                    if ($partNumber) {
                        $prefix = $partNumber . ".";
                    }
                    $data = $this->_get_part($imap, $uid, $mimetype, $subStruct, $prefix . ($index + 1));
                    if ($data) {
                        return $data;
                    }
                }
            }
        }
        return false;
    }

    private function _get_mime_type($structure) {
        $primaryMimetype = array("TEXT", "MULTIPART", "MESSAGE", "APPLICATION", "AUDIO", "IMAGE", "VIDEO", "OTHER");
        if ($structure->subtype) {
            return $primaryMimetype[(int)$structure->type] . "/" . $structure->subtype;
        }
        return "TEXT/PLAIN";
    }

    public function unread_counts() {
        $counts = $this->Email_model->get_unread_counts();
        echo json_encode(['status' => 'success', 'data' => $counts]);
    }

    public function mark_read($influencer_id) {
        $this->Email_model->mark_all_read($influencer_id);
        echo json_encode(['status' => 'success']);
    }

    private function _get_sync_start_date($influencer_id) {
        // 1. Try to find first outbound email
        $first_email_date = $this->Email_model->get_first_outbound_date($influencer_id);
        
        if ($first_email_date) {
            return strtotime($first_email_date);
        }

        // 2. Fallback to influencer creation date
        $influencer = $this->Influencer_model->get_influencer($influencer_id);
        if ($influencer && isset($influencer['created_at'])) {
            return strtotime($influencer['created_at']);
        }

        // 3. Fallback to 30 days ago if nothing else
        return strtotime('-30 days');
    }

    public function check_new_emails() {
        if (!function_exists('imap_open')) {
            echo json_encode(['status' => 'error', 'message' => 'IMAP extension not enabled']);
            return;
        }

        $config = $this->_get_email_config();
        $mailbox = '{imap.gmail.com:993/imap/ssl}INBOX';
        
        try {
            $inbox = @imap_open($mailbox, $config['smtp_user'], $config['smtp_pass']);
            if (!$inbox) {
                echo json_encode(['status' => 'error', 'message' => 'Cannot connect to IMAP: ' . imap_last_error()]);
                return;
            }

            // Search for UNSEEN emails
            $emails = imap_search($inbox, 'UNSEEN');
            
            $new_count = 0;
            $senders = [];

            if ($emails) {
                rsort($emails); 
                
                // LIMIT: Only process the 20 most recent unread emails to prevent timeout/slowdown
                $emails = array_slice($emails, 0, 20);

                foreach ($emails as $email_number) {
                    $overview = imap_fetch_overview($inbox, $email_number, 0);
                    $from = isset($overview[0]->from) ? $overview[0]->from : '';
                    $date = isset($overview[0]->date) ? strtotime($overview[0]->date) : time();
                    
                    // Extract email address
                    if (preg_match('/<([^>]+)>/', $from, $matches)) {
                        $email_addr = $matches[1];
                    } else {
                        $email_addr = $from;
                    }

                    // Check if this sender is an influencer
                    $influencer = $this->Influencer_model->get_influencer_by_email($email_addr);
                    
                    if ($influencer) {
                        // FILTER: Check if email is older than conversation start
                        $start_date = $this->_get_sync_start_date($influencer['id']);
                        // Allow a small buffer (e.g., 1 day before creation just in case of timezone issues)
                        if ($date < ($start_date - 86400)) {
                            continue;
                        }

                        $message_id = isset($overview[0]->message_id) ? $overview[0]->message_id : null;
                        
                        // Use UID
                        $uid = imap_uid($inbox, $email_number);
                        
                        // Check duplicates
                        if ($message_id && $this->Email_model->email_exists($message_id)) {
                            continue;
                        }

                        $body = $this->_get_part($inbox, $uid, "TEXT/HTML");
                        if (!$body) $body = $this->_get_part($inbox, $uid, "TEXT/PLAIN");
                        if (!$body) $body = "(No content)";

                        // Decode subject
                        $subject = isset($overview[0]->subject) ? $overview[0]->subject : '(No Subject)';
                        $subject_parts = imap_mime_header_decode($subject);
                        $subject = "";
                        foreach ($subject_parts as $p) {
                            $subject .= $p->text;
                        }

                        $data = array(
                            'user_id' => $this->session->userdata('user_id'),
                            'influencer_id' => $influencer['id'],
                            'sender_email' => $email_addr,
                            'recipient_email' => $config['smtp_user'],
                            'subject' => $subject,
                            'body' => $body,
                            'direction' => 'inbound',
                            'is_read' => 0,
                            'created_at' => date('Y-m-d H:i:s', $date),
                            'message_id' => $message_id
                        );

                        $this->Email_model->save_email($data);
                        $new_count++;
                        $senders[] = $influencer['username'] ?: $influencer['full_name'];
                    }
                }
            }
            
            imap_close($inbox);
            echo json_encode([
                'status' => 'success', 
                'new_count' => $new_count, 
                'senders' => array_unique($senders)
            ]);

        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function sync() {
        $influencer_id = $this->input->post('influencer_id');
        if (!$influencer_id) {
             echo json_encode(['status' => 'error', 'message' => 'Influencer ID required']);
             return;
        }

        $influencer = $this->Influencer_model->get_influencer($influencer_id);

        if (!function_exists('imap_open')) {
            echo json_encode(['status' => 'error', 'message' => 'IMAP extension not enabled in PHP']);
            return;
        }

        $config = $this->_get_email_config();
        $mailbox = '{imap.gmail.com:993/imap/ssl}INBOX';
        $username = $config['smtp_user'];
        $password = $config['smtp_pass'];

        try {
            $inbox = @imap_open($mailbox, $username, $password);
            if (!$inbox) {
                echo json_encode(['status' => 'error', 'message' => 'Cannot connect to IMAP: ' . imap_last_error()]);
                return;
            }

            // FILTER: Only fetch emails since conversation start
            $start_timestamp = $this->_get_sync_start_date($influencer_id);
            // IMAP Date format: "27-Jan-2026"
            // We subtract 1 day to be safe with timezones
            $since_date = date('d-M-Y', $start_timestamp - 86400);

            // Search for emails FROM this influencer SINCE the start date
            $search_criteria = 'FROM "' . $influencer['email'] . '" SINCE "' . $since_date . '"';
            $emails = imap_search($inbox, $search_criteria);

            $count = 0;
            if ($emails) {
                rsort($emails); // Process newest first
                
                foreach ($emails as $email_number) {
                    // Fetch overview to get Message-ID and Date
                    $overview = imap_fetch_overview($inbox, $email_number, 0);
                    $message_id = isset($overview[0]->message_id) ? $overview[0]->message_id : null;
                    $uid = isset($overview[0]->uid) ? $overview[0]->uid : $email_number; 
                    $uid = imap_uid($inbox, $email_number);
                    $date = isset($overview[0]->date) ? strtotime($overview[0]->date) : time();

                    // Double check date in PHP (IMAP SINCE ignores time)
                    if ($date < ($start_timestamp - 86400)) {
                        continue;
                    }

                    // Check if already exists
                    if ($message_id && $this->Email_model->email_exists($message_id)) {
                        continue;
                    }

                    // Fetch body (Try HTML, then Plain)
                    $body = $this->_get_part($inbox, $uid, "TEXT/HTML");
                    if (!$body) {
                        $body = $this->_get_part($inbox, $uid, "TEXT/PLAIN");
                    }
                    if (!$body) {
                        $body = "(No content)";
                    }
                    
                    // Decode subject if necessary
                    $subject = isset($overview[0]->subject) ? $overview[0]->subject : '(No Subject)';
                    $subject_parts = imap_mime_header_decode($subject);
                    $subject = "";
                    foreach ($subject_parts as $p) {
                        $subject .= $p->text;
                    }

                    // Save to DB
                    $data = array(
                        'user_id' => $this->session->userdata('user_id'),
                        'influencer_id' => $influencer_id,
                        'sender_email' => $overview[0]->from,
                        'recipient_email' => $username, // Us
                        'subject' => $subject,
                        'body' => $body,
                        'direction' => 'inbound',
                        'is_read' => 0,
                        'created_at' => date('Y-m-d H:i:s', $date),
                        'message_id' => $message_id
                    );
                    
                    $this->Email_model->save_email($data);
                    $count++;
                }
            }

            imap_close($inbox);
            echo json_encode(['status' => 'success', 'message' => 'Synced ' . $count . ' new emails']);

        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function cleanup_legacy_emails() {
        if (!$this->input->is_cli_request() && !$this->session->userdata('user_id')) {
             echo "Access denied";
             return;
        }

        $influencers = $this->Influencer_model->get_all_influencers();
        $deleted_count = 0;

        foreach ($influencers as $inf) {
            $start_timestamp = $this->_get_sync_start_date($inf->id);
            // Add buffer of 1 day
            $cutoff_date = date('Y-m-d H:i:s', $start_timestamp - 86400);

            $this->db->where('influencer_id', $inf->id);
            $this->db->where('direction', 'inbound');
            $this->db->where('created_at <', $cutoff_date);
            $this->db->delete('email_conversations');
            
            $deleted_count += $this->db->affected_rows();
        }

        echo json_encode(['status' => 'success', 'message' => "Cleaned up $deleted_count old emails."]);
    }

    public function test_send() {
        if (!is_cli()) {
            echo "This method is only allowed via CLI.";
            return;
        }
        
        echo "Starting Email Test...\n";
        
        $config = $this->_get_email_config();
        echo "Config loaded: " . $config['smtp_user'] . "\n";
        
        $this->email->initialize($config);
        $this->email->set_newline("\r\n");
        
        $this->email->from($config['smtp_user'], 'Instroom System Test');
        $this->email->to($config['smtp_user']); // Send to self
        $this->email->subject('Instroom SMTP Test ' . date('Y-m-d H:i:s'));
        $this->email->message('This is a test email from the Instroom System via CodeIgniter.');

        if ($this->email->send()) {
            echo "SUCCESS: Email sent to " . $config['smtp_user'] . "\n";
        } else {
            echo "FAILURE: Could not send email.\n";
            echo strip_tags($this->email->print_debugger());
        }
    }
}
