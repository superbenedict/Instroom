<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Pagination $pagination
 * @property Influencer_model $Influencer_model
 * @property Activity_log_model $Activity_log_model
 * @property CI_Session $session
 * @property CI_Input $input
 * @property CI_Upload $upload
 * @property CI_Loader $load
 */
class Influencer extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('Influencer_model');
        $this->load->model('Activity_log_model');
        
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
    }

    public function index() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role') ?? 'user';
        
        $filters = array(
            'search' => $this->input->get('search'),
            'platform' => $this->input->get('platform'),
            'niche' => $this->input->get('niche'),
            'status' => $this->input->get('status')
        );

        // Pagination Config
        $this->load->library('pagination');
        $config['base_url'] = base_url('influencer/index');
        $config['total_rows'] = $this->Influencer_model->count_influencers($filters);
        $config['per_page'] = 10;
        $config['reuse_query_string'] = TRUE;
        $config['page_query_string'] = TRUE;
        
        $config['full_tag_open'] = '<div class="flex space-x-2">';
        $config['full_tag_close'] = '</div>';
        $config['attributes'] = array('class' => 'px-3 py-1 rounded-lg border border-gray-200 bg-white text-xs font-medium text-gray-600 hover:bg-gray-50');
        $config['cur_tag_open'] = '<span class="px-3 py-1 rounded-lg border border-gray-200 bg-gray-100 text-xs font-medium text-gray-800">';
        $config['cur_tag_close'] = '</span>';
        
        $this->pagination->initialize($config);

        $page = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $data['influencers'] = $this->Influencer_model->get_influencers($filters, $config['per_page'], $page);
        $data['pagination'] = $this->pagination->create_links();
        $data['total_rows'] = $config['total_rows'];
        $data['active_count'] = $this->Influencer_model->count_influencers(['status' => 'Active']);
        $data['start_index'] = ($config['total_rows'] > 0) ? $page + 1 : 0;
        $data['end_index'] = min($page + $config['per_page'], $config['total_rows']);
        
        $this->load->view('influencer/manage', $data);
    }

    public function pipeline() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role') ?? 'user';
        $this->load->view('influencer/pipeline', $data);
    }

    public function fetch_pipeline() {
        $pipeline_stages = ['For Outreach', 'Contacted', 'Replied', 'In - Progress', 'Not Interested'];
        $influencers = $this->Influencer_model->get_influencers_by_pipeline_status($pipeline_stages);
        
        $pipeline = [
            'For Outreach' => [],
            'Contacted' => [],
            'Replied' => [],
            'In - Progress' => [],
            'Not Interested' => []
        ];
        
        foreach ($influencers as $inf) {
            $status = isset($inf->pipeline_status) ? $inf->pipeline_status : '';
            
            if (array_key_exists($status, $pipeline)) {
                $pipeline[$status][] = $inf;
            }
        }
        
        header('Content-Type: application/json');
        echo json_encode($pipeline);
    }

    public function analytics() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role') ?? 'user';
        $data['stats'] = $this->Influencer_model->get_analytics_stats();
        $data['growth_trend'] = $this->Influencer_model->get_influencer_growth_trend(30);
        $data['platforms'] = ['Facebook', 'Instagram', 'TikTok', 'YouTube'];
        $this->load->view('influencer/analytics', $data);
    }

    public function closed_collaborations() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role') ?? 'user';
        $this->load->view('influencer/closed_collaborations', $data);
    }

    public function fetch_closed_collaborations() {
        $closed_stages = ['For Order Creation', 'In-Transit', 'Delivered', 'Posted', 'Campaign Completed'];
        $influencers = $this->Influencer_model->get_influencers_by_pipeline_status($closed_stages);
        
        $pipeline = [
            'For Order Creation' => [],
            'In-Transit' => [],
            'Delivered' => [],
            'Posted' => [],
            'Campaign Completed' => []
        ];
        
        foreach ($influencers as $inf) {
            $status = isset($inf->pipeline_status) ? $inf->pipeline_status : '';
            
            if (array_key_exists($status, $pipeline)) {
                $pipeline[$status][] = $inf;
            }
        }
        
        header('Content-Type: application/json');
        echo json_encode($pipeline);
    }

    public function update_pipeline_stage() {
        $id = $this->input->post('id');
        $new_stage = $this->input->post('stage');
        
        if ($id && $new_stage) {
            // Ensure the stage is valid
            $valid_stages = [
                'For Outreach', 'Contacted', 'Replied', 'In - Progress', 'Not Interested',
                'For Order Creation', 'In-Transit', 'Delivered', 'Posted', 'Campaign Completed'
            ];
            if (in_array($new_stage, $valid_stages)) {
                $update_data = ['pipeline_status' => $new_stage];
                
                // Sync status based on pipeline stage
                if ($new_stage == 'Not Interested') {
                    $update_data['status'] = 'Inactive';
                } else {
                    $update_data['status'] = 'Active';
                }

                if ($this->Influencer_model->update_influencer($id, $update_data)) {
                    echo json_encode(['status' => 'success']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid stage: ' . $new_stage]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid data', 'debug' => $_POST]);
        }
    }

    public function qualify($id) {
        // Move to pipeline by setting pipeline_status
        $result = $this->Influencer_model->update_influencer($id, [
            'status' => 'Active',
            'pipeline_status' => 'For Outreach',
            'assessment' => 'Qualified'
        ]);
        
        if ($result) {
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Qualify Influencer',
                "Qualified influencer ID: $id"
            );
            echo json_encode(['status' => 'success', 'message' => 'Influencer qualified and moved to Pipeline!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to qualify influencer']);
        }
    }

    public function delete($id) {
        $influencer = $this->Influencer_model->get_influencer_by_id($id);
        $username = $influencer ? $influencer->username : 'Unknown';
        
        $this->Influencer_model->delete_influencer($id);
        
        $this->Activity_log_model->log_activity(
            $this->session->userdata('user_id'),
            $this->session->userdata('name'),
            'Delete Influencer',
            "Deleted influencer: $username (ID: $id)"
        );

        $this->session->set_flashdata('success', 'Influencer deleted successfully!');
        redirect('influencer');
    }

    public function delete_selected() {
        $ids = $this->input->post('ids');
        if (!empty($ids)) {
            if (is_string($ids)) {
                $ids = explode(',', $ids);
            }
            $this->Influencer_model->delete_influencers_by_ids($ids);
            
            $count = count($ids);
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Bulk Delete',
                "Deleted $count influencers via bulk action"
            );
        }
        echo json_encode(['status' => 'success']);
    }

    public function bulk_add_pipeline() {
        $ids = $this->input->post('ids');
        $stage = $this->input->post('stage') ? $this->input->post('stage') : 'For Outreach';
        
        if (!empty($ids)) {
            $this->Influencer_model->update_influencers_by_ids($ids, ['pipeline_status' => $stage]);
            
            $count = count($ids);
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Bulk Pipeline Update',
                "Moved $count influencers to pipeline stage: $stage"
            );
            
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No items selected']);
        }
    }

    public function delete_all() {
        $this->Influencer_model->delete_all_influencers();
        
        $this->Activity_log_model->log_activity(
            $this->session->userdata('user_id'),
            $this->session->userdata('name'),
            'Delete All',
            "Deleted ALL influencers from the database"
        );
        
        $this->session->set_flashdata('success', 'All influencers deleted successfully!');
        redirect('influencer');
    }

    public function get_data($id) {
        $data = $this->Influencer_model->get_influencer_by_id($id);
        
        // Enhance data with default values if needed
        if ($data) {
            // Map existing fields to expected frontend names if they differ
            if (!isset($data->engagement_rate) && isset($data->eng_rate)) {
                $data->engagement_rate = $data->eng_rate;
            }
            if (!isset($data->date_added) && isset($data->created_at)) {
                $data->date_added = $data->created_at;
            }
        }
        
        echo json_encode($data);
    }

    public function update_detail_ajax() {
        $id = $this->input->post('id');
        
        if (!$id) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
            return;
        }

        $data = [];
        
        // Direct mapping fields
        $fields = [
            'username', 'followers', 'location', 'niche', 'email',
            'avg_video_views', 'gmv', 'est_post_rate', 'first_name', 'last_name',
            'platform', 'ig_username', 'notes', 'contact_number', 'product_name',
            'order_number', 'product_cost', 'discount_code', 'affiliate_link',
            'shipping_address', 'tracking_link', 'assessment', 'pipeline_status',
            'campaign_type', 'status'
        ];

        foreach ($fields as $field) {
            if ($this->input->post($field) !== null) {
                $data[$field] = $this->input->post($field);
            }
        }

        // Mapped fields
        if ($this->input->post('engagement_rate') !== null) {
            $data['eng_rate'] = $this->input->post('engagement_rate');
        }

        // Logic: If Assessment is Qualified, set Pipeline Status to For Outreach
        if ($this->input->post('assessment') === 'Qualified') {
            $data['pipeline_status'] = 'For Outreach';
        } elseif ($this->input->post('assessment') === 'Not Qualified') {
            $data['pipeline_status'] = '';
        }

        // Handle full name reconstruction if name parts are updated
        if (isset($data['first_name']) || isset($data['last_name'])) {
            $current = $this->Influencer_model->get_influencer_by_id($id);
            if ($current) {
                $f_name = isset($data['first_name']) ? $data['first_name'] : $current->first_name;
                $l_name = isset($data['last_name']) ? $data['last_name'] : $current->last_name;
                $data['full_name'] = trim($f_name . ' ' . $l_name);
            }
        }

        $result = $this->Influencer_model->update_influencer($id, $data);
        if ($result) {
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Update Detail',
                "Updated details for influencer ID: $id"
            );
            echo json_encode(['status' => 'success', 'message' => 'Influencer updated successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
        }
    }

    public function update_assessment_ajax() {
        $id = $this->input->post('id');
        $assessment = $this->input->post('assessment');
        $notes = $this->input->post('notes');
        
        if ($id && $assessment) {
            $data = ['assessment' => $assessment];
            
            // Logic: If Assessment is Qualified, set Pipeline Status to For Outreach
            // If Assessment is Not Qualified, remove from pipeline (clear status)
            if ($assessment === 'Qualified') {
                $data['pipeline_status'] = 'For Outreach';
            } elseif ($assessment === 'Not Qualified') {
                $data['pipeline_status'] = '';
            }
            
            // If notes provided, update them
            if ($notes !== null) {
                $data['notes'] = $notes;
            }

            $result = $this->Influencer_model->update_influencer($id, $data);
            
            if ($result) {
                $this->Activity_log_model->log_activity(
                    $this->session->userdata('user_id'),
                    $this->session->userdata('name'),
                    'Update Assessment',
                    "Updated assessment to '$assessment' for influencer ID: $id"
                );
                echo json_encode(['status' => 'success', 'message' => 'Assessment updated']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
        }
    }

    public function update() {
        $id = $this->input->post('id');
        $platform = $this->input->post('platform');
        
        $data = array(
            'username' => $this->input->post('username'),
            'followers' => $this->input->post('followers'),
            'eng_rate' => $this->input->post('engagement_rate'), // Mapped to eng_rate
            'location' => $this->input->post('location'),
            'niche' => $this->input->post('niche'),
            'status' => $this->input->post('status') ? $this->input->post('status') : 'Active'
        );

        // Add platform specific fields
        if ($platform == 'TikTok') {
             $data['avg_video_views'] = $this->input->post('avg_video_views');
             $data['gmv'] = $this->input->post('gmv');
             $data['est_post_rate'] = $this->input->post('est_post_rate');
        } 
        
        // Add common optional fields
        if ($this->input->post('full_name')) $data['full_name'] = $this->input->post('full_name');
        if ($this->input->post('email')) $data['email'] = $this->input->post('email');
        if ($this->input->post('contact_info')) $data['contact_info'] = $this->input->post('contact_info');
        if ($this->input->post('first_name')) $data['first_name'] = $this->input->post('first_name');
        if ($this->input->post('last_name')) $data['last_name'] = $this->input->post('last_name');
        if ($this->input->post('notes')) $data['notes'] = $this->input->post('notes');

        $this->Influencer_model->update_influencer($id, $data);
        
        $this->Activity_log_model->log_activity(
            $this->session->userdata('user_id'),
            $this->session->userdata('name'),
            'Update Influencer',
            "Updated influencer with ID: $id"
        );

        $this->session->set_flashdata('success', 'Influencer updated successfully!');
        redirect('influencer');
    }


    public function save_manual() {
        $id = $this->input->post('id');
        $data = array(
            'platform' => $this->input->post('platform'),
            'username' => $this->input->post('username'),
            'contact_info' => $this->input->post('contact_info'),
            'first_name' => $this->input->post('first_name'),
            'last_name' => $this->input->post('last_name'),
            'followers' => $this->input->post('followers'),
            'eng_rate' => $this->input->post('engagement_rate'), // Mapped to eng_rate
            'location' => $this->input->post('location'),
            'niche' => $this->input->post('niche'),
            'notes' => $this->input->post('notes'),
            'assessment' => $this->input->post('assessment'),
            'status' => 'Active', // Default status
        );

        // Logic: If Assessment is Qualified, set Pipeline Status to For Outreach
        if ($this->input->post('assessment') === 'Qualified') {
            $data['pipeline_status'] = 'For Outreach';
        }

        if ($this->input->post('platform') == 'TikTok') {
            $data['avg_video_views'] = $this->input->post('avg_video_views');
            $data['gmv'] = $this->input->post('gmv');
            $data['est_post_rate'] = $this->input->post('est_post_rate');
        }
        
        // Construct full name if not provided but first/last are
        if ($this->input->post('first_name') || $this->input->post('last_name')) {
            $data['full_name'] = trim($this->input->post('first_name') . ' ' . $this->input->post('last_name'));
        }

        if ($id) {
            $this->Influencer_model->update_influencer($id, $data);
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Edit Influencer',
                "Edited influencer (Manual): " . $data['username'] . " (" . $data['platform'] . ")"
            );
        } else {
            // For new records, ensure pipeline_status is empty if not set (i.e. not Qualified)
            if (!isset($data['pipeline_status'])) {
                $data['pipeline_status'] = '';
            }
            $data['created_at'] = date('Y-m-d H:i:s'); // Mapped to created_at
            $this->Influencer_model->insert_influencer($data);

            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Add Influencer',
                "Added new influencer (Manual): " . $data['username'] . " (" . $data['platform'] . ")"
            );
        }
        $this->session->set_flashdata('success', 'Influencer saved successfully!');
        redirect('influencer');
    }

    public function save_instagram() {
        $id = $this->input->post('id');
        $data = array(
            'platform' => 'Instagram',
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'full_name' => $this->input->post('full_name'),
            'followers' => $this->input->post('followers'),
            'eng_rate' => $this->input->post('engagement_rate'), // Mapped to eng_rate
            'location' => $this->input->post('location'),
            'niche' => $this->input->post('niche'),
            'status' => 'Active',
        );

        if ($id) {
            $this->Influencer_model->update_influencer($id, $data);
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Edit Instagram Influencer',
                "Edited Instagram influencer: " . $data['username']
            );
        } else {
            // New Instagram influencers start with no pipeline status
            $data['pipeline_status'] = '';
            $data['created_at'] = date('Y-m-d H:i:s'); // Mapped to created_at
            $this->Influencer_model->insert_influencer($data);
            
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Add Instagram Influencer',
                "Added new Instagram influencer: " . $data['username']
            );
        }
        $this->session->set_flashdata('success', 'Instagram influencer saved successfully!');
        redirect('influencer');
    }

    public function save_tiktok() {
        $id = $this->input->post('id');
        $data = array(
            'platform' => 'TikTok',
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'full_name' => $this->input->post('full_name'),
            'followers' => $this->input->post('followers'),
            'eng_rate' => $this->input->post('engagement_rate'), // Mapped to eng_rate
            'avg_video_views' => $this->input->post('avg_video_views'),
            'gmv' => $this->input->post('gmv'),
            'est_post_rate' => $this->input->post('est_post_rate'),
            'location' => $this->input->post('location'),
            'niche' => $this->input->post('niche'),
            'status' => 'Active',
        );

        if ($id) {
            $this->Influencer_model->update_influencer($id, $data);
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Edit TikTok Influencer',
                "Edited TikTok influencer: " . $data['username']
            );
        } else {
            // New TikTok influencers start with no pipeline status
            $data['pipeline_status'] = '';
            $data['created_at'] = date('Y-m-d H:i:s'); // Mapped to created_at
            $new_id = $this->Influencer_model->insert_influencer($data);
            
            $this->Activity_log_model->log_activity(
                $this->session->userdata('user_id'),
                $this->session->userdata('name'),
                'Add TikTok Influencer',
                "Added new TikTok influencer: " . $data['username']
            );
        }
        $this->session->set_flashdata('success', 'TikTok influencer saved successfully!');
        redirect('influencer');
    }

    public function import_csv() {
        if (isset($_FILES['file']['name'])) {
            $path = './uploads/';
            if (!is_dir($path)) {
                mkdir($path, 0777, true);
            }

            $config['upload_path'] = $path;
            $config['allowed_types'] = 'csv';
            $config['max_size'] = 10000;

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('file')) {
                $file_data = $this->upload->data();
                $file_path = $path . $file_data['file_name'];

                $csv_data = array_map('str_getcsv', file($file_path));
                $header = array_shift($csv_data); // Remove header

                $insert_data = [];
                foreach ($csv_data as $row) {
                    // Assuming CSV columns: Platform, Username, Followers, Eng Rate, Niche, Email, Location
                    if (count($row) >= 2) {
                         $insert_data[] = array(
                            'platform' => isset($row[0]) ? $row[0] : 'Unknown',
                            'username' => isset($row[1]) ? $row[1] : '',
                            'followers' => isset($row[2]) ? $row[2] : 0,
                            'eng_rate' => isset($row[3]) ? $row[3] : 0,
                            'niche' => isset($row[4]) ? $row[4] : '',
                            'email' => isset($row[5]) ? $row[5] : '',
                            'location' => isset($row[6]) ? $row[6] : '',
                            'status' => 'Active',
                            'pipeline_status' => '', // Imported influencers start with no pipeline status
                            'created_at' => date('Y-m-d H:i:s')
                        );
                    }
                }

                if (!empty($insert_data)) {
                    $this->Influencer_model->insert_batch_influencers($insert_data);
                    
                    $count = count($insert_data);
                    $this->Activity_log_model->log_activity(
                        $this->session->userdata('user_id'),
                        $this->session->userdata('name'),
                        'CSV Import',
                        "Imported $count influencers via CSV"
                    );

                    $this->session->set_flashdata('success', 'CSV imported successfully!');
                } else {
                    $this->session->set_flashdata('error', 'No valid data found in CSV.');
                }
                
                unlink($file_path); // Delete file after import
            } else {
                $this->session->set_flashdata('error', 'File upload failed.');
            }
        }
        redirect('influencer');
    }

    public function download_template() {
        $filename = 'influencer_import_template.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");
        
        $file = fopen('php://output', 'w');
        $header = array("Platform", "Username", "Followers", "Engagement Rate", "Niche", "Email", "Location");
        fputcsv($file, $header);
        fclose($file);
        exit;
    }

    public function export_csv() {
        $filename = 'influencer_export_' . date('Ymd') . '.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");
        
        $file = fopen('php://output', 'w');
        $header = array("ID", "Platform", "Username", "Full Name", "Followers", "Engagement Rate", "Niche", "Email", "Location", "Status", "Pipeline Status", "Date Added");
        fputcsv($file, $header);
        
        // Get filters from GET request
        $filters = array(
            'search' => $this->input->get('search'),
            'platform' => $this->input->get('platform'),
            'niche' => $this->input->get('niche'),
            'status' => $this->input->get('status')
        );

        // Get influencers based on filters (no limit)
        $influencers = $this->Influencer_model->get_influencers($filters);
        
        foreach ($influencers as $inf) {
            $line = array(
                $inf->id,
                isset($inf->platform) ? $inf->platform : '',
                isset($inf->username) ? $inf->username : '',
                isset($inf->full_name) ? $inf->full_name : '',
                isset($inf->followers) ? $inf->followers : 0,
                isset($inf->eng_rate) ? $inf->eng_rate : 0,
                isset($inf->niche) ? $inf->niche : '',
                isset($inf->email) ? $inf->email : '',
                isset($inf->location) ? $inf->location : '',
                isset($inf->status) ? $inf->status : '',
                isset($inf->pipeline_status) ? $inf->pipeline_status : '',
                isset($inf->created_at) ? $inf->created_at : ''
            );
            fputcsv($file, $line);
        }
        
        fclose($file);
        exit;
    }

    public function export_selected_csv() {
        $ids = $this->input->post('ids');
        if (empty($ids)) {
            $this->session->set_flashdata('error', 'No items selected for export.');
            redirect('influencer');
        }

        if (is_string($ids)) {
            $ids = explode(',', $ids);
        }

        $filename = 'influencer_export_selected_' . date('Ymd') . '.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");
        
        $file = fopen('php://output', 'w');
        $header = array("ID", "Platform", "Username", "Full Name", "Followers", "Engagement Rate", "Niche", "Email", "Location", "Status", "Pipeline Status", "Date Added");
        fputcsv($file, $header);
        
        // Fetch specific influencers
        // We need a method to get by IDs. 
        // We can use get_influencers loop or add a method. 
        // For efficiency, let's just fetch all and filter or add a method.
        // Actually, Influencer_model doesn't have get_by_ids.
        // Let's iterate for now or query manually.
        
        // Better: Use a loop since we don't have a bulk get method ready and IDs shouldn't be too many.
        // OR add a temporary filter 'ids' to get_influencers if supported? No.
        
        // Fetch specific influencers using model
        $influencers = $this->Influencer_model->get_influencers_by_ids($ids);

        foreach ($influencers as $inf) {
            $line = array(
                $inf->id,
                isset($inf->platform) ? $inf->platform : '',
                isset($inf->username) ? $inf->username : '',
                isset($inf->full_name) ? $inf->full_name : '',
                isset($inf->followers) ? $inf->followers : 0,
                isset($inf->eng_rate) ? $inf->eng_rate : 0,
                isset($inf->niche) ? $inf->niche : '',
                isset($inf->email) ? $inf->email : '',
                isset($inf->location) ? $inf->location : '',
                isset($inf->status) ? $inf->status : '',
                isset($inf->pipeline_status) ? $inf->pipeline_status : '',
                isset($inf->created_at) ? $inf->created_at : ''
            );
            fputcsv($file, $line);
        }
        
        fclose($file);
        exit;
    }

}
