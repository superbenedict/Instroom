<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property Campaign_model $Campaign_model
 * @property User_model $User_model
 */
class Manager extends Manager_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('Campaign_model');
        $this->load->model('User_model');
    }

    public function index() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $this->load->view('manager/dashboard', $data);
    }

    public function campaign_planning() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['active_section'] = 'campaign_planning';
        
        // Fetch employees for assignment
        $data['employees'] = $this->User_model->get_all_users(); // Filter in view if needed
        $data['campaigns'] = $this->Campaign_model->get_all_campaigns();

        $this->load->view('manager/dashboard', $data);
    }

    public function save_campaign() {
        $goals = $this->input->post('goals');
        $sales_target = $this->input->post('sales_target');
        $conversion_rate = $this->input->post('conversion_rate');
        $budget = $this->input->post('budget');
        $assigned_employees = $this->input->post('assigned_employees'); // Array of IDs

        $campaign_data = [
            'goals' => $goals,
            'sales_target' => $sales_target,
            'conversion_rate' => $conversion_rate,
            'budget' => $budget,
            'status' => 'active',
            'created_by' => $this->session->userdata('user_id')
        ];

        $campaign_id = $this->Campaign_model->create_campaign($campaign_data);

        if ($campaign_id && !empty($assigned_employees)) {
            foreach ($assigned_employees as $emp_id) {
                $this->Campaign_model->assign_employee($campaign_id, $emp_id);
            }
        }

        $this->session->set_flashdata('success', 'Campaign created successfully!');
        redirect('manager/campaign_planning');
    }

    public function influencer_review() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['active_section'] = 'influencer_review';
        $this->load->view('manager/dashboard', $data);
    }

    public function orders_discounts() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['active_section'] = 'orders_discounts';
        $this->load->view('manager/dashboard', $data);
    }

    public function performance() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['active_section'] = 'performance';
        $this->load->view('manager/dashboard', $data);
    }

    public function reports() {
        $data['user_name'] = $this->session->userdata('name');
        $data['user_role'] = $this->session->userdata('role');
        $data['active_section'] = 'reports';
        $this->load->view('manager/dashboard', $data);
    }
}
