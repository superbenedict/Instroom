<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property Influencer_model $Influencer_model
 * @property CI_Session $session
 * @property CI_Input $input
 * @property CI_DB_query_builder $db
 * @property CI_Cache $cache
 */
class Discovery extends CI_Controller {

    private $youtube_api_key;
    private $fb_access_token;
    private $ig_business_id;
    private $google_search_engine_id;
    private $tiktok_rapidapi_key;
    private $user_id;
    private $user_role;
    private $user_name;
    private $user_email;
    private $api_mode; // 'live' or 'mock'

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('Influencer_model');
        $this->load->library('form_validation');
        $this->load->database();
        $this->load->driver('cache', array('adapter' => 'file'));

        // Load .env manually if getenv fails (common in local setups without phpdotenv)
        $this->_load_env();

        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $this->user_id = $this->session->userdata('user_id');
        $this->user_role = $this->session->userdata('role');
        $this->user_name = $this->session->userdata('name');
        $this->user_email = $this->session->userdata('email');
        
        // Try to get key from environment first (more secure), then config fallback
        $this->youtube_api_key = getenv('YOUTUBE_API_KEY') ?: config_item('youtube_api_key');
        
        // Facebook/Instagram Graph API
        $this->fb_access_token = getenv('FACEBOOK_ACCESS_TOKEN');
        $this->ig_business_id = getenv('IG_BUSINESS_ACCOUNT_ID');
        
        // Google Custom Search
        $this->google_search_engine_id = getenv('GOOGLE_SEARCH_ENGINE_ID');

        // TikTok RapidAPI
        $this->tiktok_rapidapi_key = getenv('TIKTOK_RAPIDAPI_KEY');

        // Determine mode based on available keys
        $this->api_mode = ($this->youtube_api_key || $this->fb_access_token || $this->tiktok_rapidapi_key) ? 'live' : 'mock';
    }

    public function index() {
        $data['user_name'] = $this->user_name;
        $data['user_role'] = $this->user_role;
        $data['user_email'] = $this->user_email;
        $data['api_mode'] = $this->api_mode;
        $data['results'] = [];
        $data['searched'] = false;
        
        // Fetch Recent Searches
        $this->db->select('keyword, platform');
        $this->db->where('user_id', $this->user_id);
        $this->db->group_by('keyword'); // Distinct keywords
        $this->db->order_by('MAX(created_at)', 'DESC');
        $this->db->limit(5);
        $recent_query = $this->db->get('search_history');
        $data['recent_searches'] = $recent_query->result_array();

        // Fetch Trending/Recommended Searches (Top searched by all users)
        $this->db->select('keyword, COUNT(*) as count');
        $this->db->group_by('keyword');
        $this->db->order_by('count', 'DESC');
        $this->db->limit(5);
        $trending_query = $this->db->get('search_history');
        $recommended = $trending_query->result_array();

        // Fallback for Recommended if empty
        if (empty($recommended)) {
            $recommended = [
                ['keyword' => '#MinimalistStyle'],
                ['keyword' => '#WellnessJourney'],
                ['keyword' => '#HandmadeWithLove'],
                ['keyword' => '#TravelVlog'],
                ['keyword' => '#FoodieLife']
            ];
        }
        $data['recommended_searches'] = $recommended;

        $this->load->view('discovery/index', $data);
    }

    public function search() {
        $platform = $this->input->post('platform');
        $keyword = $this->input->post('keyword');
        $min_followers = $this->input->post('min_followers');
        $max_followers = $this->input->post('max_followers');
        $location = $this->input->post('location');
        $min_engagement = $this->input->post('min_engagement');
        $has_email = $this->input->post('has_email');
        $gender = $this->input->post('gender');
        $exclude_saved = $this->input->post('exclude_saved');

        // Log Search
        if ($keyword) {
            $this->_log_search($keyword, $platform);
        }

        // Prepare Saved List for Exclusion
        $saved_map = [];
        if ($exclude_saved === 'true' || $exclude_saved === '1') {
             $query = $this->db->query("
                SELECT ia.username, ia.platform 
                FROM influencer_accounts ia 
                JOIN collaborations c ON c.account_id = ia.id
             ");
             foreach($query->result() as $row) {
                 $saved_map[$row->platform . ':' . strtolower($row->username)] = true;
             }
        }

        $results = [];
        $data['warning'] = ''; // Initialize warning

        if ($platform === 'youtube') {
            if ($this->youtube_api_key) {
                $results = $this->_search_youtube($keyword);
            } else {
                $results = [];
                $data['error'] = 'YouTube API key is not configured. Set YOUTUBE_API_KEY to enable live results.';
            }
        } elseif ($platform === 'instagram') {
            // Priority 1: Graph API (Direct Lookup or Hashtag Search if enabled)
            if ($this->fb_access_token) {
                $results = $this->_search_instagram($keyword);
            }
            
            // Priority 2: Google Custom Search (Complementary)
            // Use for niche keywords or when Graph API yields few results
            if ($this->google_search_engine_id && $this->youtube_api_key) {
                 // Check if we already found an exact match (username lookup)
                 $clean_key = str_replace('@', '', trim($keyword));
                 $is_exact_match = (count($results) === 1 && strtolower($results[0]['username']) === strtolower($clean_key));
                 
                 // If not an exact match, or if we want more results, use Google
                 if (!$is_exact_match) {
                     $cse_results = $this->_search_google_custom($keyword, 'instagram');
                     
                     if (!empty($cse_results)) {
                         // Merge and deduplicate based on username
                         $existing_usernames = array_map(function($r) { return strtolower($r['username']); }, $results);
                         
                         foreach ($cse_results as $cse_row) {
                             if (!in_array(strtolower($cse_row['username']), $existing_usernames)) {
                                 $results[] = $cse_row;
                                 $existing_usernames[] = strtolower($cse_row['username']);
                             }
                         }
                         $data['warning'] = ''; // Clear warning if Google found results
                     }
                 }
            }

            if (empty($results)) {
                 if (!$this->fb_access_token && !$this->google_search_engine_id) {
                     log_message('error', 'Discovery: No FB Access Token and No Google CSE ID found');
                     $results = [];
                     $data['warning'] = 'Instagram Graph API token not configured. Please check your .env file.';
                 } else if (empty($data['warning'])) {
                     $results = [];
                     $data['warning'] = "No results found for '$keyword'.";
                 }
            }
        } elseif ($platform === 'tiktok') {
            if ($this->tiktok_rapidapi_key) {
                $results = $this->_search_tiktok($keyword);
                if (empty($results)) {
                    $data['warning'] = "No results found on TikTok for '$keyword'.";
                }
            } else {
                // Live Mode Enforced: No Mock Data
                $results = [];
                $data['warning'] = 'TikTok API Key (TIKTOK_RAPIDAPI_KEY) is missing. Please configure your .env file to enable live search.';
            }
        } else {
            // Live results only for supported platforms
            $results = [];
            $data['warning'] = 'Live results currently supported for YouTube, Instagram, and TikTok only.';
        }

        // POST-SEARCH FILTERING
        // Since APIs don't support deep filtering, we filter the results array
        if ($min_followers || $max_followers || $location || $min_engagement || $has_email || ($exclude_saved === 'true' || $exclude_saved === '1') || ($gender && $gender !== 'any')) {
            $results = array_filter($results, function($item) use ($min_followers, $max_followers, $location, $min_engagement, $has_email, $saved_map, $exclude_saved, $gender) {
                // 0. Exclude Saved
                if ($exclude_saved === 'true' || $exclude_saved === '1') {
                    $key = $item['platform'] . ':' . strtolower($item['username']);
                    if (isset($saved_map[$key])) return false;
                }

                // 1. Followers Filter
                $followers = $item['followers'];
                if ($min_followers && $followers < $min_followers) return false;
                if ($max_followers && $followers > $max_followers) return false;

                // 2. Location Filter (Loose match)
                if ($location) {
                    $item_loc = isset($item['location']) ? strtolower($item['location']) : '';
                    $item_bio = isset($item['notes']) ? strtolower($item['notes']) : '';
                    $search_loc = strtolower($location);
                    
                    if (strpos($item_loc, $search_loc) === false && strpos($item_bio, $search_loc) === false) {
                        return false;
                    }
                }

                // 3. Engagement Rate Filter
                if ($min_engagement) {
                    $rate_str = isset($item['eng_rate']) ? $item['eng_rate'] : '0';
                    $rate = floatval(str_replace('%', '', $rate_str));
                    if ($rate < floatval($min_engagement)) return false;
                }

                // 4. Email Filter
                if ($has_email !== '' && $has_email !== null) {
                    $bio = isset($item['notes']) ? $item['notes'] : '';
                    $contact = isset($item['profile_url']) ? $item['profile_url'] : ''; // Assuming contact info might be here or we check bio
                    // Simple email regex check in bio/notes
                    $has_email_in_bio = (preg_match('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $bio));
                    
                    if ($has_email == '1' && !$has_email_in_bio) return false;
                    if ($has_email == '0' && $has_email_in_bio) return false;
                }

                // 5. Gender Filter (Experimental - Keyword based)
                if ($gender && $gender !== 'any') {
                    // This is very loose as APIs rarely return gender.
                    // We can check bio for pronouns or specific keywords if available.
                    // For now, we'll check the 'notes' (bio) for pronouns.
                    $bio = isset($item['notes']) ? strtolower($item['notes']) : '';
                    
                    $male_keywords = [' he ', ' him ', ' his ', ' dad ', ' father ', ' boy ', ' man ', ' husband '];
                    $female_keywords = [' she ', ' her ', ' hers ', ' mom ', ' mother ', ' girl ', ' woman ', ' wife '];
                    
                    $is_male = false;
                    $is_female = false;
                    
                    foreach ($male_keywords as $k) { if (strpos($bio, $k) !== false) $is_male = true; }
                    foreach ($female_keywords as $k) { if (strpos($bio, $k) !== false) $is_female = true; }
                    
                    if ($gender == 'male' && !$is_male) return false; // Strict: must have male keywords
                    if ($gender == 'female' && !$is_female) return false; // Strict: must have female keywords
                    
                    // Note: This is highly inaccurate and should be used with caution or labeled as beta.
                    // If no keywords found, we might want to keep it or exclude it. 
                    // Current logic: Exclude if keywords not found.
                }

                return true;
            });
        }

        $data['user_name'] = $this->user_name;
        $data['user_role'] = $this->user_role;
        $data['user_email'] = $this->user_email;
        $data['results'] = $results;
        $data['searched'] = true;
        $data['search_params'] = [
            'platform' => $platform,
            'keyword' => $keyword,
            'min_followers' => $min_followers,
            'max_followers' => $max_followers,
            'location' => $location,
            'min_engagement' => $min_engagement,
            'has_email' => $has_email,
            'gender' => $gender,
            'exclude_saved' => $exclude_saved
        ];
        $data['api_mode'] = $this->api_mode;

        $this->load->view('discovery/results', $data);
    }

    public function add() {
        if (!$this->input->is_ajax_request()) {
            show_404();
        }

        $data = [
            'platform' => $this->input->post('platform'),
            'username' => $this->input->post('username'),
            'full_name' => $this->input->post('full_name'), // Map to name
            'profile_image' => $this->input->post('profile_image'),
            'followers' => $this->input->post('followers'),
            'niche' => $this->input->post('niche'),
            'avg_video_views' => $this->input->post('avg_video_views'),
            'eng_rate' => $this->input->post('eng_rate'),
            'location' => $this->input->post('location'),
            'notes' => $this->input->post('notes'),
            'contact_info' => $this->input->post('profile_url'), // Map profile_url to contact_info
            'status' => 'Active', // Added to main list immediately
            'pipeline_status' => '', // Not in pipeline yet (wait for qualification)
            'created_by' => $this->user_id,
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Check if ALREADY IN LIST (Collaboration exists)
        // First get account ID if exists
        $this->db->where('username', $data['username']);
        $this->db->where('platform', $data['platform']);
        $account_query = $this->db->get('influencer_accounts');

        if ($account_query->num_rows() > 0) {
            $account = $account_query->row();
            
            // Check if any collaboration exists for this account
            $this->db->where('account_id', $account->id);
            $collab_exists = $this->db->count_all_results('collaborations');
            
            if ($collab_exists > 0) {
                echo json_encode(['status' => 'error', 'message' => 'Influencer already in your list!']);
                return;
            }
            // If account exists but no collaboration, proceed to add (Fixes "zombie account" issue)
        }

        // Insert into main 3-table structure so it appears in Influencer List
        $insert_id = $this->Influencer_model->insert_influencer($data);

        if ($insert_id) {
            echo json_encode(['status' => 'success', 'message' => 'Influencer added successfully!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add influencer.']);
        }
    }

    private function _search_instagram($keyword) {
        $this->_load_env();
        
        // Requirements
        $access_token = $this->fb_access_token;
        $ig_business_id = $this->ig_business_id;

        if (!$access_token || !$ig_business_id || $ig_business_id === 'YOUR_IG_BUSINESS_ID') {
             log_message('error', 'Facebook Graph API credentials missing. Check .env');
             return [];
        }

        // Clean keyword
        $keyword = trim($keyword);
        $is_hashtag = (strpos($keyword, '#') === 0);
        $clean_keyword = str_replace(['@', '#', ' '], '', $keyword);
        $clean_keyword_lower = strtolower($clean_keyword);

        $results = [];

        // STRATEGY 1: If it looks like a username (starts with @) or user explicitly wants user lookup
        // Try Direct Business Discovery Lookup
        if (!$is_hashtag) {
            $user_result = $this->_instagram_username_lookup($clean_keyword_lower, $ig_business_id, $access_token);
            if (!empty($user_result)) {
                $results[] = $user_result;
            }
        }

        // STRATEGY 2: If no user found OR it is a hashtag search, try Hashtag Search API
        if (empty($results)) {
            $hashtag_results = $this->_instagram_hashtag_search($clean_keyword, $ig_business_id, $access_token);
            if (!empty($hashtag_results)) {
                $results = array_merge($results, $hashtag_results);
            }
        }

        return $results;
    }

    private function _instagram_username_lookup($username, $ig_business_id, $access_token) {
        // Endpoint: Business Discovery
        // Added media fields to fetch recent posts for the Peek view
        $fields = "business_discovery.username($username){username,website,name,ig_id,id,profile_picture_url,biography,follows_count,followers_count,media_count,media{caption,media_url,media_type,like_count,comments_count,timestamp,permalink,thumbnail_url}}";
        $url = "https://graph.facebook.com/v18.0/{$ig_business_id}?fields=" . urlencode($fields) . "&access_token=" . $access_token;

        $response = $this->_make_api_request($url);

        if ($response === FALSE) return null;

        $data = json_decode($response, true);
        
        if (isset($data['error']) || !isset($data['business_discovery'])) {
            return null;
        }

        $u = $data['business_discovery'];
        
        // Process Media Data if available
        $recent_media = [];
        if (isset($u['media']['data'])) {
            foreach ($u['media']['data'] as $m) {
                // Determine image URL: thumbnail_url for VIDEO, media_url for IMAGE/CAROUSEL
                $image_url = isset($m['thumbnail_url']) ? $m['thumbnail_url'] : (isset($m['media_url']) ? $m['media_url'] : '');
                
                $recent_media[] = [
                    'caption' => isset($m['caption']) ? $m['caption'] : '',
                    'media_url' => $image_url, // Used for display
                    'media_type' => isset($m['media_type']) ? $m['media_type'] : 'IMAGE',
                    'likes' => isset($m['like_count']) ? $m['like_count'] : 0,
                    'comments' => isset($m['comments_count']) ? $m['comments_count'] : 0,
                    'timestamp' => isset($m['timestamp']) ? $m['timestamp'] : '',
                    'permalink' => isset($m['permalink']) ? $m['permalink'] : ''
                ];
            }
        }

        return [
            'platform' => 'instagram',
            'platform_id' => isset($u['id']) ? $u['id'] : '',
            'username' => isset($u['username']) ? $u['username'] : $username,
            'full_name' => isset($u['name']) ? $u['name'] : '',
            'profile_image' => isset($u['profile_picture_url']) ? $u['profile_picture_url'] : '',
            'followers' => isset($u['followers_count']) ? $u['followers_count'] : 0,
            'following' => isset($u['follows_count']) ? $u['follows_count'] : 0,
            'posts_count' => isset($u['media_count']) ? $u['media_count'] : 0,
            'eng_rate' => $this->_calculate_engagement($u), // Estimate
            'bio' => isset($u['biography']) ? $u['biography'] : '',
            'website' => isset($u['website']) ? $u['website'] : '',
            'is_verified' => false,
            'recent_media' => $recent_media, // Pass media data
            'notes' => 'Direct Lookup via Instagram Graph API',
            'profile_url' => "https://instagram.com/" . (isset($u['username']) ? $u['username'] : $username)
        ];
    }

    private function _instagram_hashtag_search($hashtag, $ig_business_id, $access_token) {
        // Step 1: Get Hashtag ID
        $url = "https://graph.facebook.com/v18.0/ig_hashtag_search?user_id={$ig_business_id}&q=" . urlencode($hashtag) . "&access_token=" . $access_token;
        $response = $this->_make_api_request($url);
        
        if ($response === FALSE) {
            log_message('error', 'IG Hashtag Search Request Failed');
            return [];
        }

        $data = json_decode($response, true);

        if (isset($data['error'])) {
            log_message('error', 'IG Hashtag Search API Error: ' . json_encode($data['error']));
            return [];
        }

        if (!isset($data['data'][0]['id'])) return [];
        
        $hashtag_id = $data['data'][0]['id'];

        // Step 2: Get Top Media for Hashtag
        // We need fields: caption, permalink
        $url = "https://graph.facebook.com/v18.0/{$hashtag_id}/top_media?user_id={$ig_business_id}&fields=caption,permalink,media_type&access_token=" . $access_token . "&limit=20";
        
        $response = $this->_make_api_request($url);
        if ($response === FALSE) return [];
        
        $data = json_decode($response, true);
        
        if (!isset($data['data'])) return [];

        // Step 3: Extract Mentions from Captions
        $potential_users = [];
        
        foreach ($data['data'] as $media) {
            if (isset($media['caption'])) {
                // Regex to find @mentions
                preg_match_all('/@([a-zA-Z0-9_.]+)/', $media['caption'], $matches);
                if (!empty($matches[1])) {
                    foreach ($matches[1] as $username) {
                        $username = strtolower(trim($username));
                        // Filter out self-referencing if possible (not possible without knowing owner)
                        // Filter out common spam words if needed
                        if (strlen($username) > 1 && !in_array($username, $potential_users)) {
                            $potential_users[] = $username;
                        }
                    }
                }
            }
        }

        // Limit to 5 unique users to avoid API rate limits
        $potential_users = array_slice(array_unique($potential_users), 0, 5);
        
        $results = [];
        foreach ($potential_users as $username) {
            $user_data = $this->_instagram_username_lookup($username, $ig_business_id, $access_token);
            if ($user_data) {
                $user_data['notes'] = "Discovered via #$hashtag mention";
                $results[] = $user_data;
            }
        }
        
        return $results;
    }
    
    private function _calculate_engagement($user_data) {
        $followers = isset($user_data['followers_count']) ? $user_data['followers_count'] : 0;
        if ($followers == 0) return '0%';
        
        $total_engagement = 0;
        $count = 0;

        if (isset($user_data['media']['data']) && is_array($user_data['media']['data'])) {
            foreach ($user_data['media']['data'] as $media) {
                $likes = isset($media['like_count']) ? $media['like_count'] : 0;
                $comments = isset($media['comments_count']) ? $media['comments_count'] : 0;
                $total_engagement += ($likes + $comments);
                $count++;
            }
        }

        if ($count == 0) return '0%';

        $avg_engagement = $total_engagement / $count;
        $rate = ($avg_engagement / $followers) * 100;
        
        return number_format($rate, 2) . '%';
    }

    private function _lookup_instagram_username($username) {
        // Reuse search logic as Business Discovery is essentially a lookup
        $results = $this->_search_instagram($username);
        return !empty($results) ? $results[0] : null;
    }

    private function _search_youtube($keyword) {
        // Cache Key Generation
        $cache_key = 'youtube_search_' . md5($keyword);
        
        // Ensure cache library is loaded (just in case)
        if (!isset($this->cache)) {
             $this->load->driver('cache', array('adapter' => 'file'));
        }

        if ($cached_results = $this->cache->get($cache_key)) {
            return $cached_results;
        }

        $url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=" . urlencode($keyword) . "&key=" . $this->youtube_api_key . "&maxResults=10";
        
        $response = $this->_make_api_request($url);
        
        if ($response === FALSE) {
            log_message('error', 'YouTube API Request Failed (cURL error or empty response)');
            return [];
        }

        $data = json_decode($response, true);
        
        // Error Handling for Quota/Permission
        if (isset($data['error'])) {
            log_message('error', 'YouTube API Error: ' . json_encode($data['error']));
            return []; // Return empty on API error
        }

        $results = [];

        if (isset($data['items'])) {
            foreach ($data['items'] as $item) {
                $channelId = isset($item['snippet']['channelId']) ? $item['snippet']['channelId'] : '';
                if (!$channelId) continue;

                $stats_data = $this->_get_youtube_channel_stats($channelId);

                $results[] = [
                    'platform' => 'youtube',
                    'username' => isset($item['snippet']['channelTitle']) ? $item['snippet']['channelTitle'] : 'Unknown',
                    'full_name' => isset($item['snippet']['title']) ? $item['snippet']['title'] : 'Unknown',
                    'profile_image' => isset($item['snippet']['thumbnails']['default']['url']) ? $item['snippet']['thumbnails']['default']['url'] : '',
                    'followers' => $stats_data['subscribers'],
                    'avg_video_views' => $stats_data['avg_views'],
                    'location' => $stats_data['country'],
                    'notes' => $stats_data['description'],
                    'profile_url' => "https://www.youtube.com/channel/" . $channelId
                ];
            }
        }
        
        // Cache for 1 hour (3600 seconds)
        if (!empty($results)) {
            $this->cache->save($cache_key, $results, 3600);
        }

        return $results;
    }

    private function _get_youtube_channel_stats($channelId) {
        // Ensure cache library is loaded (safety check)
        if (!isset($this->cache)) {
             $this->load->driver('cache', array('adapter' => 'file'));
        }

        // Cache Stats too
        $cache_key = 'youtube_stats_full_' . $channelId;
        if ($cached_stats = $this->cache->get($cache_key)) {
            return $cached_stats;
        }

        $url = "https://www.googleapis.com/youtube/v3/channels?part=statistics,snippet&id=" . $channelId . "&key=" . $this->youtube_api_key;
        $response = $this->_make_api_request($url);
        
        $stats = [
            'subscribers' => 0,
            'avg_views' => 0,
            'country' => '',
            'description' => ''
        ];

        if ($response) {
            $data = json_decode($response, true);
            if (isset($data['items'][0])) {
                $item = $data['items'][0];
                
                // Statistics
                $viewCount = isset($item['statistics']['viewCount']) ? $item['statistics']['viewCount'] : 0;
                $videoCount = isset($item['statistics']['videoCount']) ? $item['statistics']['videoCount'] : 0;
                $stats['subscribers'] = isset($item['statistics']['subscriberCount']) ? $item['statistics']['subscriberCount'] : 0;
                
                // Calculate Avg Views
                if ($videoCount > 0) {
                    $stats['avg_views'] = round($viewCount / $videoCount);
                }

                // Snippet Data
                $stats['country'] = isset($item['snippet']['country']) ? $item['snippet']['country'] : '';
                $stats['description'] = isset($item['snippet']['description']) ? substr($item['snippet']['description'], 0, 200) . '...' : ''; // Truncate
                
                $this->cache->save($cache_key, $stats, 86400); // Cache stats for 24 hours
                return $stats;
            }
        }
        
        // Fallback for failed requests
        // $stats['subscribers'] = 0; // Already initialized to 0
        return $stats;
    }

    private function _search_google_custom($keyword, $platform = 'instagram') {
        $key = $this->youtube_api_key; // Reuse Google API Key
        $cx = $this->google_search_engine_id;
        
        if (!$key || !$cx) return [];

        $q = urlencode($keyword);
        $url = "https://www.googleapis.com/customsearch/v1?key={$key}&cx={$cx}&q={$q}";

        $response = $this->_make_api_request($url);
        if ($response === FALSE) return [];

        $data = json_decode($response, true);
        if (!isset($data['items'])) return [];

        $results = [];
        foreach ($data['items'] as $item) {
            $snippet = isset($item['snippet']) ? $item['snippet'] : '';
            $title = isset($item['title']) ? $item['title'] : '';
            $link = isset($item['link']) ? $item['link'] : '';
            
            // Basic Parsing for Instagram
            // Title format often: "Name (@username) • Instagram photos and videos"
            
            // Extract Username
            $username = '';
            if (preg_match('/@([a-zA-Z0-9_.]+)/', $title, $matches)) {
                $username = $matches[1];
            } elseif (preg_match('/instagram\.com\/([a-zA-Z0-9_.]+)/', $link, $matches)) {
                $username = $matches[1];
            }
            
            if (empty($username) || in_array($username, ['p', 'reel', 'stories', 'explore', 'tags'])) continue; // Skip non-profile links

            // Extract Full Name
            $full_name = '';
            $title_parts = explode('(@', $title);
            if (count($title_parts) > 1) {
                $full_name = trim($title_parts[0]);
            } else {
                $full_name = $username;
            }

            // Extract Followers
            $followers = 0;
            // Look for "X Followers" in snippet
            if (preg_match('/([0-9.,KkMm]+)\s+Followers/', $snippet, $matches)) {
                $followers = $this->_parse_count_string($matches[1]);
            }

            // Image
            $image = '';
            if (isset($item['pagemap']['cse_image'][0]['src'])) {
                $image = $item['pagemap']['cse_image'][0]['src'];
            } else {
                $image = "https://ui-avatars.com/api/?name=" . urlencode($full_name) . "&background=random&color=fff";
            }

            $results[] = [
                'platform' => $platform,
                'platform_id' => '', // Unknown via search
                'username' => $username,
                'full_name' => $full_name,
                'profile_image' => $image,
                'followers' => $followers,
                'eng_rate' => 'N/A', // Not available via search
                'avg_video_views' => 0,
                'location' => '', 
                'notes' => 'Discovered via Google Search: ' . substr($snippet, 0, 100) . '...',
                'profile_url' => $link,
                'is_verified' => false,
                'recent_media' => [] // No media data available
            ];
        }

        return $results;
    }

    private function _search_tiktok($keyword) {
        $cache_key = 'tiktok_search_' . md5($keyword);
        if (!isset($this->cache)) {
             $this->load->driver('cache', array('adapter' => 'file'));
        }

        if ($cached_results = $this->cache->get($cache_key)) {
            return $cached_results;
        }

        // Using TokApi (RapidAPI)
        // Updated Endpoint based on error "API doesn't exists"
        // Trying 'TokApi' endpoint structure which is more reliable
        $url = "https://tokapi-mobile-version.p.rapidapi.com/v1/search/user?keyword=" . urlencode($keyword) . "&count=20";
        $headers = [
            "x-rapidapi-key: " . $this->tiktok_rapidapi_key,
            "x-rapidapi-host: tokapi-mobile-version.p.rapidapi.com"
        ];

        $response = $this->_make_api_request($url, $headers);

        if ($response === FALSE) {
             log_message('error', 'TikTok API Request Failed');
             return [];
        }

        $data = json_decode($response, true);
        
        // DEBUG: Log the raw API response to see why it's failing
        log_message('error', 'TikTok API Response: ' . print_r($data, true));

        // TokApi Response Handling
        // Structure is usually: ['user_list' => [...]] or ['search_user' => [...]]
        
        $users_list = [];
        if (isset($data['user_list'])) {
            $users_list = $data['user_list'];
        } elseif (isset($data['search_user'])) {
             $users_list = $data['search_user'];
        }

        if (empty($users_list)) {
            // Log fallback
            return [];
        }

        $results = [];
        foreach ($users_list as $item) {
             // TokApi structure: user info is inside 'user_info'
             $user = isset($item['user_info']) ? $item['user_info'] : $item;
             
             $results[] = [
                 'platform' => 'tiktok',
                 'username' => isset($user['unique_id']) ? $user['unique_id'] : '',
                 'full_name' => isset($user['nickname']) ? $user['nickname'] : '',
                 'profile_image' => isset($user['avatar_thumb']['url_list'][0]) ? $user['avatar_thumb']['url_list'][0] : (isset($user['avatar_thumb']) ? $user['avatar_thumb'] : ''),
                 'followers' => isset($user['follower_count']) ? $user['follower_count'] : 0,
                 'eng_rate' => 'N/A', 
                 'avg_video_views' => 0, 
                 'location' => isset($user['region']) ? $user['region'] : '',
                 'notes' => isset($user['signature']) ? $user['signature'] : '',
                 'profile_url' => "https://www.tiktok.com/@" . (isset($user['unique_id']) ? $user['unique_id'] : ''),
                 'is_verified' => isset($user['verification_type']) && $user['verification_type'] > 0
             ];
        }

        if (!empty($results)) {
            $this->cache->save($cache_key, $results, 3600);
        }

        return $results;
    }

    private function _parse_count_string($str) {
        $str = str_replace(',', '', strtolower(trim($str)));
        if (strpos($str, 'k') !== false) {
            return floatval($str) * 1000;
        } elseif (strpos($str, 'm') !== false) {
            return floatval($str) * 1000000;
        }
        return floatval($str);
    }

    private function _make_api_request($url, $headers = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For local dev without proper cert bundle
        
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }

        $output = curl_exec($ch);
        
        if (curl_errno($ch)) {
            curl_close($ch);
            return FALSE;
        }
        
        curl_close($ch);
        return $output;
    }

    private function _get_mock_data($platform, $keyword) {
        // Generate deterministic mock data based on keyword
        $mock_results = [];
        $seed = crc32($keyword . $platform);
        srand($seed);

        $limit = 15; // Increase to populate table
        
        $names = ['Sarah', 'John', 'Jessica', 'Mike', 'Emily', 'David', 'Emma', 'Chris', 'Olivia', 'Daniel', 'Sophia', 'James', 'Ava', 'Robert', 'Isabella'];
        $surnames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson'];

        for ($i = 0; $i < $limit; $i++) {
            $followers = rand(5000, 2000000);
            $fname = $names[rand(0, count($names)-1)];
            $lname = $surnames[rand(0, count($surnames)-1)];
            $full_name = $fname . ' ' . $lname;
            
            // Clean keyword for username generation
            $clean_key = preg_replace('/[^a-zA-Z0-9]/', '', $keyword);
            $username = strtolower($clean_key) . '_' . strtolower($fname) . rand(10, 99);
            
            $eng_rate = (rand(10, 80) / 10) . '%';
            
            $base_url = "https://instagram.com/";
            if ($platform === 'youtube') $base_url = "https://youtube.com/@";
            if ($platform === 'tiktok') $base_url = "https://tiktok.com/@";

            $mock_results[] = [
                'platform' => $platform,
                'username' => $username,
                'full_name' => $full_name,
                'profile_image' => "https://ui-avatars.com/api/?name=" . urlencode($full_name) . "&background=random&color=fff",
                'followers' => $followers,
                'eng_rate' => $eng_rate,
                'growth_rate' => (rand(0, 1) ? '+' : '-') . (rand(10, 500) / 100), // Mock Growth Rate
                'avg_video_views' => rand(1000, 500000),
                'location' => 'United States',
                'notes' => 'Mock Data for ' . $keyword,
                'profile_url' => $base_url . $username,
                'is_verified' => (rand(0, 10) > 8) // 20% chance
            ];
        }

        return $mock_results;
    }

    private function _log_search($keyword, $platform) {
        // Simple logging to database
        // Avoid duplicate logging for same keyword within short time if needed, but simple insert is fine for now
        $data = [
            'user_id' => $this->user_id,
            'keyword' => $keyword,
            'platform' => $platform,
            'created_at' => date('Y-m-d H:i:s')
        ];
        $this->db->insert('search_history', $data);
    }

    private function _load_env() {
        $env_path = FCPATH . '.env';
        if (file_exists($env_path)) {
            $lines = file($env_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos(trim($line), '#') === 0) continue;
                $parts = explode('=', $line, 2);
                if (count($parts) === 2) {
                    $key = trim($parts[0]);
                    $value = trim($parts[1]);
                    // Set both as env var and $_ENV for compatibility
                    putenv("$key=$value");
                    $_ENV[$key] = $value;
                }
            }
        }
    }
}
