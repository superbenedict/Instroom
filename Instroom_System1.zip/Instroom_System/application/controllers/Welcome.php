<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_Session $session
 * @property CI_Loader $load
 * @property Influencer_model $Influencer_model
 */
class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
        $this->load->model('Influencer_model');
	}

	public function index()
	{
		if (!$this->session->userdata('user_id')) {
			redirect('auth/login');
		}
		
		$data['user_name'] = $this->session->userdata('name');
        $data['user_email'] = $this->session->userdata('email');
        $data['user_role'] = $this->session->userdata('role');

        // Fetch recent influencers for activity feed
        $recent_influencers = $this->Influencer_model->get_recent_influencers(4);
        
        $activities = [];
        
        // Add Login Activity (Always first)
        $activities[] = [
            'type' => 'login',
            'title' => 'Login Successful',
            'description' => 'You logged in to your account.',
            'time' => 'Just now',
            'icon' => 'fa-check',
            'color' => 'brand-green'
        ];

        // Add Influencer Activities
        foreach ($recent_influencers as $inf) {
            // Check if created_at is valid, if not use current time or skip
            $time_str = $inf->created_at ? $this->time_elapsed_string($inf->created_at) : 'Recently';
            
            $activities[] = [
                'type' => 'influencer_add',
                'title' => 'New Influencer Added',
                'description' => 'Added <span class="font-semibold">' . htmlspecialchars($inf->username) . '</span> to the database.',
                'time' => $time_str,
                'icon' => 'fa-user-plus',
                'color' => 'brand-blue'
            ];
        }

        $data['activities'] = $activities;

        // Fetch Stats
        $data['total_influencers'] = $this->Influencer_model->count_influencers();
        // Placeholder for other stats as we don't have tables for campaigns/spend yet
        $data['active_campaigns'] = 8; 
        $data['avg_engagement'] = '4.2%';
        $data['total_spend'] = '$12,450';

		$this->load->view('welcome_message', $data);
	}

    private function time_elapsed_string($datetime, $full = false) {
        try {
            $now = new DateTime;
            $ago = new DateTime($datetime);
            $diff = $now->diff($ago);
        
            $w = floor($diff->d / 7);
            $diff->d -= $w * 7;

            $string = array(
                'y' => 'year',
                'm' => 'month',
                'w' => 'week',
                'd' => 'day',
                'h' => 'hour',
                'i' => 'minute',
                's' => 'second',
            );
            foreach ($string as $k => &$v) {
                if ($k == 'w' && $w) {
                     $v = $w . ' ' . $v . ($w > 1 ? 's' : '');
                } elseif (isset($diff->$k) && $diff->$k) {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                } else {
                    unset($string[$k]);
                }
            }
        
            if (!$full) $string = array_slice($string, 0, 1);
            return $string ? implode(', ', $string) . ' ago' : 'just now';
        } catch (Exception $e) {
            return 'Recently';
        }
    }
}
