<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            charcoal: '#1E1E1E',
                            offwhite: '#F7F9F8',
                            blue: '#2C8EC4',
                            amber: '#F4B740'
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/auth.css'); ?>" rel="stylesheet">
</head>
<body class="bg-brand-offwhite h-screen flex overflow-hidden font-sans">

    <!-- Left Side - Branding -->
    <div class="hidden lg:flex w-1/2 relative items-center justify-center overflow-hidden bg-cover bg-center" style="background-image: url('<?php echo base_url('assets/images/login_bg.png'); ?>');">
        <div class="relative z-10 text-center px-12">
            <h1 class="text-4xl font-bold text-white mb-4 tracking-tight">Join the Revolution</h1>
            <p class="text-lg text-blue-100 max-w-md mx-auto leading-relaxed">Start managing your influencer campaigns like a pro. It only takes a minute to get started.</p>
        </div>
    </div>

    <!-- Right Side - Register Form -->
    <div class="w-full lg:w-1/2 flex items-center justify-center p-8 bg-white overflow-y-auto">
        <div class="w-full max-w-md my-auto">
            <div class="text-center lg:text-left mb-10">
                <div class="lg:hidden flex justify-center mb-6">
                    <div class="w-16 h-16 bg-brand-deep rounded-xl flex items-center justify-center">
                        <i class="fas fa-bolt text-2xl text-brand-green"></i>
                    </div>
                </div>
                <h2 class="text-3xl font-bold text-brand-charcoal mb-2">Create your account</h2>
                <p class="text-gray-500">Get started with Instroom today.</p>
            </div>

            <?php if($this->session->flashdata('error')): ?>
                <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-r-lg shadow-sm" role="alert">
                    <p class="font-medium">Error</p>
                    <p class="text-sm"><?php echo $this->session->flashdata('error'); ?></p>
                </div>
            <?php endif; ?>

            <form action="<?php echo base_url('auth/register'); ?>" method="POST" class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2" for="name">Full Name</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <i class="far fa-user text-gray-400"></i>
                        </div>
                        <input class="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 text-brand-charcoal rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-all placeholder-gray-400" id="name" type="text" name="name" placeholder="John Doe" required>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2" for="email">Email Address</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <i class="far fa-envelope text-gray-400"></i>
                        </div>
                        <input class="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 text-brand-charcoal rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-all placeholder-gray-400" id="email" type="email" name="email" placeholder="you@example.com" required>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2" for="password">Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input class="w-full pl-11 pr-12 py-3 bg-gray-50 border border-gray-200 text-brand-charcoal rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-all placeholder-gray-400" id="password" type="password" name="password" placeholder="Enter your password" required>
                        <div class="absolute inset-y-0 right-0 pr-4 flex items-center">
                            <button type="button" id="togglePassword" class="text-gray-400 hover:text-gray-600 focus:outline-none hidden">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <p class="mt-2 text-xs text-gray-500">Must be at least 8 characters long.</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2" for="confirm_password">Confirm Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input class="w-full pl-11 pr-12 py-3 bg-gray-50 border border-gray-200 text-brand-charcoal rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-all placeholder-gray-400" id="confirm_password" type="password" name="confirm_password" placeholder="Confirm your password" required>
                        <div class="absolute inset-y-0 right-0 pr-4 flex items-center">
                            <button type="button" id="toggleConfirmPassword" class="text-gray-400 hover:text-gray-600 focus:outline-none hidden">
                                <i class="far fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <script>
                    function setupPasswordToggle(inputId, toggleId) {
                        const passwordInput = document.getElementById(inputId);
                        const toggleButton = document.getElementById(toggleId);
                        const toggleIcon = toggleButton.querySelector('i');

                        passwordInput.addEventListener('input', function() {
                            if (this.value.length > 0) {
                                toggleButton.classList.remove('hidden');
                            } else {
                                toggleButton.classList.add('hidden');
                                if (passwordInput.value === '') {
                                     passwordInput.setAttribute('type', 'password');
                                     toggleIcon.classList.remove('fa-eye-slash');
                                     toggleIcon.classList.add('fa-eye');
                                }
                            }
                        });

                        toggleButton.addEventListener('click', function() {
                            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                            passwordInput.setAttribute('type', type);
                            
                            if (type === 'text') {
                                toggleIcon.classList.remove('fa-eye');
                                toggleIcon.classList.add('fa-eye-slash');
                            } else {
                                toggleIcon.classList.remove('fa-eye-slash');
                                toggleIcon.classList.add('fa-eye');
                            }
                        });
                    }

                    setupPasswordToggle('password', 'togglePassword');
                    setupPasswordToggle('confirm_password', 'toggleConfirmPassword');
                </script>

                <button class="w-full bg-brand-green hover:bg-green-600 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-green-900/10 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-green transition duration-300 transform hover:-translate-y-0.5" type="submit">
                    Create Account
                </button>
            </form>

            <div class="mt-8 text-center">
                <p class="text-sm text-gray-500">
                    Already have an account? 
                    <a href="<?php echo base_url('auth/login'); ?>" class="font-semibold text-brand-blue hover:text-blue-600 transition-colors">Sign in</a>
                </p>
            </div>
            
            <div class="mt-10 pt-6 border-t border-gray-100 text-center">
                <p class="text-xs text-gray-400">&copy; <?php echo date('Y'); ?> Instroom. All rights reserved.</p>
            </div>
        </div>
    </div>

</body>
</html>