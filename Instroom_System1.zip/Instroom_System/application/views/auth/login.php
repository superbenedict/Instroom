<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            charcoal: '#1E1E1E',
                            offwhite: '#F7F9F8',
                            blue: '#2C8EC4',
                            amber: '#F4B740'
                        }
                    }
                }
            }
        }
    </script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/auth.css'); ?>" rel="stylesheet">
</head>
<body class="bg-brand-offwhite h-screen flex overflow-hidden font-sans">

    <!-- Left Side - Branding -->
    <div class="hidden lg:flex w-1/2 relative items-center justify-center overflow-hidden bg-cover bg-center" style="background-image: url('<?php echo base_url('assets/images/login_bg.png'); ?>');">
        <div class="relative z-10 text-center px-12">
            <h1 class="text-4xl font-bold text-white mb-4 tracking-tight">Welcome to Instroom</h1>
            <p class="text-lg text-blue-100 max-w-md mx-auto leading-relaxed">Manage your influencer campaigns, track performance, and grow your brand with our all-in-one platform.</p>
        </div>
    </div>

    <!-- Right Side - Login Form -->
    <div class="w-full lg:w-1/2 flex items-center justify-center p-8 bg-white">
        <div class="w-full max-w-md">
            <div class="text-center lg:text-left mb-10">
                <div class="lg:hidden flex justify-center mb-6">
                    <div class="w-16 h-16 bg-brand-deep rounded-xl flex items-center justify-center">
                        <i class="fas fa-bolt text-2xl text-brand-green"></i>
                    </div>
                </div>
                <h2 class="text-3xl font-bold text-brand-charcoal mb-2">Sign in to your account</h2>
                <p class="text-gray-500">Enter your details to access your dashboard.</p>
            </div>

            <?php if($this->session->flashdata('error')): ?>
                <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-r-lg shadow-sm" role="alert">
                    <p class="font-medium">Error</p>
                    <p class="text-sm"><?php echo $this->session->flashdata('error'); ?></p>
                </div>
            <?php endif; ?>

            <?php if($this->session->flashdata('success')): ?>
                <div class="bg-green-50 border-l-4 border-brand-green text-green-700 p-4 mb-6 rounded-r-lg shadow-sm" role="alert">
                    <p class="font-medium">Success</p>
                    <p class="text-sm"><?php echo $this->session->flashdata('success'); ?></p>
                </div>
            <?php endif; ?>

            <?php echo form_open('auth/login', ['class' => 'space-y-6']); ?>
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="email" name="email" id="email" required 
                            class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-all shadow-sm text-sm" 
                            placeholder="you@example.com">
                    </div>
                </div>

                <div>
                    <div class="flex items-center justify-between mb-1">
                        <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                        <a href="<?php echo site_url('auth/forgot_password'); ?>" class="text-sm text-brand-blue hover:text-brand-deep font-medium transition-colors">Forgot password?</a>
                    </div>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" name="password" id="password" required 
                            class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-all shadow-sm text-sm" 
                            placeholder="••••••••">
                    </div>
                </div>

                <button class="w-full bg-brand-green hover:bg-green-600 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-green-900/10 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-green transition duration-300 transform hover:-translate-y-0.5" type="submit">
                    Sign In
                </button>
            </form>

            <div class="mt-8 text-center">
                <p class="text-sm text-gray-500">
                    Don't have an account? 
                    <a href="<?php echo base_url('auth/register'); ?>" class="font-semibold text-brand-blue hover:text-blue-600 transition-colors">Create an account</a>
                </p>
            </div>
            
            <div class="mt-10 pt-6 border-t border-gray-100 text-center">
                <p class="text-xs text-gray-400">&copy; <?php echo date('Y'); ?> Instroom. All rights reserved.</p>
            </div>
        </div>
    </div>

</body>
</html>