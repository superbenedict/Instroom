<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics | Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827',
                            gray: '#F9FAFB',
                            border: '#E5E7EB',
                            blue: '#3B82F6',
                            purple: '#8B5CF6',
                            rose: '#F43F5E',
                            amber: '#F59E0B'
                        }
                    },
                    boxShadow: {
                        'card': '0 2px 5px -1px rgba(0, 0, 0, 0.05), 0 1px 3px -1px rgba(0, 0, 0, 0.03)',
                        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)',
                    }
                }
            }
        }
    </script>
    <link href="<?php echo base_url('assets/css/influencer.css'); ?>" rel="stylesheet">
</head>
<body class="bg-gray-50 h-screen flex overflow-hidden text-gray-800">

    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 bg-[#0F6B3E] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex fixed md:relative z-30 h-full top-0 left-0 shadow-xl">
        <div class="h-16 flex items-center px-8 border-b border-white/10">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bolt text-brand-green text-lg"></i>
                    </div>
                    <span class="text-xl font-bold tracking-tight text-white">INSTROOM</span>
                </div>
                <button class="md:hidden text-white/70 hover:text-white transition-colors focus:outline-none" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Main Menu</p>
            
            <a href="<?php echo base_url('welcome'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-tachometer-alt w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            
            <a href="<?php echo base_url('discovery'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-search w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Discovery</span>
            </a>
            
            <a href="<?php echo base_url('influencer'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-list-ul w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Influencer List</span>
            </a>

            <a href="<?php echo base_url('influencer/pipeline'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-filter w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Pipeline</span>
            </a>
            
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mt-8 mb-3">Campaigns</p>

            <a href="<?php echo base_url('influencer/closed_collaborations'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="far fa-check-square w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Closed</span>
            </a>
            
            <a href="#" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-users w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Ambassadors</span>
            </a>
            
            <a href="<?php echo base_url('influencer/analytics'); ?>" class="sidebar-item active group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white bg-white/5">
                <i class="fas fa-chart-line w-6 text-lg opacity-100 transition-opacity"></i>
                <span class="ml-3">Analytics</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden relative bg-white">
        
        <!-- Top Navigation -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-20 sticky top-0">
            <div class="flex items-center md:hidden">
                <button class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 rounded-md hover:bg-gray-100 transition-colors" onclick="toggleSidebar()">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <span class="ml-4 text-lg font-bold text-brand-deep">INSTROOM</span>
            </div>
            
            <div class="hidden md:flex items-center text-gray-500 text-sm font-medium">
                <span class="text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">Influencer</span>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <span class="text-brand-deep bg-green-50 px-2 py-1 rounded-md">Analytics</span>
            </div>

            <div class="flex items-center gap-4">
                <button class="relative p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100">
                    <i class="far fa-bell text-xl"></i>
                    <span class="absolute top-1.5 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div class="h-8 w-px bg-gray-200 mx-2"></div>

                <!-- User Dropdown -->
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-deep transition-colors"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user_role) ? ucfirst($user_role) : 'User'; ?></p>
                        </div>
                        <div class="relative">
                             <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'User'); ?>&background=1FAE5B&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-white group-hover:border-brand-green transition-all">
                             <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-deep transition-colors"></i>
                    </button>
                    
                    <!-- Dropdown -->
                    <div id="user-menu" class="hidden absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-50 animate-fade-in-up origin-top-right">
                        <div class="px-4 py-3 border-b border-gray-50">
                            <p class="text-sm font-semibold text-gray-900 truncate"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500 truncate"><?php echo isset($user_email) ? $user_email : ''; ?></p>
                        </div>
                        
                        <?php if(isset($user_role) && $user_role === 'admin'): ?>
                        <a href="<?php echo base_url('admin'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-tachometer-alt w-5 text-gray-400"></i> Admin Dashboard
                        </a>
                        <?php endif; ?>

                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5 text-gray-400"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5 text-gray-400"></i> Settings
                        </a>
                        
                        <div class="border-t border-gray-50 my-1"></div>
                        
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Scrollable Area -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6 md:p-8 scroll-smooth">
            
            <!-- Page Header -->
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Analytics Overview</h1>
                    <p class="text-gray-500 mt-1">Track your campaign performance and ROI.</p>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-xs font-medium text-gray-500 bg-white border border-gray-200 px-3 py-1.5 rounded-lg shadow-sm">
                        <i class="far fa-calendar-alt mr-1.5"></i> Last 30 Days
                    </span>
                    <button class="bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition-all flex items-center gap-2">
                        <i class="fas fa-download text-gray-400"></i> Export Report
                    </button>
                </div>
            </div>

            <!-- Top Key Metrics (Cards) -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <!-- Total Sales -->
                <div class="bg-gradient-to-br from-green-500 to-green-600 p-6 rounded-2xl shadow-lg text-white">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur-sm">
                            <i class="fas fa-dollar-sign text-white text-lg"></i>
                        </div>
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white/20 text-white">
                            +12.5%
                        </span>
                    </div>
                    <h3 class="text-2xl font-bold text-white">$ <?php echo number_format($stats['sales_amount']); ?></h3>
                    <p class="text-sm font-medium text-white/80 mt-1">Total Sales Amount</p>
                </div>

                <!-- ROI -->
                <?php 
                    $roi = ($stats['product_expenditure'] > 0) ? (($stats['sales_amount'] - $stats['product_expenditure']) / $stats['product_expenditure']) * 100 : 0;
                ?>
                <div class="bg-gradient-to-br from-blue-500 to-blue-600 p-6 rounded-2xl shadow-lg text-white">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur-sm">
                            <i class="fas fa-chart-pie text-white text-lg"></i>
                        </div>
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white/20 text-white">ROI</span>
                    </div>
                    <h3 class="text-2xl font-bold text-white"><?php echo number_format($roi, 1); ?>%</h3>
                    <p class="text-sm font-medium text-white/80 mt-1">Return on Investment</p>
                </div>

                <!-- Total Influencers -->
                <div class="bg-gradient-to-br from-purple-500 to-purple-600 p-6 rounded-2xl shadow-lg text-white">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur-sm">
                            <i class="fas fa-users text-white text-lg"></i>
                        </div>
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white/20 text-white">Active</span>
                    </div>
                    <h3 class="text-2xl font-bold text-white"><?php echo $stats['total_influencers']; ?></h3>
                    <p class="text-sm font-medium text-white/80 mt-1">Total Influencers</p>
                </div>

                <!-- Engagement -->
                <div class="bg-gradient-to-br from-orange-500 to-orange-600 p-6 rounded-2xl shadow-lg text-white">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center backdrop-blur-sm">
                            <i class="fas fa-eye text-white text-lg"></i>
                        </div>
                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white/20 text-white">Reach</span>
                    </div>
                    <h3 class="text-2xl font-bold text-white"><?php echo number_format($stats['total_views']); ?></h3>
                    <p class="text-sm font-medium text-white/80 mt-1">Total Views Generated</p>
                </div>
            </div>

            <!-- Growth Trend Chart -->
            <div class="bg-white p-6 rounded-2xl shadow-card border border-gray-100 mb-8">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-lg font-bold text-gray-900">Influencer Growth</h3>
                        <p class="text-sm text-gray-500">New collaborations over the last 30 days</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="w-3 h-3 rounded-full bg-brand-green"></span>
                        <span class="text-xs font-medium text-gray-600">New Profiles</span>
                    </div>
                </div>
                <div class="relative h-80 w-full">
                    <canvas id="growthChart"></canvas>
                </div>
            </div>

            <!-- MAIN LAYOUT - RESTRUCTURED FOR HORIZONTAL DESIGN -->
            
            <!-- SECTION 1: Brand Awareness (Horizontal) -->
            <div class="bg-white p-6 rounded-2xl shadow-card border border-gray-100 mb-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-bold text-gray-900 flex items-center gap-2">
                        <i class="fas fa-bullhorn text-brand-green"></i> Brand Awareness
                    </h3>
                    <span class="text-xs text-gray-500 font-medium bg-gray-50 px-2 py-1 rounded">Last 30 Days</span>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <!-- Total Likes -->
                    <div class="p-5 bg-gradient-to-br from-pink-50 to-white rounded-xl border border-pink-100 group hover:border-pink-200 transition-colors">
                        <div class="flex items-start justify-between mb-2">
                            <div class="text-xs font-bold text-gray-500 uppercase tracking-wide">Total Likes</div>
                            <div class="p-1.5 bg-pink-100 text-pink-600 rounded-lg group-hover:bg-pink-600 group-hover:text-white transition-colors">
                                <i class="fas fa-heart text-xs"></i>
                            </div>
                        </div>
                        <div class="text-2xl font-bold text-gray-900"><?php echo number_format($stats['total_likes']); ?></div>
                        <div class="mt-2 flex items-center text-xs text-green-600 font-medium">
                            <i class="fas fa-arrow-up mr-1"></i> 8.2%
                            <span class="text-gray-400 ml-1 font-normal">vs last month</span>
                        </div>
                    </div>

                    <!-- Total Comments -->
                    <div class="p-5 bg-gradient-to-br from-blue-50 to-white rounded-xl border border-blue-100 group hover:border-blue-200 transition-colors">
                        <div class="flex items-start justify-between mb-2">
                            <div class="text-xs font-bold text-gray-500 uppercase tracking-wide">Total Comments</div>
                            <div class="p-1.5 bg-blue-100 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                <i class="fas fa-comment text-xs"></i>
                            </div>
                        </div>
                        <div class="text-2xl font-bold text-gray-900"><?php echo number_format($stats['total_comments']); ?></div>
                        <div class="mt-2 flex items-center text-xs text-green-600 font-medium">
                            <i class="fas fa-arrow-up mr-1"></i> 12.5%
                            <span class="text-gray-400 ml-1 font-normal">vs last month</span>
                        </div>
                    </div>

                    <!-- Avg CPM -->
                    <div class="p-5 bg-gradient-to-br from-purple-50 to-white rounded-xl border border-purple-100 group hover:border-purple-200 transition-colors">
                        <div class="flex items-start justify-between mb-2">
                            <div class="text-xs font-bold text-gray-500 uppercase tracking-wide">Avg CPM</div>
                            <div class="p-1.5 bg-purple-100 text-purple-600 rounded-lg group-hover:bg-purple-600 group-hover:text-white transition-colors">
                                <i class="fas fa-tag text-xs"></i>
                            </div>
                        </div>
                        <div class="text-2xl font-bold text-gray-900">$<?php echo number_format($stats['cpm'], 2); ?></div>
                        <div class="mt-2 flex items-center text-xs text-red-500 font-medium">
                            <i class="fas fa-arrow-down mr-1"></i> 2.1%
                            <span class="text-gray-400 ml-1 font-normal">vs last month</span>
                        </div>
                    </div>

                    <!-- Avg Eng. Rate -->
                    <div class="p-5 bg-gradient-to-br from-orange-50 to-white rounded-xl border border-orange-100 group hover:border-orange-200 transition-colors">
                        <div class="flex items-start justify-between mb-2">
                            <div class="text-xs font-bold text-gray-500 uppercase tracking-wide">Avg Eng. Rate</div>
                            <div class="p-1.5 bg-orange-100 text-orange-600 rounded-lg group-hover:bg-orange-600 group-hover:text-white transition-colors">
                                <i class="fas fa-chart-bar text-xs"></i>
                            </div>
                        </div>
                        <div class="text-2xl font-bold text-gray-900"><?php echo number_format($stats['avg_eng_rate'], 2); ?>%</div>
                        <div class="mt-2 flex items-center text-xs text-green-600 font-medium">
                            <i class="fas fa-arrow-up mr-1"></i> 5.3%
                            <span class="text-gray-400 ml-1 font-normal">vs last month</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SECTION 2: Financial Overview (Horizontal / Wide) -->
            <div class="bg-white p-6 rounded-2xl shadow-card border border-gray-100 mb-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-bold text-gray-900 flex items-center gap-2">
                        <i class="fas fa-wallet text-brand-green"></i> Financial Overview
                    </h3>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Expenditure -->
                    <div class="p-5 bg-gray-50 rounded-xl border border-gray-100 flex flex-col justify-center">
                        <div class="text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Expenditure</div>
                        <div class="text-3xl font-bold text-gray-900">$<?php echo number_format($stats['product_expenditure']); ?></div>
                        <div class="w-full bg-gray-200 rounded-full h-1.5 mt-3">
                            <div class="bg-gray-800 h-1.5 rounded-full" style="width: 65%"></div>
                        </div>
                        <p class="text-[10px] text-gray-400 mt-2">65% of budget used</p>
                    </div>

                    <!-- Avg Sales / Won -->
                    <div class="p-5 bg-gray-50 rounded-xl border border-gray-100 flex flex-col justify-center">
                        <div class="text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Avg Sales / Won</div>
                        <div class="text-3xl font-bold text-gray-900">$<?php 
                            $avg_sales_per_won = ($stats['won_count'] > 0) ? $stats['sales_amount'] / $stats['won_count'] : 0;
                            echo number_format($avg_sales_per_won, 2); 
                        ?></div>
                            <div class="w-full bg-gray-200 rounded-full h-1.5 mt-3">
                            <div class="bg-brand-blue h-1.5 rounded-full" style="width: 80%"></div>
                        </div>
                        <p class="text-[10px] text-gray-400 mt-2">High performance</p>
                    </div>

                    <!-- Campaigns Won -->
                    <div class="p-5 bg-green-50 rounded-xl border border-green-100 flex items-center justify-between">
                        <div>
                            <div class="text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Campaigns Won</div>
                            <div class="text-3xl font-bold text-brand-deep"><?php echo number_format($stats['won_count']); ?></div>
                            <div class="text-[10px] text-brand-green mt-2 font-medium">Top performing metric</div>
                        </div>
                        <div class="h-16 w-16 bg-white rounded-full flex items-center justify-center shadow-sm">
                            <i class="fas fa-trophy text-brand-green text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SECTION 3: Platform Performance (Wide) -->
            <div class="bg-white p-6 rounded-2xl shadow-card border border-gray-100 mb-8">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-bold text-gray-900 flex items-center gap-2">
                        <i class="fas fa-layer-group text-brand-green"></i> Platform Performance
                    </h3>
                </div>
                
                <div class="flex flex-col lg:flex-row gap-8 items-center">
                    <!-- Chart -->
                    <div class="w-full lg:w-1/3 h-64 relative">
                        <canvas id="platformChart"></canvas>
                    </div>

                    <!-- List -->
                    <div class="w-full lg:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php foreach($platforms as $p): 
                            $detail = $stats['platform_details'][$p];
                            $iconClass = $p == 'Facebook' ? 'fab fa-facebook text-blue-600' : ($p == 'Instagram' ? 'fab fa-instagram text-pink-600' : ($p == 'TikTok' ? 'fab fa-tiktok text-black' : 'fab fa-youtube text-red-600'));
                            $bgClass = $p == 'Facebook' ? 'bg-blue-50' : ($p == 'Instagram' ? 'bg-pink-50' : ($p == 'TikTok' ? 'bg-gray-100' : 'bg-red-50'));
                        ?>
                        <div class="bg-gray-50 rounded-xl p-4 border border-gray-100 hover:shadow-md transition-shadow group flex items-center justify-between">
                            <div class="flex items-center gap-4">
                                <div class="w-10 h-10 rounded-lg <?php echo $bgClass; ?> flex items-center justify-center flex-shrink-0">
                                    <i class="<?php echo $iconClass; ?> text-lg"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold text-gray-900 text-sm"><?php echo $p; ?></h4>
                                    <p class="text-[10px] text-gray-500"><?php echo $detail['total']; ?> Influencers</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="text-sm font-bold text-gray-900"><?php echo $detail['won']; ?> Won</div>
                                <div class="text-[10px] text-gray-500">$<?php echo number_format($detail['sales_amount']); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
        </main>
    </div>

    <!-- Charts Script -->
    <script>
        // Prepare Data
        const growthData = <?php echo json_encode($growth_trend); ?>;
        const platformData = <?php echo json_encode($stats['platform_counts']); ?>;
        
        // Process Growth Data
        const growthLabels = Object.keys(growthData);
        const growthValues = Object.values(growthData);

        // Process Platform Data
        const platformLabels = Object.keys(platformData);
        const platformValues = Object.values(platformData);
        
        // Color mapping for known platforms
        const colorMap = {
            'Facebook': '#3B82F6', // Blue
            'Instagram': '#EC4899', // Pink
            'TikTok': '#000000', // Black
            'YouTube': '#EF4444', // Red
            'LinkedIn': '#0A66C2', // LinkedIn Blue
            'Twitter': '#1DA1F2', // Twitter Blue
            'Pinterest': '#E60023' // Pinterest Red
        };
        
        // Generate colors for platforms
        const platformColors = platformLabels.map(label => {
            return colorMap[label] || '#' + Math.floor(Math.random()*16777215).toString(16); // Fallback to random color
        });

        // Chart Global Defaults
        Chart.defaults.font.family = '"Plus Jakarta Sans", sans-serif';
        Chart.defaults.color = '#6B7280';

        // 1. Growth Line Chart
        const ctxGrowth = document.getElementById('growthChart').getContext('2d');
        const gradientGrowth = ctxGrowth.createLinearGradient(0, 0, 0, 400);
        gradientGrowth.addColorStop(0, 'rgba(31, 174, 91, 0.2)');
        gradientGrowth.addColorStop(1, 'rgba(31, 174, 91, 0)');

        new Chart(ctxGrowth, {
            type: 'line',
            data: {
                labels: growthLabels,
                datasets: [{
                    label: 'New Influencers',
                    data: growthValues,
                    borderColor: '#1FAE5B',
                    backgroundColor: gradientGrowth,
                    borderWidth: 2,
                    pointBackgroundColor: '#ffffff',
                    pointBorderColor: '#1FAE5B',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#fff',
                        titleColor: '#111827',
                        bodyColor: '#4B5563',
                        borderColor: '#E5E7EB',
                        borderWidth: 1,
                        padding: 10,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return context.parsed.y + ' New Profiles';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [2, 4], color: '#F3F4F6' },
                        ticks: { padding: 10 }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { padding: 10, maxTicksLimit: 10 }
                    }
                }
            }
        });

        // 2. Platform Doughnut Chart
        const ctxPlatform = document.getElementById('platformChart').getContext('2d');
        new Chart(ctxPlatform, {
            type: 'doughnut',
            data: {
                labels: platformLabels,
                datasets: [{
                    data: platformValues,
                    backgroundColor: platformColors,
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: {
                    legend: {
                        position: 'right',
                        labels: { usePointStyle: true, boxWidth: 6, padding: 20, font: { size: 11 } }
                    }
                }
            }
        });
    </script>

    <!-- Toggle Sidebar Script -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('absolute');
            sidebar.classList.toggle('z-40');
            sidebar.classList.toggle('h-full');
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });
    </script>
</body>
</html>