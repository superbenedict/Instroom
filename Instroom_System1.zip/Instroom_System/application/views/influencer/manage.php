<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Influencer List - Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827',
                            gray: '#F9FAFB',
                            border: '#E5E7EB',
                            blue: '#3B82F6',
                            purple: '#8B5CF6',
                            rose: '#F43F5E',
                            amber: '#F59E0B'
                        }
                    },
                    boxShadow: {
                        'card': '0 2px 5px -1px rgba(0, 0, 0, 0.05), 0 1px 3px -1px rgba(0, 0, 0, 0.03)',
                        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)',
                    }
                }
            }
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });
    </script>
    <link href="<?php echo base_url('assets/css/influencer_manage.css'); ?>" rel="stylesheet">
</head>
<body class="bg-gray-50 h-screen flex overflow-hidden text-gray-800">

    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 bg-[#0F6B3E] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex fixed md:relative z-30 h-full top-0 left-0 shadow-xl">
        <div class="h-16 flex items-center px-8 border-b border-white/10">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bolt text-brand-green text-lg"></i>
                    </div>
                    <span class="text-xl font-bold tracking-tight text-white">INSTROOM</span>
                </div>
                <button class="md:hidden text-white/70 hover:text-white transition-colors focus:outline-none" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Main Menu</p>
            
            <a href="<?php echo base_url('welcome'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-tachometer-alt w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            
            <a href="<?php echo base_url('discovery'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-search w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Discovery</span>
            </a>
            
            <a href="<?php echo base_url('influencer'); ?>" class="sidebar-item active group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white bg-white/5">
                <i class="fas fa-list-ul w-6 text-lg opacity-100 transition-opacity"></i>
                <span class="ml-3">Influencer List</span>
            </a>

            <a href="<?php echo base_url('influencer/pipeline'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-filter w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Pipeline</span>
            </a>

            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mt-8 mb-3">Campaigns</p>

            <a href="<?php echo base_url('influencer/closed_collaborations'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="far fa-check-square w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Closed</span>
            </a>
            
            <a href="#" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-users w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Ambassadors</span>
            </a>
            
            <a href="<?php echo base_url('influencer/analytics'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-chart-line w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Analytics</span>
            </a>
        </nav>


    </aside>

    <!-- Main Content Wrapper -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden relative bg-white">
        
        <!-- Top Navigation -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-20 sticky top-0">
            <div class="flex items-center md:hidden">
                <button class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 rounded-md hover:bg-gray-100 transition-colors" onclick="toggleSidebar()">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <span class="ml-4 text-lg font-bold text-brand-deep">INSTROOM</span>
            </div>
            
            <div class="hidden md:flex items-center text-gray-500 text-sm font-medium">
                <span class="text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">Influencer</span>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <span class="text-brand-deep bg-green-50 px-2 py-1 rounded-md">List</span>
            </div>

            <div class="flex items-center gap-4">
                <button class="relative p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100">
                    <i class="far fa-bell text-xl"></i>
                    <span class="absolute top-1.5 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div class="h-8 w-px bg-gray-200 mx-2"></div>

                <!-- User Dropdown -->
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-deep transition-colors"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user_role) ? ucfirst($user_role) : 'User'; ?></p>
                        </div>
                        <div class="relative">
                             <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'User'); ?>&background=1FAE5B&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-white group-hover:border-brand-green transition-all">
                             <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-deep transition-colors"></i>
                    </button>
                    
                    <!-- Dropdown -->
                    <div id="user-menu" class="hidden absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-50 animate-fade-in-up origin-top-right">
                        <div class="px-4 py-3 border-b border-gray-50">
                            <p class="text-sm font-semibold text-gray-900 truncate"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500 truncate"><?php echo isset($user_email) ? $user_email : ''; ?></p>
                        </div>
                        
                        <?php if(isset($user_role) && $user_role === 'admin'): ?>
                        <a href="<?php echo base_url('admin'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-tachometer-alt w-5 text-gray-400"></i> Admin Dashboard
                        </a>
                        <?php endif; ?>
                        
                        <?php if(isset($user_role) && in_array($user_role, ['admin','manager'])): ?>
                        <a href="<?php echo base_url('manager'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-chart-line w-5 text-gray-400"></i> Manager Dashboard
                        </a>
                        <?php endif; ?>
                        
                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5 text-gray-400"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5 text-gray-400"></i> Settings
                        </a>
                        
                        <div class="border-t border-gray-50 my-1"></div>
                        
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto bg-gray-50/50 p-6 md:p-8 scroll-smooth">
            
            <div class="max-w-7xl mx-auto">
                
                <!-- Action Header -->
                <div class="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900 tracking-tight">Influencers</h1>
                        <p class="text-gray-500 mt-1 text-sm font-medium">Manage, track, and analyze your influencer partnerships.</p>
                    </div>
                    <div class="flex items-center gap-3 w-full md:w-auto">
                        <button type="button" id="myListBtn" onclick="toggleMyList()" class="flex-1 md:flex-none bg-white border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-semibold py-2.5 px-5 rounded-xl shadow-sm transition-all flex items-center justify-center group">
                            <i class="fas fa-list mr-2 text-gray-400 group-hover:text-gray-600 transition-colors"></i> My List
                        </button>
                        <button type="button" onclick="toggleModal('importModal')" class="flex-1 md:flex-none bg-white border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-semibold py-2.5 px-5 rounded-xl shadow-sm transition-all flex items-center justify-center group">
                            <i class="fas fa-file-import mr-2 text-gray-400 group-hover:text-gray-600 transition-colors"></i> Import
                        </button>
                        <button type="button" onclick="toggleModal('addInfluencerModal')" class="flex-1 md:flex-none bg-brand-green hover:bg-green-600 text-white text-sm font-semibold py-2.5 px-6 rounded-xl shadow-lg shadow-green-900/20 transition-all hover:-translate-y-0.5 flex items-center justify-center">
                            <i class="fas fa-plus mr-2"></i> Add New
                        </button>
                    </div>
                </div>

                <!-- Stats Overview -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <!-- Total Influencers -->
                    <div class="bg-white p-6 rounded-2xl shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] border border-gray-100 relative overflow-hidden group hover:shadow-md transition-all">
                        <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                            <i class="fas fa-users text-6xl text-brand-green"></i>
                        </div>
                        <div class="relative z-10">
                            <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Total Influencers</p>
                            <div class="flex items-baseline gap-2">
                                <h3 class="text-3xl font-bold text-gray-900"><?= number_format($total_rows) ?></h3>
                                <span class="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                                    <i class="fas fa-arrow-up text-[10px] mr-1"></i>12%
                                </span>
                            </div>
                        </div>
                        <div class="mt-4 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                            <div class="h-full bg-brand-green w-[70%] rounded-full"></div>
                        </div>
                    </div>

                    <!-- Active -->
                    <div class="bg-white p-6 rounded-2xl shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] border border-gray-100 relative overflow-hidden group hover:shadow-md transition-all">
                        <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                            <i class="fas fa-check-circle text-6xl text-blue-500"></i>
                        </div>
                        <div class="relative z-10">
                            <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Active Now</p>
                            <div class="flex items-baseline gap-2">
                                <h3 class="text-3xl font-bold text-gray-900"><?= number_format(isset($active_count) ? $active_count : 0) ?></h3>
                                <span class="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">Running</span>
                            </div>
                        </div>
                        <div class="mt-4 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                            <div class="h-full bg-blue-500 w-[<?= ($total_rows > 0) ? ($active_count / $total_rows * 100) : 0 ?>%] rounded-full"></div>
                        </div>
                    </div>

                    <!-- Inactive -->
                    <div class="bg-white p-6 rounded-2xl shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] border border-gray-100 relative overflow-hidden group hover:shadow-md transition-all">
                        <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
                            <i class="fas fa-pause-circle text-6xl text-amber-500"></i>
                        </div>
                        <div class="relative z-10">
                            <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Inactive</p>
                            <div class="flex items-baseline gap-2">
                                <h3 class="text-3xl font-bold text-gray-900"><?= number_format($total_rows - (isset($active_count) ? $active_count : 0)) ?></h3>
                                <span class="text-xs font-medium text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">Paused</span>
                            </div>
                        </div>
                        <div class="mt-4 h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                            <div class="h-full bg-amber-400 w-[<?= ($total_rows > 0) ? (($total_rows - $active_count) / $total_rows * 100) : 0 ?>%] rounded-full"></div>
                        </div>
                    </div>
                </div>

                <!-- Flash Messages -->
                <?php if($this->session->flashdata('success')): ?>
                <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded-r-lg shadow-sm animate-fade-in-up">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-green-500"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm text-green-700"><?php echo $this->session->flashdata('success'); ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($this->session->flashdata('error')): ?>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg shadow-sm animate-fade-in-up">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-exclamation-circle text-red-500"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm text-red-700"><?php echo $this->session->flashdata('error'); ?></p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Filters & Search Bar -->
                <div id="mainSearchRow" class="mb-6 flex flex-col md:flex-row items-center justify-between gap-4">
                    <form action="<?= base_url('influencer') ?>" method="get" class="relative w-full md:w-48 group">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <i class="fas fa-search text-gray-400 group-focus-within:text-brand-green transition-colors text-xs"></i>
                        </div>
                        <input type="text" name="search" value="<?= $this->input->get('search') ?>" placeholder="Search..." class="w-full pl-9 pr-3 py-2 bg-white border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green shadow-sm transition-all text-gray-800 placeholder-gray-400">
                        <?php if($this->input->get('platform')): ?><input type="hidden" name="platform" value="<?= $this->input->get('platform') ?>"><?php endif; ?>
                        <?php if($this->input->get('niche')): ?><input type="hidden" name="niche" value="<?= $this->input->get('niche') ?>"><?php endif; ?>
                        <?php if($this->input->get('status')): ?><input type="hidden" name="status" value="<?= $this->input->get('status') ?>"><?php endif; ?>
                    </form>
                    
                    <div class="flex items-center gap-2 w-full md:w-auto">
                        <div id="bulkActions" class="hidden flex items-center gap-3 animate-fade-in-right bg-white p-1.5 rounded-xl border border-gray-100 shadow-sm">
                            <div class="flex items-center px-3 py-1.5 bg-gray-900 text-white rounded-lg">
                                <span class="text-xs font-bold whitespace-nowrap"><span id="selectedCount">0</span> Selected</span>
                            </div>
                            
                            <button onclick="bulkAddPipeline()" class="group flex items-center gap-1.5 bg-brand-blue hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-bold shadow-lg shadow-blue-500/20 transition-all transform active:scale-95 flex-shrink-0 whitespace-nowrap hover:-translate-y-0.5">
                                <i class="fas fa-columns text-xs"></i> Add to Pipeline
                            </button>
                            
                            <button onclick="bulkExport()" class="group flex items-center gap-1.5 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 px-4 py-2 rounded-lg text-xs font-bold shadow-sm transition-all transform active:scale-95 flex-shrink-0 whitespace-nowrap hover:-translate-y-0.5">
                                <i class="fas fa-file-export text-xs text-gray-400 group-hover:text-gray-600"></i> Export
                            </button>

                            <button id="bulkDeleteBtn" onclick="deleteSelected()" class="group flex items-center gap-1.5 bg-white border border-red-200 text-red-600 hover:bg-red-50 px-4 py-2 rounded-lg text-xs font-bold shadow-sm transition-all transform active:scale-95 flex-shrink-0 whitespace-nowrap hover:-translate-y-0.5">
                                <i class="fas fa-trash-alt text-xs"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Filter Options Row (Hidden by default) -->
                <div id="mainFilterOptionsRow" class="hidden bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6 animate-fade-in-up">
                    <form action="<?= base_url('influencer') ?>" method="get" class="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <?php if($this->input->get('search')): ?><input type="hidden" name="search" value="<?= $this->input->get('search') ?>"><?php endif; ?>
                        
                        <div class="relative">
                            <label class="block text-xs font-semibold text-gray-500 mb-1">Platform</label>
                            <select name="platform" onchange="this.form.submit()" class="w-full bg-gray-50 border border-gray-200 text-gray-700 py-2 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-blue focus:border-brand-blue text-sm">
                                <option value="">All Platforms</option>
                                <option value="Instagram" <?= $this->input->get('platform') == 'Instagram' ? 'selected' : '' ?>>Instagram</option>
                                <option value="TikTok" <?= $this->input->get('platform') == 'TikTok' ? 'selected' : '' ?>>TikTok</option>
                            </select>
                        </div>
                        
                        <div class="relative">
                            <label class="block text-xs font-semibold text-gray-500 mb-1">Niche</label>
                            <select name="niche" onchange="this.form.submit()" class="w-full bg-gray-50 border border-gray-200 text-gray-700 py-2 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-blue focus:border-brand-blue text-sm">
                                <option value="">All Niches</option>
                                <option value="Fashion" <?= $this->input->get('niche') == 'Fashion' ? 'selected' : '' ?>>Fashion</option>
                                <option value="Tech" <?= $this->input->get('niche') == 'Tech' ? 'selected' : '' ?>>Tech</option>
                                <option value="Beauty" <?= $this->input->get('niche') == 'Beauty' ? 'selected' : '' ?>>Beauty</option>
                                <option value="Travel" <?= $this->input->get('niche') == 'Travel' ? 'selected' : '' ?>>Travel</option>
                            </select>
                        </div>

                        <div class="relative">
                            <label class="block text-xs font-semibold text-gray-500 mb-1">Status</label>
                            <select name="status" onchange="this.form.submit()" class="w-full bg-gray-50 border border-gray-200 text-gray-700 py-2 px-3 rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-blue focus:border-brand-blue text-sm">
                                <option value="">All Status</option>
                                <option value="Active" <?= $this->input->get('status') == 'Active' ? 'selected' : '' ?>>Active</option>
                                <option value="Inactive" <?= $this->input->get('status') == 'Inactive' ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </div>
                        
                        <div class="flex items-end gap-2 col-span-2 md:col-span-2">
                             <a href="<?= base_url('influencer') ?>" class="bg-gray-100 hover:bg-gray-200 text-gray-600 py-2 px-4 rounded-lg text-sm font-medium transition-colors">
                                Reset
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Main Tables Container -->
                <div id="allListContainer">
                <!-- Table -->
                <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-100">
                            <thead>
                                <tr class="bg-gray-50 border-b border-gray-200">
                                    <th scope="col" class="px-6 py-4 text-center w-10 align-middle">
                                        <input type="checkbox" id="selectAllCheckbox" onchange="toggleSelectAll(this)" class="form-checkbox h-4 w-4 text-brand-green border-gray-300 rounded focus:ring-brand-green/20 transition duration-150 ease-in-out cursor-pointer">
                                    </th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider align-middle">Profile</th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider align-middle">Influencer</th>
                                    <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider hidden sm:table-cell align-middle">Followers</th>
                                    <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider hidden md:table-cell align-middle">Engagement</th>
                                    <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider hidden lg:table-cell align-middle">Avg. Views</th>
                                    <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider hidden lg:table-cell align-middle">GMV</th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider min-w-[200px] align-middle">Assessment</th>
                                    <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider min-w-[200px] align-middle">Notes</th>
                                    <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-gray-500 uppercase tracking-wider align-middle">Status</th>
                                    <th scope="col" class="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-wider align-middle">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50 bg-white">
                                <?php if(empty($influencers)): ?>
                                    <tr>
                                        <td colspan="11" class="px-6 py-16 whitespace-nowrap text-center text-sm text-gray-500">
                                            <div class="flex flex-col items-center justify-center">
                                                <div class="bg-gray-50 p-4 rounded-full mb-3">
                                                    <i class="fas fa-search text-gray-300 text-2xl"></i>
                                                </div>
                                                <p class="font-medium text-gray-900">No influencers found</p>
                                                <p class="text-xs text-gray-400 mt-1 mb-4">Try adjusting your filters or search terms.</p>
                                                <button onclick="toggleModal('addInfluencerModal')" class="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 text-xs font-medium py-2 px-4 rounded-lg shadow-sm transition-all">
                                                    <i class="fas fa-plus mr-1.5"></i> Add New Influencer
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($influencers as $influencer): ?>
                                    <tr class="hover:bg-gray-50/80 transition-colors group">
                                        <td class="px-6 py-4 whitespace-nowrap align-middle">
                                            <input type="checkbox" class="influencer-checkbox form-checkbox h-4 w-4 text-brand-green border-gray-300 rounded focus:ring-brand-green/20 transition duration-150 ease-in-out cursor-pointer" value="<?= $influencer->id ?>" onchange="updateBulkButtonsState()">
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap align-middle">
                                            <div class="h-10 w-10 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-gray-500 font-bold text-sm border border-gray-100 flex-shrink-0 overflow-hidden">
                                                <img src="https://ui-avatars.com/api/?name=<?= urlencode($influencer->username) ?>&background=random&color=fff&size=64" alt="<?= $influencer->username ?>" class="w-full h-full object-cover">
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap align-middle">
                                            <div>
                                                <div class="text-sm font-bold text-gray-900 flex items-center gap-2">
                                                    <?= $influencer->username ?>
                                                    <?php 
                                                        $platform = isset($influencer->platform) ? $influencer->platform : '-';
                                                        $iconClass = 'text-gray-400';
                                                        if (stripos($platform, 'Instagram') !== false) $iconClass = 'text-pink-600 fab fa-instagram';
                                                        elseif (stripos($platform, 'TikTok') !== false) $iconClass = 'text-black fab fa-tiktok';
                                                        elseif (stripos($platform, 'YouTube') !== false) $iconClass = 'text-red-600 fab fa-youtube';
                                                        else $iconClass = 'fas fa-globe text-gray-400';
                                                    ?>
                                                    <i class="<?= $iconClass ?> text-xs opacity-80" title="<?= $platform ?>"></i>
                                                </div>
                                                <div class="text-xs text-gray-400 mt-0.5"><?= isset($influencer->niche) ? $influencer->niche : 'General' ?></div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 tabular-nums hidden sm:table-cell align-middle text-center">
                                            <?= number_format($influencer->followers) ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 tabular-nums hidden md:table-cell align-middle text-center">
                                            <?php 
                                                $er = isset($influencer->eng_rate) ? $influencer->eng_rate : (isset($influencer->engagement_rate) ? $influencer->engagement_rate : 0); 
                                                echo $er . '%';
                                            ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 tabular-nums hidden lg:table-cell align-middle text-center">
                                            <?= isset($influencer->avg_video_views) ? number_format($influencer->avg_video_views) : '-' ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap hidden lg:table-cell align-middle text-center">
                                            <span class="text-sm font-medium text-brand-green tabular-nums">
                                                <?= isset($influencer->gmv) ? '$' . number_format($influencer->gmv) : '-' ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-normal align-middle max-w-xs">
                                            <div class="flex flex-col items-start gap-2">
                                                <div id="assessment-label-<?= $influencer->id ?>" class="text-sm font-semibold <?= (isset($influencer->assessment) && $influencer->assessment == 'Qualified') ? 'text-green-600' : ((isset($influencer->assessment) && $influencer->assessment == 'Not Qualified') ? 'text-red-600' : 'text-gray-500') ?>" title="<?= isset($influencer->assessment) ? $influencer->assessment : '' ?>">
                                                    <?= isset($influencer->assessment) ? $influencer->assessment : '' ?>
                                                </div>
                                                <div class="flex gap-2">
                                                    <button onclick="quickAssess(<?= $influencer->id ?>, 'Qualified')" class="w-8 h-8 rounded-full border border-green-500 text-green-500 hover:bg-green-500 hover:text-white flex items-center justify-center transition-colors shadow-sm" title="Qualified">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                    <button onclick="quickAssess(<?= $influencer->id ?>, 'Not Qualified')" class="w-8 h-8 rounded-full border border-red-500 text-red-500 hover:bg-red-500 hover:text-white flex items-center justify-center transition-colors shadow-sm" title="Not Qualified">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-normal align-middle max-w-xs">
                                            <div class="text-sm text-gray-500 line-clamp-2" title="<?= isset($influencer->notes) ? $influencer->notes : '' ?>">
                                                <?= isset($influencer->notes) && $influencer->notes !== '' ? $influencer->notes : '-' ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap align-middle text-center">
                                            <?php 
                                                // Strictly use pipeline status as per user request
                                                $display_status = !empty($influencer->pipeline_status) ? $influencer->pipeline_status : '-';

                                                $statusClass = '';
                                                $dotClass = '';
                                                switch($display_status) {
                                                    case 'Active': 
                                                        $statusClass = 'bg-green-50 text-green-700 border-green-200'; 
                                                        $dotClass = 'bg-green-500';
                                                        break;
                                                    case 'Inactive': 
                                                        $statusClass = 'bg-gray-50 text-gray-600 border-gray-200'; 
                                                        $dotClass = 'bg-gray-400';
                                                        break;
                                                    case 'For Outreach': 
                                                        $statusClass = 'bg-yellow-50 text-yellow-700 border-yellow-200'; 
                                                        $dotClass = 'bg-yellow-500';
                                                        break;
                                                    case 'Contacted': 
                                                        $statusClass = 'bg-blue-50 text-blue-700 border-blue-200'; 
                                                        $dotClass = 'bg-blue-500';
                                                        break;
                                                    case 'Replied': 
                                                        $statusClass = 'bg-purple-50 text-purple-700 border-purple-200'; 
                                                        $dotClass = 'bg-purple-500';
                                                        break;
                                                    case 'In - Progress':
                                                        $statusClass = 'bg-indigo-50 text-indigo-700 border-indigo-200';
                                                        $dotClass = 'bg-indigo-500';
                                                        break;
                                                    case 'Completed':
                                                        $statusClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                                                        $dotClass = 'bg-emerald-500';
                                                        break;
                                                    case 'Not Interested':
                                                        $statusClass = 'bg-red-50 text-red-700 border-red-200';
                                                        $dotClass = 'bg-red-500';
                                                        break;
                                                    default: 
                                                        $statusClass = 'bg-gray-50 text-gray-600 border-gray-200';
                                                        $dotClass = 'bg-gray-400';
                                                }
                                            ?>
                                            <span class="px-3 py-1 inline-flex items-center gap-1.5 text-xs font-medium rounded-full border <?= $statusClass ?>">
                                                <span class="w-1.5 h-1.5 rounded-full <?= $dotClass ?>"></span>
                                                <?= $display_status ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium align-middle">
                                            <div class="flex items-center justify-end gap-2">
                                                <button onclick="editInfluencer(<?= $influencer->id ?>)" class="text-gray-400 hover:text-brand-amber p-2 rounded-lg hover:bg-yellow-50 transition-colors" title="Edit">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </button>
                                                <button onclick="confirmDeleteSingle(<?= $influencer->id ?>)" class="text-gray-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50 transition-colors" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="bg-white px-6 py-4 border-t border-gray-100 flex items-center justify-between">
                        <div class="text-xs text-gray-500">
                            Showing <span class="font-medium"><?= $start_index ?></span> to <span class="font-medium"><?= $end_index ?></span> of <span class="font-medium"><?= $total_rows ?></span> results
                        </div>
                        <div class="flex gap-1 pagination-links">
                            <?= $pagination ?>
                        </div>
                    </div>
                </div>
                </div> <!-- End allListContainer -->

                <!-- My List Container -->
                <div id="myListContainer" class="hidden animate-fade-in-up">
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                         <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-100">
                                <thead>
                                    <tr class="bg-gray-50 border-b border-gray-200">
                                        <th scope="col" class="px-6 py-4 text-center w-10 align-middle">
                                            <input type="checkbox" class="form-checkbox h-4 w-4 text-brand-green border-gray-300 rounded focus:ring-brand-green/20 transition duration-150 ease-in-out cursor-pointer">
                                        </th>
                                        <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-brand-deep uppercase tracking-wider align-middle">Profile</th>
                                        <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-brand-deep uppercase tracking-wider align-middle">Username</th>
                                        <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-brand-deep uppercase tracking-wider align-middle">Platform</th>
                                        <th scope="col" class="px-6 py-4 text-left text-xs font-bold text-brand-deep uppercase tracking-wider align-middle">Date Transferred</th>
                                        <th scope="col" class="px-6 py-4 text-center text-xs font-bold text-brand-deep uppercase tracking-wider align-middle">Created by:</th>
                                        <th scope="col" class="px-6 py-4 text-right text-xs font-bold text-brand-deep uppercase tracking-wider align-middle">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-50 bg-white">
                                    <?php if(empty($influencers)): ?>
                                    <tr>
                                        <td colspan="7" class="px-6 py-12 text-center text-gray-500 text-sm">
                                            <div class="flex flex-col items-center justify-center">
                                                <div class="bg-gray-50 p-4 rounded-full mb-3">
                                                    <i class="fas fa-list-alt text-gray-300 text-2xl"></i>
                                                </div>
                                                <p class="font-medium text-gray-900">My List is Empty</p>
                                                <p class="text-xs text-gray-400 mt-1">Start adding influencers to your list.</p>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($influencers as $influencer): ?>
                                        <tr class="hover:bg-gray-50/80 transition-colors group">
                                            <td class="px-6 py-4 whitespace-nowrap align-middle text-center">
                                                <input type="checkbox" class="form-checkbox h-4 w-4 text-brand-green border-gray-300 rounded focus:ring-brand-green/20 transition duration-150 ease-in-out cursor-pointer">
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap align-middle flex justify-center">
                                                <div class="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 border border-gray-100 overflow-hidden">
                                                    <img src="https://ui-avatars.com/api/?name=<?= urlencode($influencer->username) ?>&background=random&color=fff&size=64&rounded=true" alt="<?= $influencer->username ?>" class="w-full h-full object-cover">
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap align-middle">
                                                <span class="text-sm font-medium text-gray-700"><?= $influencer->username ?></span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap align-middle">
                                                <div class="flex items-center gap-2">
                                                    <?php 
                                                        $platform = isset($influencer->platform) ? $influencer->platform : '-';
                                                        $iconClass = 'text-gray-400';
                                                        if (stripos($platform, 'Instagram') !== false) $iconClass = 'text-pink-600 fab fa-instagram';
                                                        elseif (stripos($platform, 'TikTok') !== false) $iconClass = 'text-black fab fa-tiktok';
                                                        elseif (stripos($platform, 'YouTube') !== false) $iconClass = 'text-red-600 fab fa-youtube';
                                                        else $iconClass = 'fas fa-globe text-gray-400';
                                                    ?>
                                                    <i class="<?= $iconClass ?> text-lg"></i>
                                                    <span class="text-sm text-gray-600"><?= $platform ?></span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap align-middle">
                                                <span class="text-sm text-gray-600"><?= date('F j, Y', strtotime($influencer->created_at)) ?></span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap align-middle text-center">
                                                <div class="flex justify-center">
                                                    <div class="h-8 w-8 rounded-full bg-pink-600 flex items-center justify-center text-white text-xs font-bold border-2 border-white shadow-sm" title="Created by Admin">
                                                        A
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium align-middle">
                                                <div class="flex items-center justify-end gap-3">
                                                    <button class="text-gray-400 hover:text-brand-blue transition-colors" title="Message">
                                                        <i class="fas fa-comment-alt"></i>
                                                    </button>
                                                    <button onclick="editInfluencer(<?= $influencer->id ?>)" class="text-gray-400 hover:text-brand-amber transition-colors" title="Edit">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </button>
                                                    <button onclick="confirmDeleteSingle(<?= $influencer->id ?>)" class="text-gray-400 hover:text-red-500 transition-colors" title="Delete">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <!-- Add Influencer Modal -->
    <div id="addInfluencerModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('addInfluencerModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full p-8 relative animate-fade-in-up">
                
                <button onclick="toggleModal('addInfluencerModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="text-center">
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Add New Influencer</h3>
                    <p class="text-sm text-gray-500 mb-8">Choose how you want to add an influencer to your list.</p>

                    <div class="space-y-4">
                        <button onclick="toggleModal('addInfluencerModal'); toggleModal('manualEntryModal'); resetForm('manualForm')" class="w-full bg-white border border-gray-200 hover:border-brand-blue hover:bg-blue-50/30 text-gray-700 font-semibold py-4 px-6 rounded-xl transition-all flex items-center group">
                            <div class="w-10 h-10 rounded-full bg-blue-100 text-brand-blue flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                                <i class="fas fa-pen"></i>
                            </div>
                            <div class="text-left">
                                <span class="block text-gray-900">Manual Entry</span>
                                <span class="text-xs text-gray-500 font-normal">Enter details manually</span>
                            </div>
                            <i class="fas fa-chevron-right ml-auto text-gray-300 group-hover:text-brand-blue transition-colors"></i>
                        </button>

                        <button onclick="toggleModal('addInfluencerModal'); toggleModal('addInstagramModal'); resetForm('instagramForm')" class="w-full bg-white border border-gray-200 hover:border-pink-500 hover:bg-pink-50/30 text-gray-700 font-semibold py-4 px-6 rounded-xl transition-all flex items-center group">
                            <div class="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 text-white flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                                <i class="fab fa-instagram"></i>
                            </div>
                            <div class="text-left">
                                <span class="block text-gray-900">Instagram Influencer</span>
                                <span class="text-xs text-gray-500 font-normal">Fetch from Instagram</span>
                            </div>
                            <i class="fas fa-chevron-right ml-auto text-gray-300 group-hover:text-pink-500 transition-colors"></i>
                        </button>
                        
                        <button onclick="toggleModal('addInfluencerModal'); toggleModal('addTiktokModal'); resetForm('tiktokForm')" class="w-full bg-white border border-gray-200 hover:border-black hover:bg-gray-50 text-gray-700 font-semibold py-4 px-6 rounded-xl transition-all flex items-center group">
                            <div class="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center mr-4 group-hover:scale-110 transition-transform">
                                <i class="fab fa-tiktok"></i>
                            </div>
                            <div class="text-left">
                                <span class="block text-gray-900">TikTok Creator</span>
                                <span class="text-xs text-gray-500 font-normal">Fetch from TikTok</span>
                            </div>
                            <i class="fas fa-chevron-right ml-auto text-gray-300 group-hover:text-black transition-colors"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Manual Entry Modal -->
    <div id="manualEntryModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('manualEntryModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl w-full p-8 relative animate-fade-in-up">
                
                <button onclick="toggleModal('manualEntryModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <h3 class="text-xl font-bold text-gray-900 mb-6">Add Manually</h3>

                <form id="manualForm" action="<?= base_url('influencer/save_manual') ?>" method="post">
                    <input type="hidden" name="id" id="manual_id">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Platform <span class="text-red-500">*</span></label>
                            <select name="platform" id="manual_platform" onchange="togglePlatformFields()" class="w-full bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors text-sm">
                                <option value="Instagram">Instagram</option>
                                <option value="TikTok">TikTok</option>
                                <option value="YouTube">YouTube</option>
                            </select>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Username <span class="text-red-500">*</span></label>
                            <input type="text" name="username" placeholder="@username" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors" required>
                        </div>

                        <div class="col-span-2">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Contact Info <span class="text-red-500">*</span></label>
                            <input type="text" name="contact_info" placeholder="Email or Phone" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Followers <span class="text-red-500">*</span></label>
                            <input type="number" name="followers" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Eng. Rate (%) <span class="text-red-500">*</span></label>
                            <input type="number" step="0.01" name="engagement_rate" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors" required>
                        </div>

                        <!-- TikTok Specific Fields -->
                        <div class="col-span-2 md:col-span-1 tiktok-field hidden">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Avg. Views</label>
                            <input type="number" name="avg_video_views" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors">
                        </div>
                        <div class="col-span-2 md:col-span-1 tiktok-field hidden">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">GMV ($)</label>
                            <input type="number" step="0.01" name="gmv" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors">
                        </div>
                        <div class="col-span-2 md:col-span-1 tiktok-field hidden">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Est. Post Rate ($)</label>
                            <input type="number" step="0.01" name="est_post_rate" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Location <span class="text-red-500">*</span></label>
                            <input type="text" name="location" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Niche <span class="text-red-500">*</span></label>
                            <select name="niche" class="w-full bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors text-sm">
                                <option value="">Select Niche</option>
                                <option value="Fashion">Fashion</option>
                                <option value="Tech">Tech</option>
                                <option value="Beauty">Beauty</option>
                                <option value="Travel">Travel</option>
                            </select>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Assessment</label>
                            <select name="assessment" class="w-full bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors text-sm">
                                <option value="">Pending</option>
                                <option value="Qualified">Qualified</option>
                                <option value="Not Qualified">Not Qualified</option>
                            </select>
                        </div>

                        <div class="col-span-2">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Notes</label>
                            <textarea name="notes" rows="3" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors"></textarea>
                        </div>
                    </div>

                    <div class="flex justify-end space-x-3 pt-4 border-t border-gray-100">
                        <button type="button" onclick="toggleModal('manualEntryModal')" class="px-6 py-2.5 text-gray-600 font-medium hover:text-gray-800 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" class="px-6 py-2.5 bg-brand-green hover:bg-green-600 text-white font-medium rounded-lg shadow-sm transition-all transform hover:-translate-y-0.5">
                            Save Influencer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Instagram Modal -->
    <div id="addInstagramModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('addInstagramModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full p-8 relative animate-fade-in-up">
                
                <button onclick="toggleModal('addInstagramModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 text-white flex items-center justify-center shadow-md">
                        <i class="fab fa-instagram text-xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Add Instagram Influencer</h3>
                </div>

                <form id="instagramForm" action="<?= base_url('influencer/save_instagram') ?>" method="post">
                    <input type="hidden" name="id" id="instagram_id">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div class="col-span-2">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Username <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">@</span>
                                <input type="text" name="username" placeholder="username" class="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors" required>
                            </div>
                        </div>
                        
                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Full Name</label>
                            <input type="text" name="full_name" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Email</label>
                            <input type="email" name="email" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Followers <span class="text-red-500">*</span></label>
                            <input type="number" name="followers" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Eng. Rate (%) <span class="text-red-500">*</span></label>
                            <input type="number" step="0.01" name="engagement_rate" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Location</label>
                            <input type="text" name="location" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Niche</label>
                            <select name="niche" class="w-full bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500/20 focus:border-pink-500 transition-colors text-sm">
                                <option value="">Select Niche</option>
                                <option value="Fashion">Fashion</option>
                                <option value="Tech">Tech</option>
                                <option value="Beauty">Beauty</option>
                                <option value="Travel">Travel</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex justify-end space-x-3 pt-4 border-t border-gray-100">
                        <button type="button" onclick="toggleModal('addInstagramModal')" class="px-6 py-2.5 text-gray-600 font-medium hover:text-gray-800 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" class="px-6 py-2.5 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-medium rounded-lg shadow-sm transition-all transform hover:-translate-y-0.5">
                            Save Influencer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- TikTok Modal -->
    <div id="addTiktokModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('addTiktokModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full p-8 relative animate-fade-in-up">
                
                <button onclick="toggleModal('addTiktokModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center shadow-md">
                        <i class="fab fa-tiktok text-xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Add TikTok Creator</h3>
                </div>

                <form id="tiktokForm" action="<?= base_url('influencer/save_tiktok') ?>" method="post">
                    <input type="hidden" name="id" id="tiktok_id">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div class="col-span-2">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">TikTok Handle <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">@</span>
                                <input type="text" name="username" placeholder="username" class="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors" required>
                            </div>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Full Name</label>
                            <input type="text" name="full_name" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Email</label>
                            <input type="email" name="email" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Followers <span class="text-red-500">*</span></label>
                            <input type="number" name="followers" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Eng. Rate (%) <span class="text-red-500">*</span></label>
                            <input type="number" step="0.01" name="engagement_rate" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors" required>
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Avg. Views</label>
                            <input type="number" name="avg_video_views" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">GMV ($)</label>
                            <input type="number" step="0.01" name="gmv" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Est. Post Rate ($)</label>
                            <input type="number" step="0.01" name="est_post_rate" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Location</label>
                            <input type="text" name="location" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors">
                        </div>

                        <div class="col-span-2 md:col-span-1">
                            <label class="block text-xs font-semibold text-gray-700 mb-1.5 uppercase">Niche</label>
                            <select name="niche" class="w-full bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-colors text-sm">
                                <option value="">Select Niche</option>
                                <option value="Fashion">Fashion</option>
                                <option value="Tech">Tech</option>
                                <option value="Beauty">Beauty</option>
                                <option value="Travel">Travel</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex justify-end space-x-3 pt-4 border-t border-gray-100">
                        <button type="button" onclick="toggleModal('addTiktokModal')" class="px-6 py-2.5 text-gray-600 font-medium hover:text-gray-800 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" class="px-6 py-2.5 bg-black hover:bg-gray-800 text-white font-medium rounded-lg shadow-sm transition-all transform hover:-translate-y-0.5">
                            Save Influencer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Import Modal -->
    <div id="importModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('importModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full p-8 relative animate-fade-in-up">
                
                <button onclick="toggleModal('importModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="flex flex-col items-center mb-6 text-center">
                    <div class="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mb-4">
                        <i class="fas fa-file-csv text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Import Influencers</h3>
                    <p class="text-sm text-gray-500 mt-1">Upload a CSV file to bulk add influencers.</p>
                    <a href="<?= base_url('influencer/download_template') ?>" class="inline-block mt-3 text-sm text-brand-blue hover:text-blue-700 font-medium hover:underline">
                        <i class="fas fa-download mr-1"></i> Download CSV Template
                    </a>
                </div>

                <form action="<?= base_url('influencer/import') ?>" method="post" enctype="multipart/form-data">
                    <div class="mb-6">
                        <label class="flex justify-center w-full h-32 px-4 transition bg-white border-2 border-gray-300 border-dashed rounded-xl appearance-none cursor-pointer hover:border-brand-blue focus:outline-none">
                            <span class="flex items-center space-x-2">
                                <i class="fas fa-cloud-upload-alt text-gray-400"></i>
                                <span class="font-medium text-gray-600">Drop CSV file or <span class="text-brand-blue underline">browse</span></span>
                            </span>
                            <input type="file" name="file" class="hidden" accept=".csv" required>
                        </label>
                        <p class="text-xs text-center text-gray-400 mt-3">Download <a href="#" class="text-brand-blue hover:underline">sample template</a></p>
                    </div>

                    <div class="flex justify-end space-x-3 pt-4 border-t border-gray-100">
                        <button type="button" onclick="toggleModal('importModal')" class="px-6 py-2.5 text-gray-600 font-medium hover:text-gray-800 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" class="px-6 py-2.5 bg-brand-blue hover:bg-blue-600 text-white font-medium rounded-lg shadow-sm transition-all transform hover:-translate-y-0.5">
                            Import Data
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Influencer Detail Modal -->
    <div id="influencerDetailModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('influencerDetailModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl w-full relative animate-fade-in-up">
                
                <button onclick="toggleModal('influencerDetailModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors z-10">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <!-- Header Section -->
                <div class="bg-white px-8 pt-8 pb-4 border-b border-gray-100">
                    <div class="flex flex-wrap gap-6 mb-4">
                        <div class="w-48">
                            <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Status</label>
                            <select id="detail_status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium text-gray-900 focus:outline-none focus:border-brand-blue">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="w-48">
                            <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Pipeline status</label>
                            <select id="detail_pipeline_status" class="w-full border-2 border-yellow-300 rounded-lg px-3 py-2 text-sm font-medium text-gray-900 focus:outline-none focus:border-yellow-400">
                                <option value="For Outreach">For Outreach</option>
                                <option value="Contacted">Contacted</option>
                                <option value="Replied">Replied</option>
                                <option value="In - Progress">In - Progress</option>
                                <option value="Completed">Completed</option>
                                <option value="Not Interested">Not Interested</option>
                            </select>
                        </div>
                        <div class="w-48">
                            <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Campaign type</label>
                            <select id="detail_campaign_type" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium text-gray-900 focus:outline-none focus:border-brand-blue">
                                <option value="">Select Type</option>
                                <option value="Seeding">Seeding</option>
                                <option value="Paid">Paid</option>
                                <option value="Affiliate">Affiliate</option>
                            </select>
                        </div>
                    </div>

                    <!-- Tabs -->
                    <div class="flex items-center gap-8 mt-6 overflow-x-auto">
                        <button onclick="switchTab('basic')" id="tab-btn-basic" class="tab-btn flex items-center gap-2 pb-3 border-b-2 border-black text-sm font-bold text-gray-900 whitespace-nowrap">
                            <i class="fas fa-info-circle"></i> Basic Information
                        </button>
                        <button onclick="switchTab('order')" id="tab-btn-order" class="tab-btn flex items-center gap-2 pb-3 border-b-2 border-transparent text-sm font-medium text-gray-400 hover:text-gray-600 transition-colors whitespace-nowrap">
                            <i class="fas fa-shopping-cart"></i> Order Details
                        </button>
                        <button class="flex items-center gap-2 pb-3 border-b-2 border-transparent text-sm font-medium text-gray-400 hover:text-gray-600 transition-colors whitespace-nowrap">
                            <i class="fas fa-chart-bar"></i> Post Insight
                        </button>
                        <button class="flex items-center gap-2 pb-3 border-b-2 border-transparent text-sm font-medium text-gray-400 hover:text-gray-600 transition-colors whitespace-nowrap">
                            <i class="fas fa-chart-line"></i> Statistics
                        </button>
                    </div>
                </div>

                <!-- Content Section -->
                <div class="p-8 bg-brand-offwhite max-h-[70vh] overflow-y-auto">
                    <form id="detailForm" onsubmit="event.preventDefault(); saveDetail();">
                        <input type="hidden" id="detail_id" name="id">
                        
                        <!-- Action Buttons (Always Visible) -->
                        <div class="flex justify-end gap-3 mb-8">
                            <button type="submit" class="bg-blue-800 hover:bg-blue-900 text-white font-bold py-2 px-6 rounded-lg shadow-sm transition-colors">
                                Save
                            </button>
                            <button type="button" onclick="toggleModal('influencerDetailModal')" class="bg-blue-800 hover:bg-blue-900 text-white font-bold py-2 px-6 rounded-lg shadow-sm transition-colors">
                                Cancel
                            </button>
                        </div>

                        <!-- Basic Information Tab -->
                        <div id="tab-basic" class="tab-content">
                            <!-- Metrics Row -->
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                                <div>
                                    <label class="block text-sm font-bold text-brand-blue mb-2"><i class="fas fa-users mr-1"></i> Followers</label>
                                    <input type="text" id="detail_followers_input" name="followers" class="w-full bg-white border border-gray-300 rounded-lg p-3 text-lg font-bold text-gray-900 focus:border-brand-blue focus:ring-1 focus:ring-brand-blue outline-none transition-all shadow-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-bold text-brand-blue mb-2"><i class="fas fa-chart-pie mr-1"></i> Eng. rate</label>
                                    <input type="text" id="detail_eng_rate_input" name="engagement_rate" class="w-full bg-white border border-gray-300 rounded-lg p-3 text-lg font-bold text-gray-900 focus:border-brand-blue focus:ring-1 focus:ring-brand-blue outline-none transition-all shadow-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-bold text-brand-blue mb-2"><i class="fas fa-play-circle mr-1"></i> Avg. Views</label>
                                    <input type="text" id="detail_avg_views_input" name="avg_video_views" class="w-full bg-white border border-brand-blue rounded-lg p-3 text-lg font-bold text-gray-900 focus:ring-2 focus:ring-brand-blue/20 outline-none transition-all shadow-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-bold text-brand-blue mb-2"><i class="fas fa-bullhorn mr-1"></i> GMV</label>
                                    <input type="text" id="detail_gmv_input" name="gmv" class="w-full bg-white border border-gray-300 rounded-lg p-3 text-lg font-bold text-gray-900 focus:border-brand-blue focus:ring-1 focus:ring-brand-blue outline-none transition-all shadow-sm">
                                </div>
                            </div>



                        <!-- Details Grid -->
                        <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
                                <!-- Email -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Email</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="email" id="detail_email_input" name="email" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                        <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- Last Name -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Last Name</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_last_name_input" name="last_name" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- First Name -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">First Name</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_first_name_input" name="first_name" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>
                                
                                 <!-- Username -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Username</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_username_input" name="username" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- Platform -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Platform</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_platform_input" name="platform" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- IG Username -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">IG Username</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_ig_username_input" name="ig_username" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- Location -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Location</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_location_input" name="location" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- Niche -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Niche</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <input type="text" id="detail_niche_input" name="niche" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                         <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>

                                <!-- Assessment -->
                                <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                    <span class="font-bold text-gray-900">Assessment</span>
                                    <div class="flex items-center gap-2 flex-1 justify-end">
                                        <select id="detail_assessment_input" name="assessment" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full dir-rtl">
                                            <option value="">Pending</option>
                                            <option value="Qualified">Qualified</option>
                                            <option value="Not Qualified">Not Qualified</option>
                                        </select>
                                        <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Notes -->
                        <div>
                            <label class="block text-sm font-bold text-gray-900 mb-2">Notes</label>
                            <textarea id="detail_notes_input" name="notes" rows="4" class="w-full bg-white border border-gray-300 rounded-lg p-3 text-sm text-gray-700 focus:border-brand-blue focus:ring-1 focus:ring-brand-blue outline-none transition-all shadow-sm"></textarea>
                        </div>
                        </div> <!-- End tab-basic -->

                        <!-- Order Details Tab -->
                        <div id="tab-order" class="tab-content hidden">
                            <div class="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
                                    
                                    <!-- First Name -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">First Name</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_first_name_order" readonly class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                        </div>
                                    </div>

                                    <!-- Last Name -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Last Name</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_last_name_order" readonly class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                        </div>
                                    </div>

                                    <!-- Contact Number -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Contact Number</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_contact_number" name="contact_number" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Product Name -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Product Name</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_product_name" name="product_name" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Order Number -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Order Number</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_order_number" name="order_number" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Product Cost -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Product Cost</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_product_cost" name="product_cost" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Discount Code -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Discount Code</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_discount_code" name="discount_code" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Affiliate Link -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Affiliate Link</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_affiliate_link" name="affiliate_link" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Shipping Address -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Shipping Address</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_shipping_address" name="shipping_address" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                    <!-- Tracking Link -->
                                    <div class="group flex items-center justify-between border-b border-gray-100 pb-2">
                                        <span class="font-bold text-gray-900">Tracking Link</span>
                                        <div class="flex items-center gap-2 flex-1 justify-end">
                                            <input type="text" id="detail_tracking_link" name="tracking_link" class="text-right text-gray-600 bg-transparent border-none focus:ring-0 p-0 w-full" placeholder="-">
                                            <i class="fas fa-pen text-brand-blue text-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"></i>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Pipeline Stage Selection Modal (For Bulk Action) -->
    <div id="pipelineStageModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('pipelineStageModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-sm w-full p-6 relative animate-fade-in-up">
                <button onclick="toggleModal('pipelineStageModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
                
                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-full bg-blue-50 text-brand-blue flex items-center justify-center">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900">Add to Pipeline</h3>
                </div>

                <form id="bulkPipelineForm" action="<?= base_url('influencer/bulk_add_pipeline') ?>" method="post">
                    <input type="hidden" name="ids" id="bulk_influencer_ids">
                    <div class="mb-6">
                        <label class="block text-xs font-semibold text-gray-700 mb-2 uppercase">Select Stage</label>
                        <select name="stage" class="w-full bg-gray-50 border border-gray-200 text-gray-900 py-2.5 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors text-sm">
                            <option value="For Outreach">For Outreach</option>
                            <option value="Contacted">Contacted</option>
                            <option value="Replied">Replied</option>
                            <option value="In - Progress">In - Progress</option>
                            <option value="Not Interested">Not Interested</option>
                        </select>
                        <p class="text-xs text-gray-500 mt-2">Selected influencers will be moved to this stage.</p>
                    </div>
                    <div class="flex justify-end space-x-3">
                         <button type="button" onclick="toggleModal('pipelineStageModal')" class="px-4 py-2 text-gray-600 text-sm font-medium hover:text-gray-800 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-brand-blue hover:bg-blue-600 text-white text-sm font-medium rounded-lg shadow-sm transition-all">
                            Move to Pipeline
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteConfirmationModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('deleteConfirmationModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-sm w-full p-6 relative animate-fade-in-up">
                <button onclick="toggleModal('deleteConfirmationModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
                
                <div class="flex items-center justify-center w-12 h-12 mx-auto bg-red-100 rounded-full mb-4">
                    <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                </div>
                
                <div class="text-center mb-6">
                    <h3 class="text-lg font-bold text-gray-900">Delete Influencers?</h3>
                    <p class="text-sm text-gray-500 mt-2">Are you sure you want to delete <span id="deleteCount" class="font-bold text-gray-800">0</span> influencer(s)? This action cannot be undone.</p>
                </div>

                <div class="flex justify-center space-x-3">
                     <button type="button" onclick="toggleModal('deleteConfirmationModal')" class="px-4 py-2 text-gray-600 text-sm font-medium hover:text-gray-800 transition-colors">
                        Cancel
                    </button>
                    <button type="button" onclick="executeDelete()" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg shadow-sm transition-all">
                        Delete
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="fixed inset-0 z-[60] bg-white/80 backdrop-blur-sm hidden flex items-center justify-center transition-opacity duration-300">
        <div class="flex flex-col items-center">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-green"></div>
            <p class="mt-4 text-sm font-medium text-gray-600">Loading...</p>
        </div>
    </div>

    <script>
        let deleteAction = null;

        function showLoading() {
             const overlay = document.getElementById('loadingOverlay');
             if(overlay) overlay.classList.remove('hidden');
        }

        function hideLoading() {
             const overlay = document.getElementById('loadingOverlay');
             if(overlay) overlay.classList.add('hidden');
        }
        
        // Attach loading to forms
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('form').forEach(form => {
                // Skip bulk pipeline form as we handle it manually
                if (form.id === 'bulkPipelineForm') return;
                
                form.addEventListener('submit', function() {
                    if(!this.target) showLoading(); 
                });
            });

            // Handle Bulk Pipeline Form
            const bulkPipelineForm = document.getElementById('bulkPipelineForm');
            if (bulkPipelineForm) {
                bulkPipelineForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    showLoading();
                    
                    const formData = new FormData(this);
                    
                    fetch(this.action, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            window.location.reload();
                        } else {
                            hideLoading();
                            alert(data.message || 'Error moving influencers to pipeline');
                        }
                    })
                    .catch(error => {
                        hideLoading();
                        console.error('Error:', error);
                        alert('An error occurred');
                    });
                });
            }
        });

        function confirmDeleteSingle(id) {
            document.getElementById('deleteCount').textContent = '1';
            toggleModal('deleteConfirmationModal');
            deleteAction = function() {
                window.location.href = '<?= base_url('influencer/delete/') ?>' + id;
            };
        }

        function executeDelete() {
            if (deleteAction) {
                deleteAction();
            }
        }

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            if (sidebar.classList.contains('hidden')) {
                sidebar.classList.remove('hidden');
            } else {
                sidebar.classList.add('hidden');
            }
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });

        function togglePlatformFields() {
            const platform = document.getElementById('manual_platform').value;
            const tiktokFields = document.querySelectorAll('.tiktok-field');
            
            if (platform === 'TikTok') {
                tiktokFields.forEach(field => field.classList.remove('hidden'));
            } else {
                tiktokFields.forEach(field => field.classList.add('hidden'));
            }
        }

        // Auto-dismiss flash messages
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.bg-green-50, .bg-red-50');
                alerts.forEach(alert => {
                    alert.style.transition = 'opacity 0.5s ease-out';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                });
            }, 5000);
        });

        function toggleModal(modalID) {
            const modal = document.getElementById(modalID);
            if (modal) {
                if (modal.classList.contains('hidden')) {
                    modal.classList.remove('hidden');
                    document.body.style.overflow = 'hidden';
                } else {
                    modal.classList.add('hidden');
                    document.body.style.overflow = 'auto';
                }
            }
        }

        function resetForm(formId) {
            const form = document.getElementById(formId);
            if (form) {
                form.reset();
                if (formId === 'manualForm') document.getElementById('manual_id').value = '';
                if (formId === 'instagramForm') document.getElementById('instagram_id').value = '';
                if (formId === 'tiktokForm') document.getElementById('tiktok_id').value = '';
            }
        }

        function toggleFilters() {
            const filters = document.getElementById('mainFilterOptionsRow');
            if (filters.classList.contains('hidden')) {
                filters.classList.remove('hidden');
            } else {
                filters.classList.add('hidden');
            }
        }

        // Centralized Bulk Actions Renderer
        function renderBulkActions() {
            const allCheckboxes = document.querySelectorAll('.influencer-checkbox');
            const checkedCheckboxes = document.querySelectorAll('.influencer-checkbox:checked');
            const bulkActions = document.getElementById('bulkActions');
            const selectedCount = document.getElementById('selectedCount');
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            
            const checkedCount = checkedCheckboxes.length;
            const totalCount = allCheckboxes.length;

            // Update Select All checkbox state
            if (selectAllCheckbox) {
                if (totalCount > 0 && checkedCount === totalCount) {
                    selectAllCheckbox.checked = true;
                    selectAllCheckbox.indeterminate = false;
                } else if (checkedCount === 0) {
                    selectAllCheckbox.checked = false;
                    selectAllCheckbox.indeterminate = false;
                } else {
                    selectAllCheckbox.checked = false;
                    selectAllCheckbox.indeterminate = true;
                }
            }

            // Update Bulk Actions Container Visibility
            if (checkedCount > 0) {
                if (bulkActions) {
                    bulkActions.classList.remove('hidden');
                    bulkActions.style.display = 'flex';
                }
                
                if (selectedCount) selectedCount.textContent = checkedCount;
            } else {
                if (bulkActions) {
                    bulkActions.classList.add('hidden');
                    bulkActions.style.display = 'none';
                }
            }
        }

        // Bulk Actions Logic
        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.influencer-checkbox');
            
            // Set all checkboxes to match the source
            checkboxes.forEach(cb => {
                cb.checked = source.checked;
            });
            
            renderBulkActions();
        }

        function updateBulkButtonsState() {
            renderBulkActions();
        }

        function bulkAddPipeline() {
            const checkboxes = document.querySelectorAll('.influencer-checkbox:checked');
            const ids = Array.from(checkboxes).map(cb => cb.value);
            if (ids.length > 0) {
                document.getElementById('bulk_influencer_ids').value = ids.join(',');
                toggleModal('pipelineStageModal');
            }
        }
        
        function bulkExport() {
            const checkboxes = document.querySelectorAll('.influencer-checkbox:checked');
            const ids = Array.from(checkboxes).map(cb => cb.value);
            
            if (ids.length > 0) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '<?= base_url('influencer/export_selected_csv') ?>';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'ids';
                input.value = ids.join(',');
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
                document.body.removeChild(form);
            }
        }
        
        function deleteSelected() {
             const checkboxes = document.querySelectorAll('.influencer-checkbox:checked');
             if (checkboxes.length > 0) {
                 document.getElementById('deleteCount').textContent = checkboxes.length;
                 toggleModal('deleteConfirmationModal');
                 
                 deleteAction = function() {
                     showLoading();
                     const ids = Array.from(checkboxes).map(cb => cb.value);
                     const form = document.createElement('form');
                     form.method = 'POST';
                     form.action = '<?= base_url('influencer/delete_selected') ?>'; // Fixed endpoint
                     const input = document.createElement('input');
                     input.type = 'hidden';
                     input.name = 'ids';
                     input.value = ids.join(',');
                     form.appendChild(input);
                     document.body.appendChild(form);
                     
                     // Use fetch for AJAX delete to avoid reload if preferred, or submit for reload
                     // Using fetch here for smoother experience + reload
                     const formData = new FormData(form);
                     fetch(form.action, {
                         method: 'POST',
                         body: formData
                     }).then(response => response.json())
                       .then(data => {
                           if(data.status === 'success') {
                               window.location.reload();
                           } else {
                               hideLoading();
                               alert('Error deleting items');
                           }
                       }).catch(err => {
                           hideLoading();
                           console.error(err);
                       });
                 };
             }
        }

        function setVal(id, val) {
            const el = document.getElementById(id);
            if(el) el.value = val !== null && val !== undefined ? val : '';
        }

        function switchTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            // Show selected
            const target = document.getElementById('tab-' + tabName);
            if(target) target.classList.remove('hidden');

            // Update buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('border-black', 'text-gray-900', 'font-bold');
                btn.classList.add('border-transparent', 'text-gray-400', 'font-medium');
            });
            const activeBtn = document.getElementById('tab-btn-' + tabName);
            if(activeBtn) {
                activeBtn.classList.remove('border-transparent', 'text-gray-400', 'font-medium');
                activeBtn.classList.add('border-black', 'text-gray-900', 'font-bold');
            }
        }

        function openDetailModal(id) {
            showLoading();
            // Reset tab
            switchTab('basic');
            
            fetch('<?= base_url('influencer/get_data/') ?>' + id)
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    
                    // ID
                    setVal('detail_id', data.id);

                    // Header Dropdowns
                    setVal('detail_status', data.status || 'Active');
                    setVal('detail_pipeline_status', data.pipeline_status || 'For Outreach');
                    setVal('detail_campaign_type', data.campaign_type || '');

                    // Metrics
                    setVal('detail_followers_input', data.followers);
                    setVal('detail_eng_rate_input', data.engagement_rate || data.eng_rate);
                    setVal('detail_avg_views_input', data.avg_video_views);
                    setVal('detail_gmv_input', data.gmv);

                    // Basic Info
                    setVal('detail_email_input', data.email);
                    setVal('detail_last_name_input', data.last_name);
                    setVal('detail_first_name_input', data.first_name);
                    setVal('detail_username_input', data.username);
                    setVal('detail_platform_input', data.platform);
                    setVal('detail_ig_username_input', data.ig_username);
                    setVal('detail_location_input', data.location);
                    setVal('detail_niche_input', data.niche);
                    setVal('detail_assessment_input', data.assessment);
                    setVal('detail_notes_input', data.notes);
                    
                    // Order Details
                    setVal('detail_first_name_order', data.first_name);
                    setVal('detail_last_name_order', data.last_name);
                    setVal('detail_contact_number', data.contact_number);
                    setVal('detail_product_name', data.product_name);
                    setVal('detail_order_number', data.order_number);
                    setVal('detail_product_cost', data.product_cost);
                    setVal('detail_discount_code', data.discount_code);
                    setVal('detail_affiliate_link', data.affiliate_link);
                    setVal('detail_shipping_address', data.shipping_address);
                    setVal('detail_tracking_link', data.tracking_link);

                    toggleModal('influencerDetailModal');
                })
                .catch(error => {
                    console.error('Error:', error);
                    hideLoading();
                });
        }

        function saveDetail() {
            showLoading();
            const form = document.getElementById('detailForm');
            const formData = new FormData(form);
            
            // Add header fields manually since they are outside the form tag
            const pipelineStatus = document.getElementById('detail_pipeline_status');
            const campaignType = document.getElementById('detail_campaign_type');
            const status = document.getElementById('detail_status');
            
            if(pipelineStatus) formData.append('pipeline_status', pipelineStatus.value);
            if(campaignType) formData.append('campaign_type', campaignType.value);
            if(status) formData.append('status', status.value);

            fetch('<?= base_url('influencer/update_detail_ajax') ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if(data.status === 'success') {
                    // Show success feedback
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-[70] animate-fade-in-up';
                    alertDiv.innerHTML = '<i class="fas fa-check-circle mr-2"></i> Saved successfully';
                    document.body.appendChild(alertDiv);
                    
                    setTimeout(() => {
                        alertDiv.remove();
                        toggleModal('influencerDetailModal');
                        window.location.reload(); 
                    }, 1000);
                } else {
                    alert('Error: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                hideLoading();
                console.error('Error:', error);
                alert('An error occurred while saving.');
            });
        }

        function editInfluencer(id) {
            showLoading();
            fetch('<?= base_url('influencer/get_data/') ?>' + id)
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    // Populate manual form for editing
                    const form = document.getElementById('manualForm');
                    document.getElementById('manual_id').value = data.id;
                    if(form.elements['platform']) {
                        form.elements['platform'].value = data.platform;
                        togglePlatformFields(); // Trigger visibility toggle
                    }
                    if(form.elements['username']) form.elements['username'].value = data.username;
                    if(form.elements['contact_info']) form.elements['contact_info'].value = data.email || data.contact_info; 
                    if(form.elements['followers']) form.elements['followers'].value = data.followers;
                    if(form.elements['engagement_rate']) form.elements['engagement_rate'].value = data.engagement_rate || data.eng_rate;
                    if(form.elements['location']) form.elements['location'].value = data.location;
                    if(form.elements['niche']) form.elements['niche'].value = data.niche;
                    if(form.elements['assessment']) form.elements['assessment'].value = data.assessment || '';

                    if(form.elements['notes']) form.elements['notes'].value = data.notes || '';
                    
                    // Populate TikTok Specific Fields if they exist
                    if(form.elements['avg_video_views']) form.elements['avg_video_views'].value = data.avg_video_views || '';
                    if(form.elements['gmv']) form.elements['gmv'].value = data.gmv || '';
                    if(form.elements['est_post_rate']) form.elements['est_post_rate'].value = data.est_post_rate || '';
                    
                    toggleModal('manualEntryModal');
                })
                .catch(error => {
                    console.error('Error:', error);
                    hideLoading();
                });
        }

        function quickAssess(id, status) {
            if (status === 'Not Qualified') {
                // Open Disqualification Modal
                document.getElementById('disqualify_id').value = id;
                document.getElementById('disqualify_reason').value = ''; // Reset reason
                toggleModal('disqualificationModal');
                return;
            }

            // Existing logic for Qualified
            performAssessmentUpdate(id, status);
        }

        function submitDisqualification() {
            const id = document.getElementById('disqualify_id').value;
            const reason = document.getElementById('disqualify_reason').value;
            
            if (!reason.trim()) {
                alert('Please enter a reason.');
                return;
            }

            performAssessmentUpdate(id, 'Not Qualified', reason);
        }

        function performAssessmentUpdate(id, status, reason = '') {
            showLoading();
            const formData = new FormData();
            formData.append('id', id);
            formData.append('assessment', status);
            if (reason) {
                formData.append('notes', reason);
            }

            fetch('<?= base_url('influencer/update_assessment_ajax') ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoading();
                if(data.status === 'success') {
                    // Close modal if open
                    const modal = document.getElementById('disqualificationModal');
                    if (!modal.classList.contains('hidden')) {
                        toggleModal('disqualificationModal');
                    }

                    // Update the UI immediately
                    const label = document.getElementById('assessment-label-' + id);
                    if(label) {
                        label.innerText = status;
                        label.className = 'text-sm font-semibold ' + 
                            (status === 'Qualified' ? 'text-green-600' : 
                             (status === 'Not Qualified' ? 'text-red-600' : 'text-gray-500'));
                    }
                    
                    // Show success feedback
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-[70] animate-fade-in-up';
                    alertDiv.innerHTML = '<i class="fas fa-check-circle mr-2"></i> Assessment Updated';
                    document.body.appendChild(alertDiv);
                    
                    setTimeout(() => {
                        alertDiv.remove();
                        // Reload to show pipeline change or updated notes
                        window.location.reload();
                    }, 1000);
                } else {
                    alert('Error: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                hideLoading();
                console.error('Error:', error);
                alert('An error occurred.');
            });
        }
    </script>
    <!-- Disqualification Reason Modal -->
    <div id="disqualificationModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('disqualificationModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full p-8 relative animate-fade-in-up">
                
                <button onclick="toggleModal('disqualificationModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="text-center">
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Disqualification Reason</h3>
                    <p class="text-sm text-gray-500 mb-6">Please specify why this influencer is not qualified.</p>
                </div>

                <div class="space-y-4">
                    <input type="hidden" id="disqualify_id">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Reason / Notes</label>
                        <textarea id="disqualify_reason" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue/20 focus:border-brand-blue transition-colors text-sm resize-none" placeholder="Enter reason..."></textarea>
                    </div>

                    <div class="flex gap-3 pt-2">
                        <button type="button" onclick="toggleModal('disqualificationModal')" class="flex-1 px-4 py-2.5 bg-gray-100 text-gray-700 rounded-lg text-sm font-bold hover:bg-gray-200 transition-colors">
                            Cancel
                        </button>
                        <button type="button" onclick="submitDisqualification()" class="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-200">
                            Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Confirmation Modal -->
    <div id="deleteConfirmationModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-sm" aria-hidden="true" onclick="toggleModal('deleteConfirmationModal')"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-md w-full p-6 relative animate-fade-in-up">
                
                <button onclick="toggleModal('deleteConfirmationModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 focus:outline-none transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="text-center">
                    <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
                        <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                    </div>
                    <h3 class="text-lg leading-6 font-bold text-gray-900 mb-2">Delete Influencers</h3>
                    <p class="text-sm text-gray-500 mb-6">Are you sure you want to delete <span id="deleteCount" class="font-bold text-gray-900">0</span> selected influencer(s)? This action cannot be undone.</p>
                </div>

                <div class="flex gap-3">
                    <button type="button" onclick="toggleModal('deleteConfirmationModal')" class="flex-1 px-4 py-2.5 bg-gray-100 text-gray-700 rounded-lg text-sm font-bold hover:bg-gray-200 transition-colors">
                        Cancel
                    </button>
                    <button type="button" onclick="deleteAction()" class="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-200">
                        Yes, Delete
                    </button>
                </div>
            </div>
        </div>
    </div>
    <script>
        function toggleMyList() {
            const allList = document.getElementById('allListContainer');
            const myList = document.getElementById('myListContainer');
            const btn = document.getElementById('myListBtn');
            
            if (myList.classList.contains('hidden')) {
                // Show My List
                allList.classList.add('hidden');
                myList.classList.remove('hidden');
                
                // Update button
                btn.innerHTML = '<i class="fas fa-users mr-2 text-gray-400 group-hover:text-gray-600 transition-colors"></i> All List';
            } else {
                // Show All List
                myList.classList.add('hidden');
                allList.classList.remove('hidden');
                
                // Update button
                btn.innerHTML = '<i class="fas fa-list mr-2 text-gray-400 group-hover:text-gray-600 transition-colors"></i> My List';
            }
        }
    </script>
</body>
</html>
