<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Influencer Discovery - Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827',
                            gray: '#F9FAFB',
                            border: '#E5E7EB',
                            blue: '#3B82F6',
                            purple: '#8B5CF6',
                            rose: '#F43F5E',
                            amber: '#F59E0B'
                        }
                    },
                    boxShadow: {
                        'card': '0 2px 5px -1px rgba(0, 0, 0, 0.05), 0 1px 3px -1px rgba(0, 0, 0, 0.03)',
                        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)',
                    }
                }
            }
        }

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('absolute');
            sidebar.classList.toggle('h-full');
            sidebar.classList.toggle('z-40');
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });

        // Add Influencer AJAX
        function addInfluencer(influencerData, btnElement) {
            const originalText = btnElement.innerHTML;
            const originalClasses = btnElement.className;
            
            btnElement.innerHTML = '<i class="fas fa-spinner fa-spin text-xs"></i> Saving...';
            btnElement.disabled = true;

            $.ajax({
                url: '<?php echo base_url("discovery/add"); ?>',
                type: 'POST',
                data: influencerData,
                dataType: 'json',
                success: function(response) {
                    if(response.status === 'success') {
                        btnElement.innerHTML = '<i class="fas fa-check text-xs"></i> Saved';
                        // Remove initial styling classes
                        btnElement.classList.remove('bg-white', 'text-gray-600', 'border-gray-200', 'hover:border-brand-green', 'hover:text-brand-green', 'shadow-sm');
                        // Add success styling classes
                        btnElement.classList.add('bg-green-50', 'text-green-600', 'border-green-200', 'cursor-default');
                        showToast('Success', 'Influencer added to your list!');
                    } else {
                        btnElement.innerHTML = originalText;
                        btnElement.disabled = false;
                        showToast('Error', response.message || 'Failed to add influencer.');
                    }
                },
                error: function() {
                    btnElement.innerHTML = originalText;
                    btnElement.disabled = false;
                    showToast('Error', 'Server error. Please try again.');
                }
            });
        }

        function showToast(title, message) {
            const toast = document.getElementById('toast');
            const icon = toast.querySelector('i');
            const titleEl = toast.querySelector('h4');
            const msgEl = toast.querySelector('p');

            titleEl.textContent = title;
            msgEl.textContent = message;

            if(title === 'Error') {
                icon.className = 'fas fa-exclamation-circle text-red-500 text-xl';
                toast.classList.replace('border-brand-green', 'border-red-500');
            } else {
                icon.className = 'fas fa-check-circle text-brand-green text-xl';
                toast.classList.replace('border-red-500', 'border-brand-green');
            }

            toast.classList.remove('hidden', 'translate-y-full');
            
            setTimeout(() => {
                toast.classList.add('translate-y-full');
                setTimeout(() => {
                    toast.classList.add('hidden');
                }, 300);
            }, 3000);
        }
        
        function setPlatform(p) {
            const select = document.querySelector('select[name="platform"]');
            if (!select) return;
            select.value = p;
            updatePlatformTabs(p);
            updatePlatformIcon(p);
        }

        function updatePlatformTabs(active) {
            document.querySelectorAll('[data-platform-tab]').forEach(btn => {
                const val = btn.getAttribute('data-platform-tab');
                if (val === active) {
                    btn.classList.add('bg-brand-green','text-white');
                    btn.classList.remove('bg-white','text-gray-700','border-gray-200');
                } else {
                    btn.classList.add('bg-white','text-gray-700','border-gray-200');
                    btn.classList.remove('bg-brand-green','text-white');
                }
            });
        }

        function updatePlatformIcon(active) {
            const icon = document.getElementById('platformIcon');
            if (!icon) return;
            if (active === 'youtube') {
                icon.className = 'fab fa-youtube text-red-600';
            } else if (active === 'instagram') {
                icon.className = 'fab fa-instagram text-pink-600';
            } else if (active === 'tiktok') {
                icon.className = 'fab fa-tiktok text-black';
            } else {
                icon.className = 'fas fa-globe text-gray-400';
            }
        }

        function showPageLoading() {
            const el = document.getElementById('page-loading');
            if (el) el.classList.remove('hidden');
        }

        document.addEventListener('DOMContentLoaded', () => {
            const select = document.querySelector('select[name="platform"]');
            if (select) {
                updatePlatformTabs(select.value);
                updatePlatformIcon(select.value);
                select.addEventListener('change', (e) => {
                    updatePlatformTabs(e.target.value);
                    updatePlatformIcon(e.target.value);
                });
            }
        });
    </script>
    <link href="<?php echo base_url('assets/css/discovery.css'); ?>" rel="stylesheet">
</head>
<body class="bg-gray-50 h-screen flex overflow-hidden text-gray-800">

    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 bg-[#0F6B3E] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex fixed md:relative z-30 h-full top-0 left-0 shadow-xl">
        <div class="h-16 flex items-center px-8 border-b border-white/10">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bolt text-brand-green text-lg"></i>
                    </div>
                    <span class="text-xl font-bold tracking-tight text-white">INSTROOM</span>
                </div>
                <button class="md:hidden text-white/70 hover:text-white transition-colors focus:outline-none" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Main Menu</p>
            
            <a href="<?php echo base_url('welcome'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-tachometer-alt w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            
            <a href="<?php echo base_url('discovery'); ?>" class="sidebar-item active group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white bg-white/5">
                <i class="fas fa-search w-6 text-lg opacity-100 transition-opacity"></i>
                <span class="ml-3">Discovery</span>
            </a>
            
            <a href="<?php echo base_url('influencer'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-list-ul w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Influencer List</span>
            </a>

            <a href="<?php echo base_url('influencer/pipeline'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-filter w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Pipeline</span>
            </a>

            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mt-8 mb-3">Campaigns</p>

            <a href="<?php echo base_url('influencer/closed_collaborations'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="far fa-check-square w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Closed</span>
            </a>
            
            <a href="#" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-users w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Ambassadors</span>
            </a>
            
            <a href="<?php echo base_url('influencer/analytics'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-chart-line w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Analytics</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden relative bg-white">
        
        <!-- Top Navigation -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-20 sticky top-0">
            <div class="flex items-center md:hidden">
                <button class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 rounded-md hover:bg-gray-100 transition-colors" onclick="toggleSidebar()">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <span class="ml-4 text-lg font-bold text-brand-deep">INSTROOM</span>
            </div>
            
            <div class="hidden md:flex items-center text-gray-500 text-sm font-medium">
                <span class="text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">Influencer</span>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <span class="text-brand-deep bg-green-50 px-2 py-1 rounded-md">Discovery</span>
            </div>

            <div class="flex items-center gap-4">
                <button class="relative p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100">
                    <i class="far fa-bell text-xl"></i>
                    <span class="absolute top-1.5 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div class="h-8 w-px bg-gray-200 mx-2"></div>

                <!-- User Dropdown -->
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-deep transition-colors"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user_role) ? ucfirst($user_role) : 'User'; ?></p>
                        </div>
                        <div class="relative">
                             <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'User'); ?>&background=1FAE5B&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-white group-hover:border-brand-green transition-all">
                             <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-deep transition-colors"></i>
                    </button>
                    
                    <!-- Dropdown -->
                    <div id="user-menu" class="hidden absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-50 animate-fade-in-up origin-top-right">
                        <div class="px-4 py-3 border-b border-gray-50">
                            <p class="text-sm font-semibold text-gray-900 truncate"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500 truncate"><?php echo isset($user_email) ? $user_email : ''; ?></p>
                        </div>
                        
                        <?php if(isset($user_role) && $user_role === 'admin'): ?>
                        <a href="<?php echo base_url('admin'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-tachometer-alt w-5 text-gray-400"></i> Admin Dashboard
                        </a>
                        <?php endif; ?>

                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5 text-gray-400"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5 text-gray-400"></i> Settings
                        </a>
                        
                        <div class="border-t border-gray-50 my-1"></div>
                        
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 relative">
            
            <!-- Decorative Background (Clouds/Cityscape Abstract) -->
            <div class="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-green-50 to-gray-50 -z-10"></div>
            
            <div class="max-w-7xl mx-auto px-6 py-12">

                <!-- Hero Section -->
                <div class="text-center mb-10 relative">
                    <!-- Magnifying Glass Icon Floating -->
                    <div class="inline-flex items-center justify-center w-16 h-16 bg-white rounded-full shadow-lg mb-6 text-3xl text-brand-green transform -rotate-12 border border-green-100">
                        <i class="fas fa-search"></i>
                    </div>
                    
                    <h1 class="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Find creators who influence your customers</h1>
                </div>

                <!-- Modern Search Component (Matching the Image) -->
                <div class="max-w-5xl mx-auto mb-12">
                    <form action="<?php echo base_url('discovery/search'); ?>" method="post" onsubmit="showPageLoading()" class="relative z-20">
                        <!-- Persistent Filters -->
                        <input type="hidden" name="min_followers" value="<?php echo isset($search_params['min_followers']) ? $search_params['min_followers'] : ''; ?>">
                        <input type="hidden" name="max_followers" value="<?php echo isset($search_params['max_followers']) ? $search_params['max_followers'] : ''; ?>">
                        <input type="hidden" name="location" value="<?php echo isset($search_params['location']) ? $search_params['location'] : ''; ?>">
                        <input type="hidden" name="min_engagement" value="<?php echo isset($search_params['min_engagement']) ? $search_params['min_engagement'] : ''; ?>">
                        <input type="hidden" name="has_email" value="<?php echo isset($search_params['has_email']) ? $search_params['has_email'] : ''; ?>">
                        <input type="hidden" name="gender" value="<?php echo isset($search_params['gender']) ? $search_params['gender'] : ''; ?>">

                        
                        <div class="bg-white rounded-lg shadow-xl shadow-green-100/50 border border-gray-100 p-2 flex flex-col md:flex-row items-center gap-0 divide-y md:divide-y-0 md:divide-x divide-gray-100">
                            
                            <!-- Platform Selector (Icon) -->
                            <div class="w-full md:w-auto relative group">
                                <select name="platform" id="platformSelect" onchange="updateSearchUI(this.value)" class="appearance-none bg-transparent py-4 pl-4 pr-10 cursor-pointer focus:outline-none text-transparent font-medium h-full w-full md:w-[70px] z-10 relative">
                                    <option value="instagram" <?php echo (isset($search_params['platform']) && $search_params['platform'] == 'instagram') ? 'selected' : ''; ?> class="text-gray-700">Instagram</option>
                                    <option value="youtube" <?php echo (isset($search_params['platform']) && $search_params['platform'] == 'youtube') ? 'selected' : ''; ?> class="text-gray-700">YouTube</option>
                                    <option value="tiktok" <?php echo (isset($search_params['platform']) && $search_params['platform'] == 'tiktok') ? 'selected' : ''; ?> class="text-gray-700">TikTok</option>
                                </select>
                                <!-- Custom Icon Overlay -->
                                <div class="absolute inset-0 flex items-center justify-center pointer-events-none text-xl z-0">
                                    <i id="searchPlatformIcon" class="<?php 
                                        $p = isset($search_params['platform']) ? $search_params['platform'] : 'instagram';
                                        if($p == 'youtube') echo 'fab fa-youtube text-red-600';
                                        elseif($p == 'tiktok') echo 'fab fa-tiktok text-black';
                                        else echo 'fab fa-instagram text-pink-600';
                                    ?>"></i>
                                    <i class="fas fa-chevron-down text-[10px] text-gray-400 ml-2"></i>
                                </div>
                            </div>

                            <!-- Search Intent Dropdown -->
                            <div class="w-full md:w-[320px] relative hidden md:block">
                                <div class="relative w-full h-full">
                                    <select class="appearance-none w-full h-full py-4 px-4 bg-transparent text-gray-700 font-medium cursor-pointer focus:outline-none">
                                        <option>Show influencers who talk about</option>
                                        <option>Show influencers who mention</option>
                                        <option>Show influencers similar to</option>
                                    </select>
                                    <div class="absolute inset-y-0 right-4 flex items-center pointer-events-none">
                                        <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
                                    </div>
                                </div>
                            </div>

                            <!-- Search Input -->
                            <div class="flex-1 w-full relative">
                                <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                    <i class="fas fa-search text-gray-300"></i>
                                </div>
                                <input type="text" name="keyword" value="<?php echo isset($search_params['keyword']) ? $search_params['keyword'] : ''; ?>" 
                                    class="w-full h-full py-4 pl-10 pr-4 bg-transparent text-gray-900 placeholder-gray-400 focus:outline-none" 
                                    placeholder="A primary topic of interest, eg: #wellnesswednesday" required>
                            </div>



                            <!-- Action Button -->
                            <div class="p-1 w-full md:w-auto">
                                <button type="submit" class="w-full md:w-auto bg-[#1FAE5B] hover:bg-[#0F6B3E] text-white font-bold py-3 px-8 rounded-md transition-all shadow-md hover:shadow-lg whitespace-nowrap">
                                    Find Creators
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Recommended Searches -->
                    <div class="mt-6 flex flex-wrap items-center justify-center gap-3 text-sm">
                        <span class="text-gray-400 flex items-center gap-1"><i class="fas fa-magic text-brand-green"></i> Recommended Searches:</span>
                        <?php if(!empty($recommended_searches)): ?>
                            <?php foreach($recommended_searches as $item): ?>
                                <button type="button" onclick="setSearchKeyword('<?php echo htmlspecialchars($item['keyword'], ENT_QUOTES); ?>')" class="px-4 py-1.5 bg-white border border-green-100 text-brand-deep rounded-full hover:bg-green-50 transition-colors shadow-sm">
                                    <?php echo htmlspecialchars($item['keyword']); ?>
                                </button>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <!-- Recent Searches -->
                    <?php if(!empty($recent_searches)): ?>
                    <div class="mt-4 flex flex-wrap items-center justify-center gap-3 text-sm">
                        <span class="text-gray-400">Recent searches:</span>
                        <?php foreach($recent_searches as $item): ?>
                            <button type="button" onclick="setSearchKeyword('<?php echo htmlspecialchars($item['keyword'], ENT_QUOTES); ?>')" class="px-3 py-1 bg-white border border-gray-200 rounded-full flex items-center gap-2 text-gray-600 shadow-sm hover:bg-gray-50">
                                <?php 
                                    $icon = 'fas fa-globe';
                                    if(isset($item['platform'])) {
                                        if($item['platform'] == 'instagram') $icon = 'fab fa-instagram text-pink-500';
                                        elseif($item['platform'] == 'youtube') $icon = 'fab fa-youtube text-red-600';
                                        elseif($item['platform'] == 'tiktok') $icon = 'fab fa-tiktok text-black';
                                    }
                                ?>
                                <i class="<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($item['keyword']); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if(isset($error)): ?>
                <div class="max-w-4xl mx-auto mb-6">
                    <div class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-4 py-3 flex items-center gap-2">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                </div>
                <?php elseif(isset($data['warning']) && !empty($data['warning'])): ?>
                <div class="max-w-4xl mx-auto mb-6">
                    <div class="rounded-xl border border-amber-200 bg-amber-50 text-amber-800 px-4 py-3 flex items-center gap-2">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span><?php echo $data['warning']; ?></span>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Empty State / Placeholder Categories -->
                <div class="text-center mt-12 opacity-40">
                     <i class="fas fa-arrow-up text-4xl text-green-200 animate-bounce"></i>
                     <p class="mt-4 text-gray-400">Enter a topic above to start searching</p>
                </div>

            </div>
        </main>
    </div>

    <!-- Notification Toast -->
    <div id="toast" class="fixed bottom-5 right-5 bg-white border-l-4 border-brand-green shadow-lg rounded-xl p-4 hidden transform transition-all duration-300 translate-y-full z-50 flex items-center gap-4 pr-6">
        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-check text-brand-green"></i>
        </div>
        <div>
            <h4 class="font-bold text-gray-900 text-sm">Success</h4>
            <p class="text-sm text-gray-500">Action completed successfully.</p>
        </div>
    </div>
    <!-- Filter Modal -->
    <div id="filterModal" class="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-5xl h-[85vh] rounded-xl shadow-2xl flex flex-col md:flex-row overflow-hidden animate-fade-in-up">
            
            <!-- Sidebar -->
            <div class="w-full md:w-64 bg-gray-50 border-r border-gray-200 flex flex-col flex-shrink-0">
                <div class="p-6">
                    <h3 class="font-bold text-lg text-gray-900 mb-6">All Filter</h3>
                    
                    <div class="space-y-1">
                        <button class="w-full text-left px-4 py-2.5 rounded-lg bg-purple-50 text-purple-700 font-medium text-sm">
                            Basic filters
                        </button>
                        <button class="w-full text-left px-4 py-2.5 rounded-lg text-gray-600 hover:bg-gray-100 font-medium text-sm transition-colors">
                            Advanced filters
                        </button>
                    </div>

                    <div class="mt-8">
                        <div class="relative">
                            <select class="w-full appearance-none bg-white border border-gray-200 text-gray-700 py-2.5 px-4 pr-8 rounded-lg focus:outline-none focus:border-purple-500 text-sm">
                                <option>Saved Filters</option>
                            </select>
                            <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                                <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-auto p-6 border-t border-gray-200 md:block hidden">
                    <button onclick="clearFilters()" class="text-red-500 text-sm font-medium hover:text-red-700 flex items-center gap-2">
                        <i class="fas fa-times"></i> Clear All Filters
                    </button>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 flex flex-col min-w-0 bg-white">
                <div class="flex-1 overflow-y-auto p-8 custom-scrollbar">
                    
                    <!-- Basic Filters Header -->
                    <div class="flex items-center justify-between mb-6">
                        <h4 class="text-gray-500 font-medium text-sm uppercase tracking-wider">Basic Filters</h4>
                        <i class="fas fa-chevron-up text-gray-400"></i>
                    </div>

                    <!-- Followers -->
                    <div class="mb-10">
                        <h5 class="font-bold text-gray-900 mb-1">Followers</h5>
                        <p class="text-gray-500 text-xs mb-4">Go smaller if you need creator-affiliates. Go bigger if you have budgets to accommodate fees.</p>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="nano" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('nano')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Nano - 5K to 25K</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="micro" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('micro')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Micro - 25K to 100K</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="macro" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('macro')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Macro - 100K to 500K</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="mega" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('mega')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Mega - 500K to 1M</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="whale" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('whale')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Whale - 1M+</span>
                            </label>
                        </div>

                        <h6 class="font-medium text-gray-800 text-sm mb-3">Custom Range</h6>
                        <div class="flex items-center gap-4">
                            <div class="relative w-32">
                                <input type="number" id="min_followers_input" placeholder="Min" class="w-full border border-gray-300 rounded-lg py-2 px-3 text-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            </div>
                            <div class="flex-1 h-1.5 bg-purple-100 rounded-full relative">
                                <div class="absolute inset-y-0 left-0 bg-purple-500 rounded-full w-full opacity-20"></div>
                            </div>
                            <div class="relative w-32">
                                <input type="number" id="max_followers_input" placeholder="Max" class="w-full border border-gray-300 rounded-lg py-2 px-3 text-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            </div>
                        </div>
                    </div>

                    <div class="border-t border-gray-100 my-8"></div>

                    <!-- Location -->
                    <div class="mb-10">
                        <div class="flex items-center gap-1 mb-4 border-b border-gray-200">
                            <button class="px-4 py-2 text-sm font-medium text-purple-600 border-b-2 border-purple-600 bg-purple-50 rounded-t-lg">Influencer Location</button>
                            <button class="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700">Audience Location</button>
                        </div>
                        
                        <p class="text-gray-500 text-xs mb-4">Select the location you want to target.</p>
                        
                        <div class="relative mb-6">
                            <i class="fas fa-search absolute left-3 top-3 text-gray-400 text-sm"></i>
                            <input type="text" id="location_input" placeholder="Find by City or Country" class="w-full border border-gray-300 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
                        </div>

                        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                            <?php 
                            $top_locations = ['United States', 'Canada', 'United Kingdom', 'India', 'France', 'Germany', 'Australia', 'New Zealand', 'Spain'];
                            foreach($top_locations as $loc): ?>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="top_location" value="<?php echo $loc; ?>" class="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500" onchange="updateLocationInput(this)">
                                <span class="text-gray-700 text-sm"><?php echo $loc; ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="border-t border-gray-100 my-8"></div>

                    <!-- Engagement Rate -->
                    <div class="mb-10">
                        <h5 class="font-bold text-gray-900 mb-1">Engagement Rate</h5>
                        <p class="text-gray-500 text-xs mb-6">Select the engagement rate you want. 1-2% is good enough to start.</p>
                        
                        <div class="flex items-center justify-between text-xs font-bold text-gray-700 mb-2">
                            <span>0%</span>
                            <span>15%+</span>
                        </div>
                        <input type="range" id="engagement_slider" min="0" max="15" step="0.5" value="0" class="w-full h-2 bg-purple-100 rounded-lg appearance-none cursor-pointer accent-purple-600">
                        <div class="mt-2 text-center">
                            <span id="engagement_display" class="bg-purple-100 text-purple-700 text-xs font-bold px-2 py-1 rounded">0% +</span>
                        </div>
                    </div>

                    <div class="border-t border-gray-100 my-8"></div>

                    <!-- Email & Gender Row -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <!-- Email -->
                        <div>
                            <h5 class="font-bold text-gray-900 mb-1">Email</h5>
                            <p class="text-gray-500 text-xs mb-4">Do you strictly want to email creators?</p>
                            
                            <div class="flex gap-3">
                                <button type="button" onclick="toggleBtnState(this, 'has_email')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="1">Exists</button>
                                <button type="button" onclick="toggleBtnState(this, 'has_email')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="0">Doesn't Exist</button>
                                <input type="hidden" id="has_email_input" name="has_email_temp" value="">
                            </div>
                        </div>

                        <!-- Gender -->
                        <div>
                            <div class="flex items-center gap-2 mb-2">
                                <h5 class="font-bold text-gray-900">Gender</h5>
                                <div class="bg-purple-50 text-purple-600 text-[10px] px-2 py-0.5 rounded font-medium">Influencer</div>
                            </div>
                            
                            <div class="flex gap-3">
                                <button type="button" onclick="toggleBtnState(this, 'gender')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="male">Male</button>
                                <button type="button" onclick="toggleBtnState(this, 'gender')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="female">Female</button>
                                <input type="hidden" id="gender_input" name="gender_temp" value="">
                            </div>
                        </div>
                    </div>
                    
                </div>

                <!-- Footer -->
                <div class="p-6 border-t border-gray-200 bg-gray-50 flex items-center justify-between">
                     <button onclick="toggleFilterModal()" class="md:hidden text-gray-500 hover:text-gray-700 font-medium text-sm">Cancel</button>
                     
                     <div class="flex items-center gap-4 ml-auto">
                         <button type="button" class="hidden md:block px-6 py-2.5 border border-purple-600 text-purple-600 font-medium rounded-lg hover:bg-purple-50 transition-colors text-sm">
                             <i class="fas fa-history mr-1"></i> Apply Previous
                         </button>
                         <button type="button" onclick="applyFilters()" class="px-8 py-2.5 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 shadow-lg shadow-purple-200 transition-all text-sm">
                             Apply Filters
                         </button>
                     </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Filter Logic
        function toggleFilterModal() {
            const modal = document.getElementById('filterModal');
            modal.classList.toggle('hidden');
            if (!modal.classList.contains('hidden')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        }

        function updateFollowerRange(preset) {
            const minInput = document.getElementById('min_followers_input');
            const maxInput = document.getElementById('max_followers_input');
            
            let min = 0, max = '';
            
            switch(preset) {
                case 'nano': min = 5000; max = 25000; break;
                case 'micro': min = 25000; max = 100000; break;
                case 'macro': min = 100000; max = 500000; break;
                case 'mega': min = 500000; max = 1000000; break;
                case 'whale': min = 1000000; max = ''; break;
            }
            
            minInput.value = min;
            maxInput.value = max;
        }

        function updateLocationInput(checkbox) {
            const input = document.getElementById('location_input');
            const val = checkbox.value;
            
            if (checkbox.checked) {
                document.querySelectorAll('input[name="top_location"]').forEach(cb => {
                    if(cb !== checkbox) cb.checked = false;
                });
                input.value = val;
            } else {
                if(input.value === val) input.value = '';
            }
        }

        const engagementSlider = document.getElementById('engagement_slider');
        const engagementDisplay = document.getElementById('engagement_display');
        
        if (engagementSlider) {
            engagementSlider.addEventListener('input', function() {
                if (this.value == 0) {
                    engagementDisplay.textContent = 'Any';
                } else {
                    engagementDisplay.textContent = this.value + '%+';
                }
            });
        }

        function toggleBtnState(btn, type) {
            const parent = btn.parentNode;
            const input = document.getElementById(type + '_input');
            const val = btn.getAttribute('data-value');
            
            // Deselect all
            parent.querySelectorAll('button').forEach(b => {
                b.classList.remove('bg-purple-50', 'border-purple-200', 'text-purple-700');
                b.classList.add('border-gray-200', 'text-gray-700');
            });
            
            // Toggle logic
            if (input.value === val) {
                input.value = ''; // Deselect
            } else {
                input.value = val;
                btn.classList.remove('border-gray-200', 'text-gray-700');
                btn.classList.add('bg-purple-50', 'border-purple-200', 'text-purple-700');
            }
        }

        function clearFilters() {
            // Reset inputs
            document.getElementById('min_followers_input').value = '';
            document.getElementById('max_followers_input').value = '';
            document.getElementById('location_input').value = '';
            if(engagementSlider) {
                engagementSlider.value = 0;
                engagementDisplay.textContent = '0% +';
            }
            document.getElementById('has_email_input').value = '';
            document.getElementById('gender_input').value = '';
            
            // Reset radios/checkboxes
            document.querySelectorAll('input[type="radio"]').forEach(el => el.checked = false);
            document.querySelectorAll('input[type="checkbox"]').forEach(el => el.checked = false);
            
            // Reset buttons
            document.querySelectorAll('button[data-value]').forEach(b => {
                b.classList.remove('bg-purple-50', 'border-purple-200', 'text-purple-700');
                b.classList.add('border-gray-200', 'text-gray-700');
            });
        }

        // --- Functions from Secondary Filter Script ---

        function setFollowers(min, max) {
            document.getElementById('min_followers_input').value = min;
            document.getElementById('max_followers_input').value = max;
        }

        function setLocation(loc) {
            document.getElementById('location_input').value = loc;
        }

        function setHasEmail(val) {
            document.getElementById('has_email_input').value = val;
            
            ['email_any', 'email_yes', 'email_no'].forEach(id => {
                const btn = document.getElementById(id);
                if(btn) btn.className = 'flex-1 py-2 text-xs font-medium rounded-md text-gray-500 hover:text-gray-900 transition-all';
            });

            let activeId = 'email_any';
            if (val === '1') activeId = 'email_yes';
            if (val === '0') activeId = 'email_no';

            const activeBtn = document.getElementById(activeId);
            if(activeBtn) activeBtn.className = 'flex-1 py-2 text-xs font-medium rounded-md shadow-sm bg-white text-gray-900 transition-all';
        }

        function setGender(val) {
            document.getElementById('gender_input').value = val;
            
            ['gender_any', 'gender_male', 'gender_female'].forEach(id => {
                const btn = document.getElementById(id);
                if(btn) btn.className = 'flex-1 py-2 text-xs font-medium rounded-md text-gray-500 hover:text-gray-900 transition-all';
            });

            let activeId = 'gender_any';
            if (val === 'male') activeId = 'gender_male';
            if (val === 'female') activeId = 'gender_female';

            const activeBtn = document.getElementById(activeId);
            if(activeBtn) activeBtn.className = 'flex-1 py-2 text-xs font-medium rounded-md shadow-sm bg-white text-gray-900 transition-all';
        }

        function resetFilters() {
            document.getElementById('min_followers_input').value = '';
            document.getElementById('max_followers_input').value = '';
            document.getElementById('location_input').value = '';
            if(engagementSlider) {
                engagementSlider.value = 0;
                engagementDisplay.textContent = 'Any';
            }
            setHasEmail('');
            setGender('any');
        }

        function applyFilters() {
            // Collect values
            const minFollowers = document.getElementById('min_followers_input').value;
            const maxFollowers = document.getElementById('max_followers_input').value;
            const location = document.getElementById('location_input').value;
            const engagement = document.getElementById('engagement_slider').value;
            const hasEmail = document.getElementById('has_email_input').value;
            const gender = document.getElementById('gender_input').value;
            
            // Create/Update hidden inputs in the main search form
            const form = document.querySelector('form[action*="discovery/search"]');
            
            addHiddenInput(form, 'min_followers', minFollowers);
            addHiddenInput(form, 'max_followers', maxFollowers);
            addHiddenInput(form, 'location', location);
            addHiddenInput(form, 'min_engagement', engagement);
            addHiddenInput(form, 'has_email', hasEmail);
            addHiddenInput(form, 'gender', gender);
            
            toggleFilterModal();
            showPageLoading();
            form.submit();
        }

        function addHiddenInput(form, name, value) {
            let input = form.querySelector(`input[name="${name}"]`);
            if (!input) {
                input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                form.appendChild(input);
            }
            input.value = value;
        }

        // Initialize filters from PHP params
        document.addEventListener('DOMContentLoaded', () => {
            <?php if(isset($search_params['min_followers'])): ?>
                document.getElementById('min_followers_input').value = '<?php echo $search_params['min_followers']; ?>';
            <?php endif; ?>
            <?php if(isset($search_params['max_followers'])): ?>
                document.getElementById('max_followers_input').value = '<?php echo $search_params['max_followers']; ?>';
            <?php endif; ?>
            <?php if(isset($search_params['location'])): ?>
                document.getElementById('location_input').value = '<?php echo $search_params['location']; ?>';
            <?php endif; ?>
            <?php if(isset($search_params['min_engagement'])): ?>
                const engVal = '<?php echo $search_params['min_engagement']; ?>';
                if(engagementSlider) {
                    engagementSlider.value = engVal;
                    if(engVal > 0) document.getElementById('engagement_display').textContent = engVal + '%+';
                }
            <?php endif; ?>
            <?php if(isset($search_params['has_email'])): ?>
                setHasEmail('<?php echo $search_params['has_email']; ?>');
            <?php endif; ?>
            <?php if(isset($search_params['gender'])): ?>
                setGender('<?php echo $search_params['gender']; ?>');
            <?php endif; ?>
        });
    </script>
    <div id="page-loading" class="fixed inset-0 bg-white/70 backdrop-blur-sm hidden z-50 flex items-center justify-center">
        <div class="flex items-center gap-3 bg-white rounded-xl shadow-lg border border-gray-100 px-5 py-3">
            <i class="fas fa-spinner fa-spin text-brand-green"></i>
            <span class="text-gray-700 font-medium">Searching...</span>
        </div>
    </div>
    <script>
        function showPageLoading() {
            document.getElementById('page-loading').classList.remove('hidden');
        }

        function setSearchKeyword(keyword) {
            const input = document.querySelector('input[name="keyword"]');
            if (input) {
                input.value = keyword;
                showPageLoading();
                input.form.submit();
            }
        }

        function updateSearchUI(platform) {
            const icon = document.getElementById('searchPlatformIcon');
            // Reset classes
            icon.className = '';
            
            if (platform === 'youtube') {
                icon.className = 'fab fa-youtube text-red-600';
            } else if (platform === 'tiktok') {
                icon.className = 'fab fa-tiktok text-black';
            } else {
                icon.className = 'fab fa-instagram text-pink-600';
            }
        }
    </script>
    <!-- Filter Modal -->
    <div id="filterModal" class="fixed inset-0 bg-gray-900/60 backdrop-blur-sm z-[60] hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-fade-in-up">
            
            <!-- Header -->
            <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 z-10">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center text-brand-green">
                        <i class="fas fa-sliders-h"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900">Filters</h3>
                </div>
                <div class="flex items-center gap-3">
                    <button type="button" onclick="resetFilters()" class="text-sm text-gray-500 hover:text-red-500 font-medium transition-colors">
                        Reset all
                    </button>
                    <button type="button" onclick="toggleFilterModal()" class="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <!-- Body -->
            <div class="flex-1 overflow-hidden flex flex-col md:flex-row">
                
                <!-- Sidebar (Categories) -->
                <div class="w-full md:w-64 bg-gray-50 border-r border-gray-100 p-4 flex-shrink-0 overflow-y-auto hidden md:block">
                    <div class="space-y-1">
                        <button class="w-full text-left px-4 py-2.5 rounded-lg bg-white shadow-sm text-brand-deep font-semibold text-sm border border-gray-100 flex items-center justify-between">
                            <span>Basic Filters</span>
                            <i class="fas fa-chevron-right text-xs text-gray-300"></i>
                        </button>
                        <button class="w-full text-left px-4 py-2.5 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900 font-medium text-sm transition-colors flex items-center justify-between">
                            <span>Advanced Filters</span>
                            <i class="fas fa-lock text-xs text-amber-400" title="Premium"></i>
                        </button>
                    </div>

                    <div class="mt-8 px-4">
                        <p class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Saved Filters</p>
                        <button class="text-sm text-brand-green font-medium hover:underline flex items-center gap-2">
                            <i class="fas fa-plus-circle"></i> Create New
                        </button>
                    </div>
                </div>

                <!-- Content -->
                <div class="flex-1 overflow-y-auto p-6 md:p-8">
                    <div class="grid grid-cols-1 gap-8">
                        
                        <!-- Followers -->
                        <div class="space-y-4">
                            <label class="flex items-center justify-between">
                                <span class="text-sm font-bold text-gray-900">Followers</span>
                                <span class="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">Audience Size</span>
                            </label>
                            
                            <div class="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
                                <button type="button" onclick="setFollowers(1000, 10000)" class="px-3 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:border-brand-green hover:text-brand-green hover:bg-green-50 transition-all text-center">
                                    Nano<br><span class="text-[10px] text-gray-400">1k-10k</span>
                                </button>
                                <button type="button" onclick="setFollowers(10000, 50000)" class="px-3 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:border-brand-green hover:text-brand-green hover:bg-green-50 transition-all text-center">
                                    Micro<br><span class="text-[10px] text-gray-400">10k-50k</span>
                                </button>
                                <button type="button" onclick="setFollowers(50000, 500000)" class="px-3 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:border-brand-green hover:text-brand-green hover:bg-green-50 transition-all text-center">
                                    Macro<br><span class="text-[10px] text-gray-400">50k-500k</span>
                                </button>
                                <button type="button" onclick="setFollowers(500000, 1000000)" class="px-3 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:border-brand-green hover:text-brand-green hover:bg-green-50 transition-all text-center">
                                    Mega<br><span class="text-[10px] text-gray-400">500k-1M</span>
                                </button>
                                <button type="button" onclick="setFollowers(1000000, '')" class="px-3 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:border-brand-green hover:text-brand-green hover:bg-green-50 transition-all text-center">
                                    Whale<br><span class="text-[10px] text-gray-400">1M+</span>
                                </button>
                            </div>

                            <div class="flex items-center gap-3">
                                <div class="relative flex-1">
                                    <span class="absolute left-3 top-2.5 text-gray-400 text-xs">Min</span>
                                    <input type="number" id="min_followers_input" placeholder="0" class="w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-green focus:ring-1 focus:ring-brand-green">
                                </div>
                                <span class="text-gray-300">-</span>
                                <div class="relative flex-1">
                                    <span class="absolute left-3 top-2.5 text-gray-400 text-xs">Max</span>
                                    <input type="number" id="max_followers_input" placeholder="Any" class="w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-green focus:ring-1 focus:ring-brand-green">
                                </div>
                            </div>
                        </div>

                        <!-- Location -->
                        <div class="space-y-4">
                            <label class="block text-sm font-bold text-gray-900">Location</label>
                            <div class="relative">
                                <i class="fas fa-map-marker-alt absolute left-3.5 top-3 text-gray-400"></i>
                                <input type="text" id="location_input" placeholder="Search locations (e.g., United States, London)" class="w-full pl-10 pr-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-green focus:ring-1 focus:ring-brand-green">
                            </div>
                            <div class="flex flex-wrap gap-2">
                                <button type="button" onclick="setLocation('United States')" class="px-3 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full text-xs text-gray-600 transition-colors">United States</button>
                                <button type="button" onclick="setLocation('United Kingdom')" class="px-3 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full text-xs text-gray-600 transition-colors">United Kingdom</button>
                                <button type="button" onclick="setLocation('Canada')" class="px-3 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full text-xs text-gray-600 transition-colors">Canada</button>
                                <button type="button" onclick="setLocation('Australia')" class="px-3 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full text-xs text-gray-600 transition-colors">Australia</button>
                            </div>
                        </div>

                        <!-- Engagement Rate -->
                        <div class="space-y-4">
                            <div class="flex items-center justify-between">
                                <label class="text-sm font-bold text-gray-900">Engagement Rate</label>
                                <span class="text-sm text-brand-green font-bold" id="engagement_display">Any</span>
                            </div>
                            <input type="range" id="engagement_slider" min="0" max="10" step="0.5" value="0" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-green">
                            <div class="flex justify-between text-xs text-gray-400">
                                <span>0%</span>
                                <span>5%</span>
                                <span>10%+</span>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <!-- Has Email -->
                            <div class="space-y-4">
                                <label class="block text-sm font-bold text-gray-900">Has Email</label>
                                <div class="flex p-1 bg-gray-100 rounded-lg">
                                    <button type="button" onclick="setHasEmail('')" id="email_any" class="flex-1 py-2 text-xs font-medium rounded-md shadow-sm bg-white text-gray-900 transition-all">Any</button>
                                    <button type="button" onclick="setHasEmail('1')" id="email_yes" class="flex-1 py-2 text-xs font-medium rounded-md text-gray-500 hover:text-gray-900 transition-all">Exists</button>
                                    <button type="button" onclick="setHasEmail('0')" id="email_no" class="flex-1 py-2 text-xs font-medium rounded-md text-gray-500 hover:text-gray-900 transition-all">Doesn't Exist</button>
                                </div>
                                <input type="hidden" id="has_email_input" value="">
                            </div>

                            <!-- Influencer Gender -->
                            <div class="space-y-4">
                                <label class="block text-sm font-bold text-gray-900">Influencer Gender</label>
                                <div class="flex p-1 bg-gray-100 rounded-lg">
                                    <button type="button" onclick="setGender('any')" id="gender_any" class="flex-1 py-2 text-xs font-medium rounded-md shadow-sm bg-white text-gray-900 transition-all">Any</button>
                                    <button type="button" onclick="setGender('male')" id="gender_male" class="flex-1 py-2 text-xs font-medium rounded-md text-gray-500 hover:text-gray-900 transition-all">Male</button>
                                    <button type="button" onclick="setGender('female')" id="gender_female" class="flex-1 py-2 text-xs font-medium rounded-md text-gray-500 hover:text-gray-900 transition-all">Female</button>
                                </div>
                                <input type="hidden" id="gender_input" value="any">
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
                <button type="button" class="text-sm font-medium text-gray-600 hover:text-gray-900">
                    Apply Previous
                </button>
                <div class="flex items-center gap-3">
                    <button type="button" onclick="toggleFilterModal()" class="px-5 py-2.5 rounded-lg border border-gray-200 text-gray-600 font-medium text-sm hover:bg-white hover:border-gray-300 transition-colors">
                        Cancel
                    </button>
                    <button type="button" onclick="applyFilters()" class="px-6 py-2.5 rounded-lg bg-brand-green text-white font-bold text-sm hover:bg-brand-deep shadow-md hover:shadow-lg transition-all">
                        Show Results
                    </button>
                </div>
            </div>

        </div>
    </div>


</body>
</html>
