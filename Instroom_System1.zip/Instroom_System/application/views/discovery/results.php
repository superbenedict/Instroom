<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827',
                            gray: '#F9FAFB',
                            border: '#E5E7EB',
                            blue: '#3B82F6',
                            purple: '#8B5CF6',
                            rose: '#F43F5E',
                            amber: '#F59E0B'
                        }
                    },
                    boxShadow: {
                        'card': '0 2px 5px -1px rgba(0, 0, 0, 0.05), 0 1px 3px -1px rgba(0, 0, 0, 0.03)',
                        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)',
                    }
                }
            }
        }

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('absolute');
            sidebar.classList.toggle('h-full');
            sidebar.classList.toggle('z-40');
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });

        // Add Influencer AJAX
        function addInfluencer(influencerData, btnElement) {
            const originalText = btnElement.innerHTML;
            const originalClasses = btnElement.className;
            
            btnElement.innerHTML = '<i class="fas fa-spinner fa-spin text-xs"></i> Saving...';
            btnElement.disabled = true;

            $.ajax({
                url: '<?php echo base_url("discovery/add"); ?>',
                type: 'POST',
                data: influencerData,
                dataType: 'json',
                success: function(response) {
                    if(response.status === 'success') {
                        btnElement.innerHTML = '<i class="fas fa-check text-xs"></i> Saved';
                        // Remove initial styling classes
                        btnElement.classList.remove('bg-white', 'text-gray-600', 'border-gray-200', 'hover:border-brand-green', 'hover:text-brand-green', 'shadow-sm');
                        // Add success styling classes
                        btnElement.classList.add('bg-green-50', 'text-green-600', 'border-green-200', 'cursor-default');
                        showToast('Success', 'Influencer added to List!', 'success');
                    } else {
                        btnElement.innerHTML = originalText;
                        btnElement.disabled = false;
                        showToast('Error', response.message || 'Failed to add influencer.');
                    }
                },
                error: function() {
                    btnElement.innerHTML = originalText;
                    btnElement.disabled = false;
                    showToast('Error', 'Server error. Please try again.');
                }
            });
        }

        function showToast(title, message) {
            const toast = document.getElementById('toast');
            const icon = toast.querySelector('i');
            const titleEl = toast.querySelector('h4');
            const msgEl = toast.querySelector('p');

            titleEl.textContent = title;
            msgEl.textContent = message;

            if(title === 'Error') {
                icon.className = 'fas fa-exclamation-circle text-red-500 text-xl';
                toast.classList.replace('border-brand-green', 'border-red-500');
            } else {
                icon.className = 'fas fa-check-circle text-brand-green text-xl';
                toast.classList.replace('border-red-500', 'border-brand-green');
            }

            toast.classList.remove('hidden', 'translate-y-full');
            
            setTimeout(() => {
                toast.classList.add('translate-y-full');
                setTimeout(() => {
                    toast.classList.add('hidden');
                }, 300);
            }, 3000);
        }
        
        function updateSearchUI(platform) {
            const icon = document.getElementById('searchPlatformIcon');
            // Reset classes
            icon.className = '';
            
            if (platform === 'youtube') {
                icon.className = 'fab fa-youtube text-red-600 text-lg';
            } else if (platform === 'tiktok') {
                icon.className = 'fab fa-tiktok text-black text-lg';
            } else {
                icon.className = 'fab fa-instagram text-pink-600 text-lg';
            }
        }

        function showPageLoading() {
            const el = document.getElementById('page-loading');
            if (el) el.classList.remove('hidden');
        }
    </script>
    <link href="<?php echo base_url('assets/css/discovery.css'); ?>" rel="stylesheet">
</head>
<body class="bg-gray-50 h-screen flex overflow-hidden text-gray-800">

    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 bg-[#0F6B3E] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex fixed md:relative z-30 h-full top-0 left-0 shadow-xl">
        <div class="h-16 flex items-center px-8 border-b border-white/10">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bolt text-brand-green text-lg"></i>
                    </div>
                    <span class="text-xl font-bold tracking-tight text-white">INSTROOM</span>
                </div>
                <button class="md:hidden text-white/70 hover:text-white transition-colors focus:outline-none" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Main Menu</p>
            
            <a href="<?php echo base_url('welcome'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-tachometer-alt w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            
            <a href="<?php echo base_url('discovery'); ?>" class="sidebar-item active group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white bg-white/5">
                <i class="fas fa-search w-6 text-lg opacity-100 transition-opacity"></i>
                <span class="ml-3">Discovery</span>
            </a>
            
            <a href="<?php echo base_url('influencer'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-list-ul w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Influencer List</span>
            </a>

            <a href="<?php echo base_url('influencer/pipeline'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-filter w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Pipeline</span>
            </a>

            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mt-8 mb-3">Campaigns</p>

            <a href="<?php echo base_url('influencer/closed_collaborations'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="far fa-check-square w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Closed</span>
            </a>
            
            <a href="#" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-users w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Ambassadors</span>
            </a>
            
            <a href="<?php echo base_url('influencer/analytics'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-chart-line w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Analytics</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden relative bg-white">
        
        <!-- Top Navigation -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-20 sticky top-0">
            <div class="flex items-center md:hidden">
                <button class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 rounded-md hover:bg-gray-100 transition-colors" onclick="toggleSidebar()">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <span class="ml-4 text-lg font-bold text-brand-deep">INSTROOM</span>
            </div>
            
            <div class="hidden md:flex items-center text-gray-500 text-sm font-medium">
                <span class="text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">Influencer</span>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <a href="<?php echo base_url('discovery'); ?>" class="text-gray-500 hover:text-brand-green transition-colors">Discovery</a>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <span class="text-brand-deep bg-green-50 px-2 py-1 rounded-md">Search Results</span>
            </div>

            <div class="flex items-center gap-4">
                <button class="relative p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100">
                    <i class="far fa-bell text-xl"></i>
                    <span class="absolute top-1.5 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div class="h-8 w-px bg-gray-200 mx-2"></div>

                <!-- User Dropdown -->
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-deep transition-colors"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user_role) ? ucfirst($user_role) : 'User'; ?></p>
                        </div>
                        <div class="relative">
                             <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'User'); ?>&background=1FAE5B&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-white group-hover:border-brand-green transition-all">
                             <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-deep transition-colors"></i>
                    </button>
                    
                    <!-- Dropdown -->
                    <div id="user-menu" class="hidden absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-1 z-50 animate-fade-in-up origin-top-right">
                        <div class="px-4 py-3 border-b border-gray-50">
                            <p class="text-sm font-semibold text-gray-900 truncate"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500 truncate"><?php echo isset($user_email) ? $user_email : ''; ?></p>
                        </div>
                        
                        <?php if(isset($user_role) && $user_role === 'admin'): ?>
                        <a href="<?php echo base_url('admin'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-tachometer-alt w-5 text-gray-400"></i> Admin Dashboard
                        </a>
                        <?php endif; ?>

                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5 text-gray-400"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5 text-gray-400"></i> Settings
                        </a>
                        
                        <div class="border-t border-gray-50 my-1"></div>
                        
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 relative">
            
            <!-- Decorative Background (Clouds/Cityscape Abstract) -->
            <div class="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-green-50 to-gray-50 -z-10"></div>
            
            <div class="max-w-7xl mx-auto px-6 py-8">

                <!-- Header Section -->
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <a href="<?php echo base_url('discovery'); ?>" class="text-gray-400 hover:text-brand-green transition-colors">
                                <i class="fas fa-arrow-left"></i> Back to Search
                            </a>
                        </div>
                        <h1 class="text-2xl font-bold text-gray-900">
                            Results for "<?php echo isset($search_params['keyword']) ? $search_params['keyword'] : 'Search'; ?>"
                        </h1>
                        <p class="text-sm text-gray-500 mt-1">Found <?php echo number_format(count($results) * 15 + 245); ?> creators matching your criteria</p>
                    </div>

                    <!-- Compact Search Bar -->
                    <form action="<?php echo base_url('discovery/search'); ?>" method="post" onsubmit="showPageLoading()" class="w-full md:w-auto">
                        <div class="flex items-center bg-white rounded-lg shadow-sm border border-gray-200 p-1">
                            <div class="relative w-[50px] flex items-center justify-center border-r border-gray-100 self-stretch">
                                <select name="platform" onchange="updateSearchUI(this.value)" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                                    <option value="instagram" <?php echo (isset($search_params['platform']) && $search_params['platform'] == 'instagram') ? 'selected' : ''; ?>>Instagram</option>
                                    <option value="youtube" <?php echo (isset($search_params['platform']) && $search_params['platform'] == 'youtube') ? 'selected' : ''; ?>>YouTube</option>
                                    <option value="tiktok" <?php echo (isset($search_params['platform']) && $search_params['platform'] == 'tiktok') ? 'selected' : ''; ?>>TikTok</option>
                                </select>
                                <i id="searchPlatformIcon" class="<?php 
                                    $p = isset($search_params['platform']) ? $search_params['platform'] : 'instagram';
                                    if($p == 'youtube') echo 'fab fa-youtube text-red-600';
                                    elseif($p == 'tiktok') echo 'fab fa-tiktok text-black';
                                    else echo 'fab fa-instagram text-pink-600';
                                ?> text-lg"></i>
                            </div>
                            <input type="text" name="keyword" value="<?php echo isset($search_params['keyword']) ? $search_params['keyword'] : ''; ?>" 
                                class="w-full md:w-64 pl-3 pr-4 py-2 text-sm text-gray-700 focus:outline-none placeholder-gray-400" 
                                placeholder="Search..." required>
                            <button type="submit" class="p-2 bg-brand-green text-white rounded-md hover:bg-brand-deep transition-colors">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
                
                <?php if(isset($warning) && $warning): ?>
                <div class="mb-6 rounded-xl border border-yellow-200 bg-yellow-50 text-yellow-800 px-4 py-3 flex items-center gap-2">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo $warning; ?></span>
                </div>
                <?php endif; ?>

                <?php if(!empty($results)): ?>
                    <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div class="text-sm text-gray-500 font-medium">
                            <!-- Filters / Stats -->
                        </div>
                        
                        <div class="flex items-center gap-3">
                            <div class="flex items-center gap-2 text-sm text-gray-600">
                                <span>Exclude Saved</span>
                                <button type="button" onclick="toggleExcludeSaved(this)" id="exclude_saved_btn" class="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2 bg-gray-200">
                                    <span class="translate-x-0 pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out"></span>
                                </button>
                            </div>
                            
                            <button onclick="toggleFilterModal()" class="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                                <i class="fas fa-filter text-brand-green"></i> Filters
                            </button>
                            <button class="px-4 py-2 bg-brand-green/10 border border-brand-green/20 rounded-lg text-sm font-medium text-brand-deep hover:bg-brand-green/20 flex items-center gap-2">
                                <i class="fas fa-list-check"></i> Add to List
                            </button>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="bg-gray-50/50 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                        <th class="p-4 w-10 text-center">
                                            <input type="checkbox" class="rounded border-gray-300 text-brand-green focus:ring-brand-green cursor-pointer">
                                        </th>
                                        <th class="p-4 font-semibold text-gray-600">Avatar & Name</th>
                                        <th class="p-4 font-semibold text-gray-600">Add To List</th>
                                        <th class="p-4 font-semibold text-gray-600">Username</th>
                                        <th class="p-4 font-semibold text-gray-600">Followers</th>
                                        <th class="p-4 font-semibold text-gray-600">Eng. Rate</th>
                                        <th class="p-4 font-semibold text-gray-600">Growth Rate</th>
                                        <th class="p-4 font-semibold text-gray-600 group relative">
                                            Est. Fair Fee
                                            <i class="fas fa-info-circle text-gray-400 text-xs ml-1 cursor-help"></i>
                                            <div class="hidden group-hover:block absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-48 bg-gray-800 text-white text-xs rounded py-1 px-2 shadow-lg z-50 text-center">
                                                Based on CPM ($5-$15) + Engagement Bonus
                                                <div class="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-800"></div>
                                            </div>
                                        </th>
                                        <th class="p-4 text-center font-semibold text-gray-600">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    <?php foreach($results as $index => $row): ?>
                                        <tr class="hover:bg-gray-50/80 transition-colors group">
                                            <td class="p-4 text-center">
                                                <input type="checkbox" class="rounded border-gray-300 text-brand-green focus:ring-brand-green cursor-pointer">
                                            </td>
                                            <td class="p-4">
                                                <div class="flex items-center gap-3">
                                                    <div class="relative w-10 h-10 flex-shrink-0">
                                                        <img src="<?php echo $row['profile_image']; ?>" alt="<?php echo $row['username']; ?>" class="w-full h-full rounded-full object-cover border border-gray-200">
                                                        <?php if($row['platform'] == 'instagram'): ?>
                                                            <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center shadow-sm">
                                                                <i class="fab fa-instagram text-pink-500 text-[10px]"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="min-w-0">
                                                        <div class="flex items-center gap-1">
                                                            <p class="font-semibold text-gray-900 truncate max-w-[180px]" title="<?php echo $row['full_name']; ?>">
                                                                <?php echo $row['full_name']; ?>
                                                            </p>
                                                            <?php if(isset($row['is_verified']) && $row['is_verified']): ?>
                                                                <i class="fas fa-check-circle text-blue-500 text-xs" title="Verified"></i>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="p-4">
                                                <button onclick='addInfluencer(<?php echo json_encode($row); ?>, this)' class="inline-flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-md text-gray-600 text-sm font-medium hover:border-brand-green hover:text-brand-green bg-white transition-all shadow-sm whitespace-nowrap">
                                                    <i class="fas fa-plus text-xs"></i> Add
                                                </button>
                                            </td>
                                            <td class="p-4 text-gray-600 text-sm font-medium">
                                                @<?php echo $row['username']; ?>
                                            </td>
                                            <td class="p-4 font-semibold text-gray-900">
                                                <?php 
                                                    $followers = $row['followers'];
                                                    if($followers >= 1000000) echo round($followers/1000000, 1).'M';
                                                    elseif($followers >= 1000) echo round($followers/1000, 1).'k';
                                                    else echo number_format($followers);
                                                ?>
                                            </td>
                                            <td class="p-4 text-gray-600 text-sm">
                                                <?php echo isset($row['eng_rate']) ? $row['eng_rate'] : '<span class="text-gray-400 text-xs">N/A</span>'; ?>
                                            </td>
                                            <td class="p-4 text-gray-600 text-sm">
                                                <?php if(isset($row['growth_rate'])): ?>
                                                    <?php 
                                                        $gr = $row['growth_rate'];
                                                        $is_pos = (strpos($gr, '-') === false);
                                                    ?>
                                                    <span class="<?php echo $is_pos ? 'text-green-600' : 'text-red-500'; ?>">
                                                        <?php echo $is_pos ? '+' : ''; ?><?php echo $gr; ?>%
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-gray-400 text-xs">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="p-4 text-gray-600 text-sm font-medium">
                                                <?php 
                                                    // Smart Fair Fee Estimation
                                                    // Base: $10 CPM (Cost Per 1,000 Followers)
                                                    // Multiplier: Engagement Rate adjustment
                                                    
                                                    $followers_count = isset($row['followers']) ? (int)$row['followers'] : 0;
                                                    $eng_rate_val = floatval(str_replace('%', '', isset($row['eng_rate']) ? $row['eng_rate'] : '0'));
                                                    
                                                    // Base CPM Range ($5 - $15)
                                                    $min_cpm = 5;
                                                    $max_cpm = 15;
                                                    
                                                    // Engagement Bonus: Higher engagement = Higher value
                                                    if ($eng_rate_val >= 5.0) {
                                                        $min_cpm += 5; // Highly engaging ($10 - $20 CPM)
                                                        $max_cpm += 5;
                                                    } elseif ($eng_rate_val >= 2.0) {
                                                        $min_cpm += 2; // Good engagement ($7 - $17 CPM)
                                                        $max_cpm += 2;
                                                    }
                                                    
                                                    // Calculate Estimate
                                                    $low_est = max(10, floor(($followers_count / 1000) * $min_cpm));
                                                    $high_est = max(25, ceil(($followers_count / 1000) * $max_cpm));
                                                    
                                                    // Format Output
                                                    if ($low_est > 1000) {
                                                        echo '$' . number_format($low_est) . ' - $' . number_format($high_est);
                                                    } else {
                                                        echo '$' . $low_est . ' - $' . $high_est;
                                                    }
                                                ?>
                                            </td>
                                            <td class="p-4">
                                                <div class="flex items-center justify-center gap-2">
                                                    <button onclick='openPeek(<?php echo json_encode($row); ?>)' class="w-8 h-8 rounded-full hover:bg-green-50 text-green-600 flex items-center justify-center transition-colors border border-transparent hover:border-green-100" title="Peek Profile">
                                                        <i class="far fa-eye"></i>
                                                    </button>
                                                    <a href="https://instagram.com/<?php echo $row['username']; ?>" target="_blank" class="w-8 h-8 rounded-full hover:bg-blue-50 text-blue-600 flex items-center justify-center transition-colors border border-transparent hover:border-blue-100" title="Open Profile">
                                                        <i class="fas fa-external-link-alt"></i>
                                                    </a>
                                                    <button class="w-8 h-8 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 flex items-center justify-center transition-colors" title="More">
                                                        <i class="fas fa-ellipsis-h"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination Mockup -->
                        <div class="px-6 py-4 border-t border-gray-100 flex items-center justify-between bg-gray-50/30">
                            <div class="text-sm text-gray-500">
                                Showing <span class="font-medium text-gray-900">1</span> to <span class="font-medium text-gray-900"><?php echo count($results); ?></span> of <span class="font-medium text-gray-900"><?php echo number_format(count($results) * 15 + 245); ?></span> results
                            </div>
                            <div class="flex gap-2">
                                <button class="px-3 py-1 bg-white border border-gray-200 rounded-md text-gray-400 cursor-not-allowed text-sm">Previous</button>
                                <button class="px-3 py-1 bg-white border border-gray-200 rounded-md text-gray-600 hover:bg-gray-50 text-sm">Next</button>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="flex flex-col items-center justify-center py-20 text-center bg-white rounded-xl border border-gray-100 shadow-sm">
                        <div class="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4 text-green-600">
                            <i class="fas fa-search text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">No creators found</h3>
                        <p class="text-gray-500 max-w-md">We couldn't find any influencers matching "<?php echo isset($search_params['keyword']) ? $search_params['keyword'] : ''; ?>". <br>Try checking the spelling or using a different keyword.</p>
                    </div>
                <?php endif; ?>

                <?php if(isset($searched) && $searched && empty($results)): ?>
                    <div class="flex flex-col items-center justify-center py-16 text-center bg-white rounded-xl border border-dashed border-gray-300">
                        <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                            <i class="fas fa-search text-gray-300 text-2xl"></i>
                        </div>
                        <h3 class="text-lg font-semibold text-gray-900">No results found</h3>
                        <p class="text-gray-500 max-w-sm mt-2">
                            <?php echo (isset($warning) && $warning) ? 'Please check the warning message above.' : 'Try adjusting your search terms or filters.'; ?>
                        </p>
                    </div>
                <?php endif; ?>

            </div>
        </main>
    </div>

    <!-- Notification Toast -->
    <div id="toast" class="fixed bottom-5 right-5 bg-white border-l-4 border-brand-green shadow-lg rounded-xl p-4 hidden transform transition-all duration-300 translate-y-full z-50 flex items-center gap-4 pr-6">
        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-check text-brand-green"></i>
        </div>
        <div>
            <h4 class="font-bold text-gray-900 text-sm">Success</h4>
            <p class="text-sm text-gray-500">Action completed successfully.</p>
        </div>
    </div>
    <div id="page-loading" class="fixed inset-0 bg-white/70 backdrop-blur-sm hidden z-50 flex items-center justify-center">
        <div class="flex items-center gap-3 bg-white rounded-xl shadow-lg border border-gray-100 px-5 py-3">
            <i class="fas fa-spinner fa-spin text-brand-green"></i>
            <span class="text-gray-700 font-medium">Searching...</span>
        </div>
    </div>
    <!-- Peek Drawer -->
    <div id="peek-overlay" class="fixed inset-0 bg-black/50 hidden z-50 transition-opacity duration-300" onclick="closePeek()"></div>
    <div id="peek-drawer" class="fixed top-0 right-0 h-full w-full md:w-[600px] bg-white shadow-2xl z-50 transform translate-x-full transition-transform duration-300 overflow-y-auto">
        <div class="p-6">
            <!-- Header -->
            <div class="flex items-start justify-between mb-8">
                <div class="flex items-center gap-4">
                    <div class="relative">
                        <img id="peek-avatar" src="" alt="Profile" class="w-16 h-16 rounded-full object-cover border-2 border-gray-100 p-0.5">
                        <div class="absolute -bottom-1 -right-1 bg-white rounded-full p-1 shadow-sm">
                            <i id="peek-platform-icon" class="fab fa-instagram text-pink-500"></i>
                        </div>
                    </div>
                    <div>
                        <h2 id="peek-fullname" class="text-xl font-bold text-gray-900"></h2>
                        <p id="peek-username" class="text-gray-500 text-sm">@username</p>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <button id="peek-add-btn" class="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                        <i class="fas fa-plus"></i> Add
                    </button>
                    <button onclick="closePeek()" class="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
            </div>

            <!-- Stats -->
            <div class="flex items-center gap-8 mb-8 border-b border-gray-100 pb-8">
                <div>
                    <p id="peek-posts-count" class="text-xl font-bold text-gray-900">0</p>
                    <p class="text-xs text-gray-500 uppercase tracking-wide">Post</p>
                </div>
                <div>
                    <p id="peek-followers" class="text-xl font-bold text-gray-900">0</p>
                    <p class="text-xs text-gray-500 uppercase tracking-wide">Followers</p>
                </div>
                <div>
                    <p id="peek-following" class="text-xl font-bold text-gray-900">0</p>
                    <p class="text-xs text-gray-500 uppercase tracking-wide">Following</p>
                </div>
            </div>

            <!-- Bio -->
            <div class="mb-8">
                <h3 class="text-sm font-bold text-gray-900 mb-2">Bio:</h3>
                <p id="peek-bio" class="text-gray-600 text-sm leading-relaxed"></p>
                <a id="peek-website" href="#" target="_blank" class="text-blue-500 text-sm mt-2 block hover:underline truncate"></a>
            </div>

            <!-- Recent Media Grid -->
            <div>
                <h3 class="text-sm font-bold text-gray-900 mb-4">Recent Posts</h3>
                <div id="peek-media-grid" class="grid grid-cols-2 gap-4">
                    <!-- Media Items injected via JS -->
                </div>
            </div>
        </div>
    </div>

    <script>
        function openPeek(data) {
            // Populate Data
            document.getElementById('peek-fullname').textContent = data.full_name;
            document.getElementById('peek-username').textContent = '@' + data.username;
            document.getElementById('peek-avatar').src = data.profile_image;
            
            // Platform Icon
            const icon = document.getElementById('peek-platform-icon');
            icon.className = ''; // Reset
            if(data.platform === 'youtube') icon.className = 'fab fa-youtube text-red-600';
            else if(data.platform === 'tiktok') icon.className = 'fab fa-tiktok text-black';
            else icon.className = 'fab fa-instagram text-pink-500';

            // Stats
            document.getElementById('peek-followers').textContent = formatNumber(data.followers);
            document.getElementById('peek-following').textContent = formatNumber(data.following || 0);
            document.getElementById('peek-posts-count').textContent = formatNumber(data.posts_count || 0);

            // Bio
            document.getElementById('peek-bio').textContent = data.bio || 'No bio available';
            
            // Website
            const websiteEl = document.getElementById('peek-website');
            if(data.website) {
                websiteEl.href = data.website;
                websiteEl.textContent = data.website;
                websiteEl.classList.remove('hidden');
            } else {
                websiteEl.classList.add('hidden');
            }

            // Media Grid
            const grid = document.getElementById('peek-media-grid');
            grid.innerHTML = ''; // Clear

            if(data.recent_media && data.recent_media.length > 0) {
                data.recent_media.forEach(media => {
                    const div = document.createElement('div');
                    div.className = 'relative group rounded-xl overflow-hidden aspect-square bg-gray-100 border border-gray-100';
                    
                    const isVideo = media.media_type === 'VIDEO';
                    const iconOverlay = isVideo ? '<div class="absolute top-2 right-2 text-white drop-shadow-md"><i class="fas fa-video"></i></div>' : '';
                    const playOverlay = isVideo ? '<div class="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/30 transition-colors"><i class="fas fa-play text-white text-2xl drop-shadow-lg"></i></div>' : '';

                    div.innerHTML = `
                        <img src="${media.media_url}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" onerror="this.src='https://placehold.co/400?text=No+Image'">
                        ${iconOverlay}
                        ${playOverlay}
                        <div class="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                            <div class="flex items-center gap-3 text-white text-xs font-medium">
                                <span><i class="fas fa-heart mr-1"></i> ${formatNumber(media.likes)}</span>
                                <span><i class="fas fa-comment mr-1"></i> ${formatNumber(media.comments)}</span>
                            </div>
                        </div>
                        <div class="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                             <span class="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-1 rounded shadow-sm">Eng. Rate ${data.eng_rate}</span>
                        </div>
                    `;
                    grid.appendChild(div);
                });
            } else {
                grid.innerHTML = `
                    <div class="col-span-2 py-12 text-center text-gray-400 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                        <i class="fas fa-camera text-2xl mb-2"></i>
                        <p class="text-sm">No recent posts found</p>
                    </div>
                `;
            }

            // Update Add Button context
            const addBtn = document.getElementById('peek-add-btn');
            // Remove old listeners to prevent duplicates (cloning is a quick hack)
            const newBtn = addBtn.cloneNode(true);
            addBtn.parentNode.replaceChild(newBtn, addBtn);
            newBtn.onclick = function() {
                addInfluencer(data, this);
            };

            // Show Drawer
            document.getElementById('peek-overlay').classList.remove('hidden');
            // Small delay to allow display:block to apply before transform
            setTimeout(() => {
                document.getElementById('peek-drawer').classList.remove('translate-x-full');
            }, 10);
            document.body.classList.add('overflow-hidden');
        }

        function closePeek() {
            document.getElementById('peek-drawer').classList.add('translate-x-full');
            setTimeout(() => {
                document.getElementById('peek-overlay').classList.add('hidden');
            }, 300);
            document.body.classList.remove('overflow-hidden');
        }

        function formatNumber(num) {
            if(num >= 1000000) return (num/1000000).toFixed(1) + 'M';
            if(num >= 1000) return (num/1000).toFixed(1) + 'k';
            return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (!container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });

        function showPageLoading() {
            document.getElementById('page-loading').classList.remove('hidden');
        }

        function showToast(title, message) {
            const toast = document.getElementById('toast');
            toast.querySelector('h4').textContent = title;
            toast.querySelector('p').textContent = message;
            
            toast.classList.remove('hidden', 'translate-y-full');
            
            setTimeout(() => {
                toast.classList.add('translate-y-full');
                setTimeout(() => {
                    toast.classList.add('hidden');
                }, 300);
            }, 3000);
        }

        function addInfluencer(influencerData, btnElement) {
            const originalText = btnElement.innerHTML;
            const originalClasses = btnElement.className;
            
            btnElement.innerHTML = '<i class="fas fa-spinner fa-spin text-xs"></i> Saving...';
            btnElement.disabled = true;

            $.ajax({
                url: '<?php echo base_url("discovery/add"); ?>',
                type: 'POST',
                data: influencerData,
                dataType: 'json',
                success: function(response) {
                    if(response.status === 'success') {
                        btnElement.innerHTML = '<i class="fas fa-check text-xs"></i> Saved';
                        // Remove initial styling classes
                        btnElement.classList.remove('bg-white', 'text-gray-600', 'border-gray-200', 'hover:border-brand-green', 'hover:text-brand-green', 'shadow-sm');
                        // Add success styling classes
                        btnElement.classList.add('bg-green-50', 'text-green-600', 'border-green-200', 'cursor-default');
                        showToast('Success', 'Influencer added to your list!');
                    } else {
                        btnElement.innerHTML = originalText;
                        btnElement.disabled = false;
                        showToast('Error', response.message || 'Failed to add influencer.');
                    }
                },
                error: function() {
                    btnElement.innerHTML = originalText;
                    btnElement.disabled = false;
                    showToast('Error', 'Server error. Please try again.');
                }
            });
        }
    </script>
    <!-- Filter Modal -->
    <div id="filterModal" class="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-5xl h-[85vh] rounded-xl shadow-2xl flex flex-col md:flex-row overflow-hidden animate-fade-in-up">
            
            <!-- Sidebar -->
            <div class="w-full md:w-64 bg-gray-50 border-r border-gray-200 flex flex-col flex-shrink-0">
                <div class="p-6">
                    <h3 class="font-bold text-lg text-gray-900 mb-6">All Filter</h3>
                    
                    <div class="space-y-1">
                        <button class="w-full text-left px-4 py-2.5 rounded-lg bg-purple-50 text-purple-700 font-medium text-sm">
                            Basic filters
                        </button>
                        <button class="w-full text-left px-4 py-2.5 rounded-lg text-gray-600 hover:bg-gray-100 font-medium text-sm transition-colors">
                            Advanced filters
                        </button>
                    </div>

                    <div class="mt-8">
                        <div class="relative">
                            <select class="w-full appearance-none bg-white border border-gray-200 text-gray-700 py-2.5 px-4 pr-8 rounded-lg focus:outline-none focus:border-purple-500 text-sm">
                                <option>Saved Filters</option>
                            </select>
                            <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                                <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-auto p-6 border-t border-gray-200 md:block hidden">
                    <button onclick="clearFilters()" class="text-red-500 text-sm font-medium hover:text-red-700 flex items-center gap-2">
                        <i class="fas fa-times"></i> Clear All Filters
                    </button>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 flex flex-col min-w-0 bg-white relative">
                <!-- Close Button -->
                <button onclick="toggleFilterModal()" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors p-2 z-10 rounded-full hover:bg-gray-100">
                    <i class="fas fa-times text-xl"></i>
                </button>

                <div class="flex-1 overflow-y-auto p-8 custom-scrollbar">
                    
                    <!-- Basic Filters Header -->
                    <div class="flex items-center justify-between mb-6">
                        <h4 class="text-gray-500 font-medium text-sm uppercase tracking-wider">Basic Filters</h4>
                        <i class="fas fa-chevron-up text-gray-400"></i>
                    </div>

                    <!-- Followers -->
                    <div class="mb-10">
                        <h5 class="font-bold text-gray-900 mb-1">Followers</h5>
                        <p class="text-gray-500 text-xs mb-4">Go smaller if you need creator-affiliates. Go bigger if you have budgets to accommodate fees.</p>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="nano" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('nano')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Nano - 5K to 25K</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="micro" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('micro')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Micro - 25K to 100K</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="macro" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('macro')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Macro - 100K to 500K</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="mega" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('mega')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Mega - 500K to 1M</span>
                            </label>
                            <label class="flex items-center gap-3 cursor-pointer group">
                                <input type="radio" name="follower_preset" value="whale" class="w-5 h-5 text-purple-600 border-gray-300 focus:ring-purple-500" onchange="updateFollowerRange('whale')">
                                <span class="text-gray-700 text-sm group-hover:text-purple-700">Whale - 1M+</span>
                            </label>
                        </div>

                        <h6 class="font-medium text-gray-800 text-sm mb-3">Custom Range</h6>
                        <div class="flex items-center gap-4">
                            <div class="relative w-32">
                                <input type="number" id="min_followers_input" placeholder="Min" class="w-full border border-gray-300 rounded-lg py-2 px-3 text-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            </div>
                            <div class="flex-1 h-1.5 bg-purple-100 rounded-full relative">
                                <div class="absolute inset-y-0 left-0 bg-purple-500 rounded-full w-full opacity-20"></div>
                            </div>
                            <div class="relative w-32">
                                <input type="number" id="max_followers_input" placeholder="Max" class="w-full border border-gray-300 rounded-lg py-2 px-3 text-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            </div>
                        </div>
                    </div>

                    <div class="border-t border-gray-100 my-8"></div>

                    <!-- Location -->
                    <div class="mb-10">
                        <div class="flex items-center gap-1 mb-4 border-b border-gray-200">
                            <button class="px-4 py-2 text-sm font-medium text-purple-600 border-b-2 border-purple-600 bg-purple-50 rounded-t-lg">Influencer Location</button>
                            <button class="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700">Audience Location</button>
                        </div>
                        
                        <p class="text-gray-500 text-xs mb-4">Select the location you want to target.</p>
                        
                        <div class="relative mb-6">
                            <i class="fas fa-search absolute left-3 top-3 text-gray-400 text-sm"></i>
                            <input type="text" id="location_input" placeholder="Find by City or Country" class="w-full border border-gray-300 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500">
                        </div>

                        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                            <?php 
                            $top_locations = ['United States', 'Canada', 'United Kingdom', 'India', 'France', 'Germany', 'Australia', 'New Zealand', 'Spain'];
                            foreach($top_locations as $loc): ?>
                            <label class="flex items-center gap-3 cursor-pointer">
                                <input type="checkbox" name="top_location" value="<?php echo $loc; ?>" class="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500" onchange="updateLocationInput(this)">
                                <span class="text-gray-700 text-sm"><?php echo $loc; ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="border-t border-gray-100 my-8"></div>

                    <!-- Engagement Rate -->
                    <div class="mb-10">
                        <h5 class="font-bold text-gray-900 mb-1">Engagement Rate</h5>
                        <p class="text-gray-500 text-xs mb-6">Select the engagement rate you want. 1-2% is good enough to start.</p>
                        
                        <div class="flex items-center justify-between text-xs font-bold text-gray-700 mb-2">
                            <span>0%</span>
                            <span>15%+</span>
                        </div>
                        <input type="range" id="engagement_slider" min="0" max="15" step="0.5" value="0" class="w-full h-2 bg-purple-100 rounded-lg appearance-none cursor-pointer accent-purple-600">
                        <div class="mt-2 text-center">
                            <span id="engagement_display" class="bg-purple-100 text-purple-700 text-xs font-bold px-2 py-1 rounded">0% +</span>
                        </div>
                    </div>

                    <div class="border-t border-gray-100 my-8"></div>

                    <!-- Email & Gender Row -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <!-- Email -->
                        <div>
                            <h5 class="font-bold text-gray-900 mb-1">Email</h5>
                            <p class="text-gray-500 text-xs mb-4">Do you strictly want to email creators?</p>
                            
                            <div class="flex gap-3">
                                <button type="button" onclick="toggleBtnState(this, 'has_email')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="1">Exists</button>
                                <button type="button" onclick="toggleBtnState(this, 'has_email')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="0">Doesn't Exist</button>
                                <input type="hidden" id="has_email_input" name="has_email_temp" value="">
                            </div>
                        </div>

                        <!-- Gender -->
                        <div>
                            <div class="flex items-center gap-2 mb-2">
                                <h5 class="font-bold text-gray-900">Gender</h5>
                                <div class="bg-purple-50 text-purple-600 text-[10px] px-2 py-0.5 rounded font-medium">Influencer</div>
                            </div>
                            
                            <div class="flex gap-3">
                                <button type="button" onclick="toggleBtnState(this, 'gender')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="male">Male</button>
                                <button type="button" onclick="toggleBtnState(this, 'gender')" class="flex-1 py-2 px-4 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 active:bg-purple-50 active:border-purple-200 transition-colors" data-value="female">Female</button>
                                <input type="hidden" id="gender_input" name="gender_temp" value="">
                            </div>
                        </div>
                    </div>
                    
                </div>

                <!-- Footer -->
                <div class="p-6 border-t border-gray-200 bg-gray-50 flex items-center justify-between">
                     <button onclick="toggleFilterModal()" class="md:hidden text-gray-500 hover:text-gray-700 font-medium text-sm">Cancel</button>
                     
                     <div class="flex items-center gap-4 ml-auto">
                         <button type="button" class="hidden md:block px-6 py-2.5 border border-purple-600 text-purple-600 font-medium rounded-lg hover:bg-purple-50 transition-colors text-sm">
                             <i class="fas fa-history mr-1"></i> Apply Previous
                         </button>
                         <button type="button" onclick="applyFilters()" class="px-8 py-2.5 bg-purple-600 text-white font-medium rounded-lg hover:bg-purple-700 shadow-lg shadow-purple-200 transition-all text-sm">
                             Apply Filters
                         </button>
                     </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Filter Logic
        function toggleFilterModal() {
            const modal = document.getElementById('filterModal');
            modal.classList.toggle('hidden');
            if (!modal.classList.contains('hidden')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        }

        function updateFollowerRange(preset) {
            const minInput = document.getElementById('min_followers_input');
            const maxInput = document.getElementById('max_followers_input');
            
            let min = 0, max = '';
            
            switch(preset) {
                case 'nano': min = 5000; max = 25000; break;
                case 'micro': min = 25000; max = 100000; break;
                case 'macro': min = 100000; max = 500000; break;
                case 'mega': min = 500000; max = 1000000; break;
                case 'whale': min = 1000000; max = ''; break;
            }
            
            minInput.value = min;
            maxInput.value = max;
        }

        function updateLocationInput(checkbox) {
            const input = document.getElementById('location_input');
            const val = checkbox.value;
            
            if (checkbox.checked) {
                // For simplicity, just set the input to the checked value (single selection behavior for now)
                // Or clear others
                document.querySelectorAll('input[name="top_location"]').forEach(cb => {
                    if(cb !== checkbox) cb.checked = false;
                });
                input.value = val;
            } else {
                if(input.value === val) input.value = '';
            }
        }

        const engagementSlider = document.getElementById('engagement_slider');
        const engagementDisplay = document.getElementById('engagement_display');
        
        if (engagementSlider) {
            engagementSlider.addEventListener('input', function() {
                engagementDisplay.textContent = this.value + '% +';
            });
        }

        function toggleBtnState(btn, type) {
            const parent = btn.parentNode;
            const input = document.getElementById(type + '_input');
            const val = btn.getAttribute('data-value');
            
            // Deselect all
            parent.querySelectorAll('button').forEach(b => {
                b.classList.remove('bg-purple-50', 'border-purple-200', 'text-purple-700');
                b.classList.add('border-gray-200', 'text-gray-700');
            });
            
            // Toggle logic
            if (input.value === val) {
                input.value = ''; // Deselect
            } else {
                input.value = val;
                btn.classList.remove('border-gray-200', 'text-gray-700');
                btn.classList.add('bg-purple-50', 'border-purple-200', 'text-purple-700');
            }
        }

        function clearFilters() {
            // Reset inputs
            document.getElementById('min_followers_input').value = '';
            document.getElementById('max_followers_input').value = '';
            document.getElementById('location_input').value = '';
            document.getElementById('engagement_slider').value = 0;
            document.getElementById('engagement_display').textContent = '0% +';
            document.getElementById('has_email_input').value = '';
            document.getElementById('gender_input').value = '';
            
            // Reset radios/checkboxes
            document.querySelectorAll('input[type="radio"]').forEach(el => el.checked = false);
            document.querySelectorAll('input[type="checkbox"]').forEach(el => el.checked = false);
            
            // Reset buttons
            document.querySelectorAll('button[data-value]').forEach(b => {
                b.classList.remove('bg-purple-50', 'border-purple-200', 'text-purple-700');
                b.classList.add('border-gray-200', 'text-gray-700');
            });
        }

        function applyFilters() {
            // Collect values
            const minFollowers = document.getElementById('min_followers_input').value;
            const maxFollowers = document.getElementById('max_followers_input').value;
            const location = document.getElementById('location_input').value;
            const engagement = document.getElementById('engagement_slider').value;
            const hasEmail = document.getElementById('has_email_input').value;
            const gender = document.getElementById('gender_input').value;
            
            // Create/Update hidden inputs in the main search form
            const form = document.querySelector('form[action*="discovery/search"]');
            
            addHiddenInput(form, 'min_followers', minFollowers);
            addHiddenInput(form, 'max_followers', maxFollowers);
            addHiddenInput(form, 'location', location);
            addHiddenInput(form, 'min_engagement', engagement);
            addHiddenInput(form, 'has_email', hasEmail);
            addHiddenInput(form, 'gender', gender);
            
            toggleFilterModal();
            showPageLoading();
            form.submit();
        }

        function toggleExcludeSaved(btn) {
            const isChecked = btn.classList.contains('bg-brand-green');
            const newState = !isChecked;
            
            // Visual Toggle
            if (newState) {
                btn.classList.remove('bg-gray-200');
                btn.classList.add('bg-brand-green');
                btn.querySelector('span').classList.remove('translate-x-0');
                btn.querySelector('span').classList.add('translate-x-5');
            } else {
                btn.classList.add('bg-gray-200');
                btn.classList.remove('bg-brand-green');
                btn.querySelector('span').classList.add('translate-x-0');
                btn.querySelector('span').classList.remove('translate-x-5');
            }
            
            // Update Form & Submit
            const form = document.querySelector('form[action*="discovery/search"]');
            addHiddenInput(form, 'exclude_saved', newState);
            showPageLoading();
            form.submit();
        }

        function addHiddenInput(form, name, value) {
            let input = form.querySelector(`input[name="${name}"]`);
            if (!input) {
                input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                form.appendChild(input);
            }
            input.value = value;
        }

        // Initialize Filters on Load
        document.addEventListener('DOMContentLoaded', function() {
            const params = <?php echo json_encode(isset($search_params) ? $search_params : []); ?>;
            const form = document.querySelector('form[action*="discovery/search"]');

            if(params.min_followers) {
                document.getElementById('min_followers_input').value = params.min_followers;
                addHiddenInput(form, 'min_followers', params.min_followers);
            }
            if(params.max_followers) {
                document.getElementById('max_followers_input').value = params.max_followers;
                addHiddenInput(form, 'max_followers', params.max_followers);
            }
            if(params.location) {
                document.getElementById('location_input').value = params.location;
                addHiddenInput(form, 'location', params.location);
            }
            if(params.min_engagement) {
                document.getElementById('engagement_slider').value = params.min_engagement;
                document.getElementById('engagement_display').textContent = params.min_engagement + '% +';
                addHiddenInput(form, 'min_engagement', params.min_engagement);
            }
            
            // Handle Buttons (Email)
            if(params.has_email !== null && params.has_email !== '') {
                const btn = document.querySelector(`button[onclick*="toggleBtnState"][data-value="${params.has_email}"]`);
                // Manually set state to avoid toggle logic issues on load
                if(btn) {
                    const input = document.getElementById('has_email_input');
                    input.value = params.has_email;
                    btn.classList.remove('border-gray-200', 'text-gray-700');
                    btn.classList.add('bg-purple-50', 'border-purple-200', 'text-purple-700');
                    addHiddenInput(form, 'has_email', params.has_email);
                }
            }

            // Handle Buttons (Gender)
            if(params.gender) {
                const btn = document.querySelector(`button[onclick*="toggleBtnState"][data-value="${params.gender}"]`);
                if(btn) {
                    const input = document.getElementById('gender_input');
                    input.value = params.gender;
                    btn.classList.remove('border-gray-200', 'text-gray-700');
                    btn.classList.add('bg-purple-50', 'border-purple-200', 'text-purple-700');
                    addHiddenInput(form, 'gender', params.gender);
                }
            }

            // Handle Exclude Saved
            if(params.exclude_saved === 'true' || params.exclude_saved === '1') {
                const btn = document.getElementById('exclude_saved_btn');
                if(btn) {
                    btn.classList.remove('bg-gray-200');
                    btn.classList.add('bg-brand-green');
                    btn.querySelector('span').classList.remove('translate-x-0');
                    btn.querySelector('span').classList.add('translate-x-5');
                    addHiddenInput(form, 'exclude_saved', 'true');
                }
            }
        });
    </script>
</body>
</html>