<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827'
                        }
                    }
                }
            }
        }
    </script>
    <link href="<?php echo base_url('assets/css/manager.css'); ?>" rel="stylesheet">
</head>
<body class="bg-gray-50 h-screen flex overflow-hidden text-gray-800">
    <aside class="w-64 bg-[#111827] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex">
        <div class="h-16 flex items-center px-6 border-b border-white/10">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 bg-brand-green rounded-lg flex items-center justify-center text-white font-bold">M</div>
                <span class="text-xl font-bold tracking-tight text-white">Manager Panel</span>
            </div>
        </div>
        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1">
            <a href="<?php echo base_url('manager'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg bg-white/10 text-white">
                <i class="fas fa-chart-line w-6"></i>
                <span class="ml-2">Dashboard</span>
            </a>
            <a href="<?php echo base_url('manager/campaign_planning'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                <i class="fas fa-bullseye w-6"></i>
                <span class="ml-2">Campaign Planning</span>
            </a>
            <a href="<?php echo base_url('manager/influencer_review'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                <i class="fas fa-user-check w-6"></i>
                <span class="ml-2">Influencer Review</span>
            </a>
            <a href="<?php echo base_url('manager/orders_discounts'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                <i class="fas fa-receipt w-6"></i>
                <span class="ml-2">Orders & Discounts</span>
            </a>
            <a href="<?php echo base_url('manager/performance'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                <i class="fas fa-chart-bar w-6"></i>
                <span class="ml-2">Performance</span>
            </a>
            <a href="<?php echo base_url('manager/reports'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                <i class="fas fa-file-alt w-6"></i>
                <span class="ml-2">Reports</span>
            </a>
            <div class="border-t border-white/10 my-4"></div>
            <a href="<?php echo base_url('influencer'); ?>" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                <i class="fas fa-arrow-left w-6"></i>
                <span class="ml-2">Back to App</span>
            </a>
        </nav>
    </aside>
    <div class="flex-1 flex flex-col overflow-hidden">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-10">
            <h2 class="text-lg font-semibold text-gray-800">Manager</h2>
            <div class="flex items-center gap-4">
                <div class="h-8 w-px bg-gray-200 mx-2"></div>
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-green transition-colors"><?php echo isset($user_name) ? $user_name : 'Manager'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user_role) ? ucfirst($user_role) : 'Manager'; ?></p>
                        </div>
                        <div class="relative">
                            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'Manager'); ?>&background=111827&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-gray-200 group-hover:border-brand-green transition-all">
                            <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-green transition-colors"></i>
                    </button>
                    <div id="user-menu" class="hidden absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 py-1 z-50 transform origin-top-right transition-all">
                        <div class="px-4 py-3 border-b border-gray-100">
                            <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold">Account</p>
                        </div>
                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5"></i> Settings
                        </a>
                        <div class="border-t border-gray-100 my-1"></div>
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6 md:p-8">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <a href="<?php echo base_url('manager/campaign_planning'); ?>" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
                    <div class="flex items-center gap-3 mb-3">
                        <i class="fas fa-bullseye text-brand-green"></i>
                        <h3 class="text-lg font-bold text-gray-900">Campaign Planning</h3>
                    </div>
                    <p class="text-sm text-gray-600">Define goals, set KPIs & budget, assign employees.</p>
                </a>
                <a href="<?php echo base_url('manager/influencer_review'); ?>" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
                    <div class="flex items-center gap-3 mb-3">
                        <i class="fas fa-user-check text-brand-green"></i>
                        <h3 class="text-lg font-bold text-gray-900">Influencer Review & Approval</h3>
                    </div>
                    <p class="text-sm text-gray-600">Review sourced influencers and approve outreach.</p>
                </a>
                <a href="<?php echo base_url('manager/orders_discounts'); ?>" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
                    <div class="flex items-center gap-3 mb-3">
                        <i class="fas fa-receipt text-brand-green"></i>
                        <h3 class="text-lg font-bold text-gray-900">Order & Discount Oversight</h3>
                    </div>
                    <p class="text-sm text-gray-600">Approve orders, review discount codes and links.</p>
                </a>
                <a href="<?php echo base_url('manager/performance'); ?>" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
                    <div class="flex items-center gap-3 mb-3">
                        <i class="fas fa-chart-bar text-brand-green"></i>
                        <h3 class="text-lg font-bold text-gray-900">Performance Monitoring</h3>
                    </div>
                    <p class="text-sm text-gray-600">Track sales, conversions and top performers.</p>
                </a>
                <a href="<?php echo base_url('manager/reports'); ?>" class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition">
                    <div class="flex items-center gap-3 mb-3">
                        <i class="fas fa-file-alt text-brand-green"></i>
                        <h3 class="text-lg font-bold text-gray-900">Report Approval</h3>
                    </div>
                    <p class="text-sm text-gray-600">Review employee reports and submit final report.</p>
                </a>
            </div>
            <?php $section = isset($active_section) ? $active_section : 'dashboard'; ?>
            <?php if ($section === 'campaign_planning'): ?>
            <form action="<?php echo base_url('manager/save_campaign'); ?>" method="post">
                <div class="mt-8 space-y-6">
                    <?php if($this->session->flashdata('success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <span class="block sm:inline"><?php echo $this->session->flashdata('success'); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h4 class="font-semibold text-gray-900 mb-3">Define Campaign Goals</h4>
                        <textarea name="goals" class="w-full border border-gray-200 rounded-lg p-3" rows="4" placeholder="Goals" required></textarea>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h4 class="font-semibold text-gray-900 mb-3">Set KPIs & Budget</h4>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <input type="number" name="sales_target" class="border border-gray-200 rounded-lg p-3" placeholder="Sales Target" required>
                            <input type="number" step="0.01" name="conversion_rate" class="border border-gray-200 rounded-lg p-3" placeholder="Conversion Rate (%)" required>
                            <input type="number" name="budget" class="border border-gray-200 rounded-lg p-3" placeholder="Budget" required>
                        </div>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <h4 class="font-semibold text-gray-900 mb-3">Assign Employees</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-60 overflow-y-auto">
                            <?php if(isset($employees) && !empty($employees)): ?>
                                <?php foreach($employees as $emp): ?>
                                    <label class="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                                        <input type="checkbox" name="assigned_employees[]" value="<?php echo $emp->id; ?>" class="form-checkbox h-5 w-5 text-brand-green rounded">
                                        <span class="text-gray-700"><?php echo isset($emp->name) ? $emp->name : $emp->email; ?></span>
                                    </label>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="text-gray-500 col-span-full text-center py-4">No employees found to assign.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit" class="bg-brand-green hover:bg-brand-deep text-white px-6 py-3 rounded-lg font-bold shadow-sm transition-all transform hover:scale-105">
                            Create Campaign
                        </button>
                    </div>
                </div>
            </form>

            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mt-8">
                <h4 class="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <i class="fas fa-list text-brand-green"></i> Active Campaigns
                </h4>
                <?php if(isset($campaigns) && !empty($campaigns)): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-gray-600">
                            <thead class="bg-gray-50 text-gray-900 font-semibold border-b border-gray-200">
                                <tr>
                                    <th class="p-3">Goals</th>
                                    <th class="p-3">Sales Target</th>
                                    <th class="p-3">Budget</th>
                                    <th class="p-3">Status</th>
                                    <th class="p-3">Created Date</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php foreach($campaigns as $camp): ?>
                                    <tr class="hover:bg-gray-50 transition-colors">
                                        <td class="p-3 font-medium text-gray-900"><?php echo isset($camp->goals) ? htmlspecialchars(substr($camp->goals, 0, 50)) . (strlen($camp->goals) > 50 ? '...' : '') : '-'; ?></td>
                                        <td class="p-3"><?php echo isset($camp->sales_target) ? number_format($camp->sales_target) : '-'; ?></td>
                                        <td class="p-3 font-semibold text-brand-green">$<?php echo isset($camp->budget) ? number_format($camp->budget, 2) : '-'; ?></td>
                                        <td class="p-3">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                <?php echo isset($camp->status) ? ucfirst($camp->status) : 'Active'; ?>
                                            </span>
                                        </td>
                                        <td class="p-3 text-gray-500"><?php echo isset($camp->created_at) ? date('M d, Y', strtotime($camp->created_at)) : '-'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                        <i class="fas fa-clipboard-list text-gray-400 text-4xl mb-3"></i>
                        <p class="text-gray-500">No campaigns created yet.</p>
                    </div>
                <?php endif; ?>
            </div>

            <?php elseif ($section === 'influencer_review'): ?>
            <div class="mt-8 space-y-6">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-3">Review Sourced Influencers</h4>
                    <a href="<?php echo base_url('influencer'); ?>" class="inline-flex items-center gap-2 text-brand-green hover:text-brand-deep font-semibold">
                        <i class="fas fa-users"></i>
                        Go to Influencer List
                    </a>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-3">Approve Outreach Messages</h4>
                    <div class="flex items-center gap-3">
                        <input type="text" class="flex-1 border border-gray-200 rounded-lg p-3" placeholder="Search outreach drafts">
                        <button class="bg-brand-green hover:bg-brand-deep text-white px-4 py-2 rounded-lg text-sm font-semibold">Approve</button>
                        <button class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg text-sm font-semibold">Reject</button>
                    </div>
                </div>
            </div>
            <?php elseif ($section === 'orders_discounts'): ?>
            <div class="mt-8 space-y-6">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-3">Approve Influencer Orders</h4>
                    <div class="flex items-center gap-3">
                        <input type="text" class="flex-1 border border-gray-200 rounded-lg p-3" placeholder="Search orders">
                        <button class="bg-brand-green hover:bg-brand-deep text-white px-4 py-2 rounded-lg text-sm font-semibold">Approve</button>
                    </div>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-3">Review Discount Codes</h4>
                    <div class="flex items-center gap-3">
                        <input type="text" class="flex-1 border border-gray-200 rounded-lg p-3" placeholder="Discount code">
                        <button class="bg-brand-green hover:bg-brand-deep text-white px-4 py-2 rounded-lg text-sm font-semibold">Validate</button>
                    </div>
                </div>
            </div>
            <?php elseif ($section === 'performance'): ?>
            <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-1">Sales</h4>
                    <p class="text-3xl font-bold text-brand-green">-</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-1">Conversions</h4>
                    <p class="text-3xl font-bold text-brand-green">-</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-1">Top Performers</h4>
                    <p class="text-3xl font-bold text-brand-green">-</p>
                </div>
            </div>
            <?php elseif ($section === 'reports'): ?>
            <div class="mt-8 space-y-6">
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-3">Review Employee Reports</h4>
                    <div class="flex items-center gap-3">
                        <input type="text" class="flex-1 border border-gray-200 rounded-lg p-3" placeholder="Search reports">
                        <button class="bg-brand-green hover:bg-brand-deep text-white px-4 py-2 rounded-lg text-sm font-semibold">Open</button>
                    </div>
                </div>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 class="font-semibold text-gray-900 mb-3">Submit Final Campaign Report</h4>
                    <div class="flex items-center gap-3">
                        <input type="text" class="flex-1 border border-gray-200 rounded-lg p-3" placeholder="Report title">
                        <button class="bg-brand-green hover:bg-brand-deep text-white px-4 py-2 rounded-lg text-sm font-semibold">Submit</button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
    <script>
        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }
        document.addEventListener('click', function(e) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(e.target)) {
                menu.classList.add('hidden');
            }
        });
    </script>
</body>
</html>
