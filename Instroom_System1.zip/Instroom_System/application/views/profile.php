<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    /**
     * @var object $user
     * @var string $user_name
     */
    ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile | Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827',
                            gray: '#F9FAFB',
                            border: '#E5E7EB',
                        }
                    },
                    boxShadow: {
                        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -1px rgba(0, 0, 0, 0.02)',
                        'card': '0 0 0 1px rgba(0,0,0,0.03), 0 2px 8px rgba(0,0,0,0.04)',
                    }
                }
            }
        }
    </script>
    <link href="<?php echo base_url('assets/css/settings.css'); ?>" rel="stylesheet">
</head>
<body class="bg-brand-gray h-screen flex overflow-hidden text-gray-800">

    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 bg-[#0F6B3E] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex fixed md:relative z-30 h-full top-0 left-0 shadow-xl">
        <div class="h-16 flex items-center px-8 border-b border-white/10">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bolt text-brand-green text-lg"></i>
                    </div>
                    <span class="text-xl font-bold tracking-tight text-white">INSTROOM</span>
                </div>
                <button class="md:hidden text-white/70 hover:text-white transition-colors focus:outline-none" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Main Menu</p>
            
            <a href="<?php echo base_url('welcome'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-tachometer-alt w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            
            <a href="<?php echo base_url('discovery'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-search w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Discovery</span>
            </a>
            
            <a href="<?php echo base_url('influencer'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-list-ul w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Influencer List</span>
            </a>

            <a href="<?php echo base_url('influencer/pipeline'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-filter w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Pipeline</span>
            </a>

            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mt-8 mb-3">Campaigns</p>

            <a href="<?php echo base_url('influencer/closed_collaborations'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="far fa-check-square w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Closed</span>
            </a>
            
            <a href="#" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-users w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Ambassadors</span>
            </a>
            
            <a href="<?php echo base_url('influencer/analytics'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-chart-line w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Analytics</span>
            </a>
        </nav>


    </aside>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden relative bg-white">
        
        <!-- Top Navigation -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-20 sticky top-0">
            <div class="flex items-center md:hidden">
                <button class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 rounded-md hover:bg-gray-100 transition-colors" onclick="toggleSidebar()">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <span class="ml-4 text-lg font-bold text-brand-deep">INSTROOM</span>
            </div>
            
            <div class="hidden md:flex items-center text-gray-500 text-sm font-medium">
                <span class="text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">User</span>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <span class="text-brand-deep bg-green-50 px-2 py-1 rounded-md">Profile</span>
            </div>

            <div class="flex items-center gap-4">
                <button class="relative p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100">
                    <i class="far fa-bell text-xl"></i>
                    <span class="absolute top-1.5 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div class="h-8 w-px bg-gray-200 mx-2"></div>

                <!-- User Dropdown -->
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-deep transition-colors"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user->role) ? ucfirst($user->role) : 'User'; ?></p>
                        </div>
                        <div class="relative">
                             <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'User'); ?>&background=1FAE5B&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-white group-hover:border-brand-green transition-all">
                             <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-deep transition-colors"></i>
                    </button>
                    
                    <!-- Dropdown Menu -->
                    <div id="user-menu" class="hidden absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 py-1 z-50 transform origin-top-right transition-all">
                        <div class="px-4 py-3 border-b border-gray-100">
                            <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold">Account</p>
                        </div>

                        <?php if(isset($user->role) && $user->role === 'admin'): ?>
                        <a href="<?php echo base_url('admin'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-tachometer-alt w-5"></i> Admin Dashboard
                        </a>
                        <?php endif; ?>

                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5"></i> Settings
                        </a>
                        <div class="border-t border-gray-100 my-1"></div>
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Scrollable Area -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6 md:p-8 scroll-smooth">
            
            <!-- Header Section -->
            <div class="mb-8">
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">User Profile</h1>
                <p class="text-gray-500 mt-1">Manage your account settings and preferences.</p>
            </div>

            <!-- Flash Messages -->
            <?php if($this->session->flashdata('success')): ?>
            <div class="bg-green-50 border-l-4 border-brand-green p-4 mb-6 rounded-r-lg shadow-sm">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-check-circle text-brand-green"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-green-700"><?php echo $this->session->flashdata('success'); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if($this->session->flashdata('error')): ?>
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg shadow-sm">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-circle text-red-500"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-700"><?php echo $this->session->flashdata('error'); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Profile Card -->
                <div class="lg:col-span-1">
                    <div class="bg-white rounded-2xl shadow-card border border-gray-100 overflow-hidden">
                        <div class="bg-gradient-to-r from-green-600 to-brand-deep h-32"></div>
                        <div class="px-6 pb-6 relative">
                            <div class="relative -top-12 mb-[-30px]">
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user_name); ?>&background=ffffff&color=0F6B3E&rounded=true&bold=true&size=128" alt="User Avatar" class="w-24 h-24 rounded-full border-4 border-white shadow-lg">
                            </div>
                            <div class="mt-4 pt-10">
                                <h2 class="text-xl font-bold text-gray-900"><?php echo $user->name; ?></h2>
                                <p class="text-sm text-gray-500"><?php echo $user->email; ?></p>
                                <div class="mt-4 flex flex-wrap gap-2">
                                    <span class="px-3 py-1 text-xs font-semibold text-green-700 bg-green-50 rounded-full border border-green-100"><?php echo isset($user->role) ? ucfirst($user->role) : 'User'; ?></span>
                                    <span class="px-3 py-1 text-xs font-semibold text-blue-700 bg-blue-50 rounded-full border border-blue-100">Verified</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Forms -->
                <div class="lg:col-span-2 space-y-8">
                    <!-- Update Info -->
                    <div class="bg-white p-6 rounded-2xl shadow-card border border-gray-100">
                        <h3 class="text-lg font-bold text-gray-900 mb-6 border-b border-gray-100 pb-4">Personal Information</h3>
                        <form action="<?php echo base_url('profile/update'); ?>" method="post">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
                                    <input type="text" name="name" value="<?php echo $user->name; ?>" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-colors" required>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                                    <input type="email" name="email" value="<?php echo $user->email; ?>" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-colors" required>
                                </div>
                            </div>
                            <div class="flex justify-end">
                                <button type="submit" class="bg-brand-green hover:bg-green-600 text-white px-6 py-2.5 rounded-lg text-sm font-semibold shadow-sm transition-all flex items-center gap-2">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Change Password -->
                    <div class="bg-white p-6 rounded-2xl shadow-card border border-gray-100">
                        <h3 class="text-lg font-bold text-gray-900 mb-6 border-b border-gray-100 pb-4">Change Password</h3>
                        <form action="<?php echo base_url('profile/change_password'); ?>" method="post">
                            <div class="space-y-4 mb-6">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">Current Password</label>
                                    <input type="password" name="current_password" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-colors" required>
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label class="block text-sm font-semibold text-gray-700 mb-2">New Password</label>
                                        <input type="password" name="new_password" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-colors" required>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-semibold text-gray-700 mb-2">Confirm New Password</label>
                                        <input type="password" name="confirm_password" class="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green transition-colors" required>
                                    </div>
                                </div>
                            </div>
                            <div class="flex justify-end">
                                <button type="submit" class="bg-gray-800 hover:bg-gray-900 text-white px-6 py-2.5 rounded-lg text-sm font-semibold shadow-sm transition-all flex items-center gap-2">
                                    <i class="fas fa-key"></i> Update Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <!-- Toggle Sidebar Script -->
    <script>
        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('absolute');
            sidebar.classList.toggle('z-40');
            sidebar.classList.toggle('h-full');
        }
    </script>
</body>
</html>
