<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Dashboard - Instroom</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            green: '#1FAE5B',
                            deep: '#0F6B3E',
                            dark: '#111827',
                            gray: '#F9FAFB',
                            border: '#E5E7EB',
                            blue: '#3B82F6',
                            purple: '#8B5CF6',
                            rose: '#F43F5E',
                            amber: '#F59E0B'
                        }
                    },
                    boxShadow: {
                        'card': '0 2px 5px -1px rgba(0, 0, 0, 0.05), 0 1px 3px -1px rgba(0, 0, 0, 0.03)',
                        'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)',
                        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)',
                    }
                }
            }
        }
    </script>
    <link href="<?php echo base_url('assets/css/welcome.css'); ?>" rel="stylesheet">
</head>
<body class="bg-gray-50 h-screen flex overflow-hidden text-gray-800">

    <!-- Sidebar -->
    <aside id="sidebar" class="w-72 bg-[#0F6B3E] flex-shrink-0 flex flex-col transition-all duration-300 hidden md:flex fixed md:relative z-30 h-full top-0 left-0 shadow-xl">
        <div class="h-16 flex items-center px-8 border-b border-white/10">
            <div class="flex items-center justify-between w-full">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bolt text-brand-green text-lg"></i>
                    </div>
                    <span class="text-xl font-bold tracking-tight text-white">INSTROOM</span>
                </div>
                <button class="md:hidden text-white/70 hover:text-white transition-colors focus:outline-none" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <nav class="flex-1 overflow-y-auto py-6 px-4 space-y-1.5">
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Main Menu</p>
            
            <a href="<?php echo base_url('welcome'); ?>" class="sidebar-item active group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white bg-white/5">
                <i class="fas fa-tachometer-alt w-6 text-lg opacity-100 transition-opacity"></i>
                <span class="ml-3">Dashboard</span>
            </a>
            
            <a href="<?php echo base_url('discovery'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-search w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Discovery</span>
            </a>
            
            <a href="<?php echo base_url('influencer'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-list-ul w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Influencer List</span>
            </a>

            <a href="<?php echo base_url('influencer/pipeline'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-filter w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Pipeline</span>
            </a>
            
            <p class="px-4 text-xs font-semibold text-white/40 uppercase tracking-wider mt-8 mb-3">Campaigns</p>

            <a href="<?php echo base_url('influencer/closed_collaborations'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="far fa-check-square w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Closed</span>
            </a>
            
            <a href="#" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-users w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Ambassadors</span>
            </a>
            
            <a href="<?php echo base_url('influencer/analytics'); ?>" class="sidebar-item group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 text-white/70 hover:text-white">
                <i class="fas fa-chart-line w-6 text-lg opacity-70 group-hover:opacity-100 transition-opacity"></i>
                <span class="ml-3">Analytics</span>
            </a>
        </nav>


    </aside>

    <!-- Main Content Wrapper -->
    <div class="flex-1 flex flex-col h-screen overflow-hidden relative bg-white">
        
        <!-- Top Navigation -->
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 z-20 sticky top-0">
            <div class="flex items-center md:hidden">
                <button class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 rounded-md hover:bg-gray-100 transition-colors" onclick="toggleSidebar()">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <span class="ml-4 text-lg font-bold text-brand-deep">INSTROOM</span>
            </div>
            
            <div class="hidden md:flex items-center text-gray-500 text-sm font-medium">
                <span class="text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">Home</span>
                <i class="fas fa-chevron-right text-xs mx-3 text-gray-300"></i>
                <span class="text-brand-deep bg-green-50 px-2 py-1 rounded-md">Dashboard</span>
            </div>

            <div class="flex items-center gap-4">
                <button class="relative p-2 text-gray-400 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100">
                    <i class="far fa-bell text-xl"></i>
                    <span class="absolute top-1.5 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
                
                <div class="h-8 w-px bg-gray-200 mx-2"></div>

                <!-- User Dropdown -->
                <div class="relative" id="user-menu-container">
                    <button onclick="toggleUserMenu()" class="flex items-center gap-3 cursor-pointer group focus:outline-none">
                        <div class="text-right hidden sm:block">
                            <p class="text-sm font-semibold text-gray-800 group-hover:text-brand-deep transition-colors"><?php echo isset($user_name) ? $user_name : 'User'; ?></p>
                            <p class="text-xs text-gray-500"><?php echo isset($user_role) ? ucfirst($user_role) : 'User'; ?></p>
                        </div>
                        <div class="relative">
                             <img src="https://ui-avatars.com/api/?name=<?php echo urlencode(isset($user_name) ? $user_name : 'User'); ?>&background=1FAE5B&color=fff&rounded=true&bold=true" alt="User Avatar" class="w-9 h-9 rounded-full shadow-sm border-2 border-white group-hover:border-brand-green transition-all">
                             <div class="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                        </div>
                        <i class="fas fa-chevron-down text-gray-400 text-xs ml-1 group-hover:text-brand-deep transition-colors"></i>
                    </button>
                    
                    <!-- Dropdown Menu -->
                    <div id="user-menu" class="hidden absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 py-1 z-50 transform origin-top-right transition-all">
                        <div class="px-4 py-3 border-b border-gray-100">
                            <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold">Account</p>
                        </div>
                        <?php if(isset($user_role) && $user_role === 'admin'): ?>
                        <a href="<?php echo base_url('admin'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-tachometer-alt w-5"></i> Admin Dashboard
                        </a>
                        <?php endif; ?>
                        <a href="<?php echo base_url('profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="far fa-user w-5"></i> Profile
                        </a>
                        <a href="<?php echo base_url('settings'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-brand-green transition-colors">
                            <i class="fas fa-cog w-5"></i> Settings
                        </a>
                        <div class="border-t border-gray-100 my-1"></div>
                        <a href="<?php echo base_url('auth/logout'); ?>" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                            <i class="fas fa-sign-out-alt w-5"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto bg-gray-50/50 p-6 md:p-8 scroll-smooth">
            
            <div class="max-w-7xl mx-auto">
                <div class="flex justify-between items-end mb-10">
                    <div>
                        <h1 class="text-3xl font-bold text-brand-charcoal tracking-tight">Overview</h1>
                        <p class="text-gray-500 mt-2">Here's what's happening with your influencers today.</p>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                    <!-- Card 1 -->
                    <div class="bg-white rounded-2xl p-6 shadow-soft border border-gray-50 hover:shadow-lg transition-all duration-300 group">
                        <div class="flex justify-between items-start mb-4">
                            <div class="p-3 bg-blue-50 rounded-xl group-hover:bg-brand-blue group-hover:text-white transition-colors duration-300">
                                <i class="fas fa-users text-brand-blue text-xl group-hover:text-white transition-colors"></i>
                            </div>
                            <span class="text-xs font-semibold text-green-600 bg-green-50 px-2.5 py-1 rounded-lg">+12%</span>
                        </div>
                        <p class="text-gray-500 text-sm font-medium">Total Influencers</p>
                        <h3 class="text-3xl font-bold text-brand-charcoal mt-1"><?php echo isset($total_influencers) ? number_format($total_influencers) : '0'; ?></h3>
                    </div>

                    <!-- Card 2 -->
                    <div class="bg-white rounded-2xl p-6 shadow-soft border border-gray-50 hover:shadow-lg transition-all duration-300 group">
                        <div class="flex justify-between items-start mb-4">
                            <div class="p-3 bg-green-50 rounded-xl group-hover:bg-brand-green group-hover:text-white transition-colors duration-300">
                                <i class="fas fa-bullhorn text-brand-green text-xl group-hover:text-white transition-colors"></i>
                            </div>
                            <span class="text-xs font-semibold text-green-600 bg-green-50 px-2.5 py-1 rounded-lg">+5%</span>
                        </div>
                        <p class="text-gray-500 text-sm font-medium">Active Campaigns</p>
                        <h3 class="text-3xl font-bold text-brand-charcoal mt-1">8</h3>
                    </div>

                    <!-- Card 3 -->
                    <div class="bg-white rounded-2xl p-6 shadow-soft border border-gray-50 hover:shadow-lg transition-all duration-300 group">
                        <div class="flex justify-between items-start mb-4">
                            <div class="p-3 bg-amber-50 rounded-xl group-hover:bg-brand-amber group-hover:text-white transition-colors duration-300">
                                <i class="fas fa-star text-brand-amber text-xl group-hover:text-white transition-colors"></i>
                            </div>
                            <span class="text-xs font-semibold text-red-500 bg-red-50 px-2.5 py-1 rounded-lg">-2%</span>
                        </div>
                        <p class="text-gray-500 text-sm font-medium">Avg. Engagement</p>
                        <h3 class="text-3xl font-bold text-brand-charcoal mt-1">4.2%</h3>
                    </div>

                    <!-- Card 4 -->
                    <div class="bg-white rounded-2xl p-6 shadow-soft border border-gray-50 hover:shadow-lg transition-all duration-300 group">
                        <div class="flex justify-between items-start mb-4">
                            <div class="p-3 bg-gray-100 rounded-xl group-hover:bg-brand-deep group-hover:text-white transition-colors duration-300">
                                <i class="fas fa-wallet text-brand-deep text-xl group-hover:text-white transition-colors"></i>
                            </div>
                            <span class="text-xs font-semibold text-gray-500 bg-gray-100 px-2.5 py-1 rounded-lg">YTD</span>
                        </div>
                        <p class="text-gray-500 text-sm font-medium">Total Spend</p>
                        <h3 class="text-3xl font-bold text-brand-charcoal mt-1">$12,450</h3>
                    </div>
                </div>

                <!-- Recent Activity & Charts Section -->
                <div class="w-full">
                    <!-- Activity Feed -->
                    <div class="bg-white rounded-2xl shadow-soft border border-gray-50 p-8">
                        <h2 class="text-lg font-bold text-brand-charcoal mb-6">Recent Activity</h2>
                        
                        <div class="space-y-6">
                            <?php if (isset($activities) && !empty($activities)): ?>
                                <?php foreach ($activities as $index => $activity): ?>
                                    <div class="flex items-start group">
                                        <div class="flex-shrink-0 relative">
                                            <div class="h-10 w-10 rounded-full bg-<?php echo str_replace('brand-', '', $activity['color']); ?>-50 flex items-center justify-center border border-<?php echo str_replace('brand-', '', $activity['color']); ?>-100">
                                                <i class="fas <?php echo $activity['icon']; ?> text-<?php echo str_replace('brand-', '', $activity['color']); ?>-600 text-sm"></i>
                                            </div>
                                            <?php if ($index < count($activities) - 1): ?>
                                            <div class="absolute top-10 left-1/2 -ml-px h-full w-0.5 bg-gray-100" aria-hidden="true"></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ml-4 min-w-0 flex-1">
                                            <div class="text-sm font-medium text-brand-charcoal">
                                                <?php echo $activity['title']; ?>
                                            </div>
                                            <div class="text-sm text-gray-500 mt-1">
                                                <?php echo $activity['description']; ?>
                                            </div>
                                            <div class="text-xs text-gray-400 mt-2"><?php echo $activity['time']; ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="text-gray-500 text-sm">No recent activity found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('absolute');
            sidebar.classList.toggle('z-40');
            sidebar.classList.toggle('h-full');
        }

        function toggleUserMenu() {
            const menu = document.getElementById('user-menu');
            menu.classList.toggle('hidden');
        }

        // Close on click outside
        document.addEventListener('click', function(event) {
            const container = document.getElementById('user-menu-container');
            const menu = document.getElementById('user-menu');
            if (container && menu && !container.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });
    </script>
</body>
</html>