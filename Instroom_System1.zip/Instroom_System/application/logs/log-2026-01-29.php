<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-29 04:43:54 --> Instagram API (RapidAPI) Error: Operation timed out after 30000 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 04:44:48 --> Instagram API (RapidAPI) Error: Operation timed out after 30001 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 04:46:50 --> Instagram API (RapidAPI) HTTP Error: 404 Response: {"message":"API doesn't exists"}
ERROR - 2026-01-29 04:46:56 --> Instagram API (RapidAPI) HTTP Error: 404 Response: {"message":"API doesn't exists"}
ERROR - 2026-01-29 04:47:33 --> Instagram API (RapidAPI) Error: Operation timed out after 30001 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 04:50:19 --> Instagram API (RapidAPI) Error: Operation timed out after 30000 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 04:50:23 --> Instagram API (RapidAPI) HTTP Error: 404 Response: {"message":"API doesn't exists"}
ERROR - 2026-01-29 04:50:29 --> Instagram API (RapidAPI) HTTP Error: 404 Response: {"message":"API doesn't exists"}
ERROR - 2026-01-29 04:51:00 --> Instagram API (RapidAPI) Error: Operation timed out after 30000 milliseconds with 0 bytes received
ERROR - 2026-01-29 04:51:46 --> Instagram API (RapidAPI) Error: Operation timed out after 30001 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 04:53:46 --> Instagram Search API Failed (0). Trying Direct Username Lookup...
ERROR - 2026-01-29 04:53:57 --> Instagram Search API Failed (404). Trying Direct Username Lookup...
ERROR - 2026-01-29 04:53:59 --> Instagram Search API Failed (429). Trying Direct Username Lookup...
ERROR - 2026-01-29 04:54:42 --> Instagram Search API Failed (404). Trying Direct Username Lookup...
ERROR - 2026-01-29 08:42:34 --> Instagram Search API Failed (404). Trying Direct Username Lookup...
ERROR - 2026-01-29 09:02:37 --> Instagram API (RapidAPI) Error: Operation timed out after 45000 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 09:05:45 --> Instagram API (RapidAPI) Error: Operation timed out after 45000 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 09:15:59 --> Instagram API (RapidAPI) HTTP Error: 404 Response: {"message":"Endpoint '\/search' does not exist"}
ERROR - 2026-01-29 09:35:59 --> Instagram API (RapidAPI) Error: Operation timed out after 45000 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 09:37:31 --> Instagram API (RapidAPI) Error: Operation timed out after 45000 milliseconds with 0 out of 0 bytes received
ERROR - 2026-01-29 10:41:24 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "bio", expecting "function" or "const" C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 241
ERROR - 2026-01-29 10:41:29 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "bio", expecting "function" or "const" C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 241
ERROR - 2026-01-29 10:41:42 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "bio", expecting "function" or "const" C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 241
ERROR - 2026-01-29 10:41:44 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "bio", expecting "function" or "const" C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 241
ERROR - 2026-01-29 10:46:34 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: Nike cannot be found.","fbtrace_id":"A2JxXe6YunyGHzVEaLOk-ZT"}
ERROR - 2026-01-29 10:46:38 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: Nike cannot be found.","fbtrace_id":"A8POoZmsII0pZGcPeqWU6wa"}
ERROR - 2026-01-29 10:46:39 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: Nike cannot be found.","fbtrace_id":"A74pLFH9XAxTwMUTstDo6Lp"}
ERROR - 2026-01-29 10:46:41 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: Nike cannot be found.","fbtrace_id":"AXw5hqWvv3uJb_czz4mEOJN"}
ERROR - 2026-01-29 10:46:48 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: Nike cannot be found.","fbtrace_id":"Ae-BnmYXMa-SFGkxpFRBR4x"}
ERROR - 2026-01-29 10:50:08 --> Severity: Warning --> Undefined array key "profile_image" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 479
ERROR - 2026-01-29 10:50:08 --> Severity: Warning --> Undefined array key "full_name" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 484
ERROR - 2026-01-29 10:50:08 --> Severity: Warning --> Undefined array key "full_name" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 485
ERROR - 2026-01-29 10:50:15 --> Severity: Warning --> Undefined array key "profile_image" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 479
ERROR - 2026-01-29 10:50:15 --> Severity: Warning --> Undefined array key "full_name" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 484
ERROR - 2026-01-29 10:50:15 --> Severity: Warning --> Undefined array key "full_name" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 485
ERROR - 2026-01-29 10:50:23 --> Severity: Warning --> Undefined array key "profile_image" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 479
ERROR - 2026-01-29 10:50:23 --> Severity: Warning --> Undefined array key "full_name" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 484
ERROR - 2026-01-29 10:50:23 --> Severity: Warning --> Undefined array key "full_name" C:\xampp\htdocs\Instroom_System\application\views\discovery\index.php 485
ERROR - 2026-01-29 10:54:48 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: congtv cannot be found.","fbtrace_id":"AOXC5ARghED6YIfIsn_11sI"}
ERROR - 2026-01-29 10:55:12 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: xe.zyyy cannot be found.","fbtrace_id":"AX_MrhuVUAMHNSz3JJfFBBY"}
ERROR - 2026-01-29 10:55:14 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: xe.zyyy cannot be found.","fbtrace_id":"ASNUtQCb4lrJwOF--icllpE"}
ERROR - 2026-01-29 10:55:16 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: xe.zyyy cannot be found.","fbtrace_id":"AiJ5GbTT9mTsoOAgnXCWoc3"}
ERROR - 2026-01-29 10:56:39 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: lifeofayemami cannot be found.","fbtrace_id":"ADD4rNoJba6o3dGHWH6hMdi"}
ERROR - 2026-01-29 10:58:51 --> Graph API Error: {"message":"Invalid user id","type":"OAuthException","code":110,"error_subcode":2207013,"is_transient":false,"error_user_title":"Cannot find User","error_user_msg":"The user with username: ejmpower cannot be found.","fbtrace_id":"AwSUFbaGAOtHjv69QDI2QB2"}
