<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-31 03:18:05 --> TikTok API Response: Array
(
    [message] => API doesn't exists
)

ERROR - 2026-01-31 03:20:40 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 820
ERROR - 2026-01-31 03:23:11 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 820
ERROR - 2026-01-31 03:28:19 --> TikTok API Response: Array
(
    [message] => You are not subscribed to this API.
)

ERROR - 2026-01-31 03:32:22 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Instroom_System\application\controllers\Discovery.php 822
