<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Base Controller
 * @property CI_Session $session
 * @property CI_Loader $load
 * @property CI_Input $input
 * @property CI_Output $output
 */
class MY_Controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
    }
}

/**
 * Auth Controller - Ensures user is logged in
 */
class Auth_Controller extends MY_Controller {
    
    protected $user_id;
    protected $user_role;
    protected $user_name;

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');

        // Check if user is logged in
        if (!$this->session->userdata('logged_in')) {
            // Save current URL to redirect back after login
            $this->session->set_userdata('redirect_url', current_url());
            redirect('auth/login');
        }

        $this->user_id = $this->session->userdata('user_id');
        $this->user_role = $this->session->userdata('role');
        $this->user_name = $this->session->userdata('name');
    }
}

/**
 * Admin Controller - Ensures user is Admin
 */
class Admin_Controller extends Auth_Controller {
    public function __construct() {
        parent::__construct();
        if ($this->user_role !== 'admin') {
            show_error('You do not have permission to access this page.', 403, 'Forbidden');
        }
    }
}

/**
 * Manager Controller - Ensures user is Manager or Admin
 */
class Manager_Controller extends Auth_Controller {
    public function __construct() {
        parent::__construct();
        if (!in_array($this->user_role, ['admin', 'manager'])) {
            show_error('You do not have permission to access this page.', 403, 'Forbidden');
        }
    }
}

/**
 * Employee Controller - Ensures user is Employee, Manager, or Admin
 */
class Employee_Controller extends Auth_Controller {
    public function __construct() {
        parent::__construct();
        if (!in_array($this->user_role, ['admin', 'manager', 'employee'])) {
            show_error('You do not have permission to access this page.', 403, 'Forbidden');
        }
    }
}
