<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_DB_query_builder $db
 * @property CI_Loader $load
 */
class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function register($data) {
        return $this->db->insert('users', $data);
    }

    public function login($email, $password) {
        $this->db->where('email', $email);
        $query = $this->db->get('users');

        if ($query->num_rows() == 1) {
            $user = $query->row();
            
            // Check if account is active
            if (isset($user->status) && $user->status !== 'active') {
                return 'inactive';
            }

            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        return false;
    }
    
    public function email_exists($email) {
        $this->db->where('email', $email);
        $query = $this->db->get('users');
        return $query->num_rows() > 0;
    }

    /**
     * Get user by ID
     * @param int $id
     * @return stdClass|null
     */
    public function get_user_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('users');
        return $query->row();
    }

    public function update_user($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('users', $data);
    }

    public function check_password($id, $password) {
        $this->db->where('id', $id);
        $query = $this->db->get('users');
        if ($query->num_rows() == 1) {
            $user = $query->row();
            return password_verify($password, $user->password);
        }
        return false;
    }

    public function get_all_users($search = null) {
        if ($search) {
            $this->db->group_start();
            $this->db->like('name', $search);
            $this->db->or_like('email', $search);
            $this->db->group_end();
        }
        return $this->db->get('users')->result();
    }

    public function delete_user($id) {
        $this->db->where('id', $id);
        return $this->db->delete('users');
    }

    public function count_all_users() {
        return $this->db->count_all('users');
    }

    public function save_password_reset_token($email, $token) {
        $data = [
            'email' => $email,
            'token' => $token,
            'created_at' => date('Y-m-d H:i:s')
        ];
        return $this->db->insert('password_resets', $data);
    }
}
