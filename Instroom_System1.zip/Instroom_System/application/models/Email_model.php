<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->_check_schema();
    }

    private function _check_schema() {
        if (!$this->db->field_exists('message_id', 'email_conversations')) {
            $this->load->dbforge();
            $fields = array(
                'message_id' => array(
                    'type' => 'VARCHAR',
                    'constraint' => '255',
                    'null' => TRUE,
                    'after' => 'id'
                )
            );
            $this->dbforge->add_column('email_conversations', $fields);
        }
    }

    public function email_exists($message_id) {
        if (!$message_id) return false;
        $this->db->where('message_id', $message_id);
        $query = $this->db->get('email_conversations');
        return $query->num_rows() > 0;
    }

    public function save_email($data) {
        return $this->db->insert('email_conversations', $data);
    }

    public function get_emails_by_influencer($influencer_id) {
        $this->db->where('influencer_id', $influencer_id);
        $this->db->order_by('created_at', 'ASC');
        $query = $this->db->get('email_conversations');
        return $query->result_array();
    }

    public function get_unread_counts() {
        $this->db->select('influencer_id, COUNT(*) as unread_count');
        $this->db->where('direction', 'inbound');
        $this->db->where('is_read', 0);
        $this->db->group_by('influencer_id');
        $query = $this->db->get('email_conversations');
        
        $result = array();
        foreach ($query->result_array() as $row) {
            $result[$row['influencer_id']] = $row['unread_count'];
        }
        return $result;
    }

    public function mark_all_read($influencer_id) {
        $this->db->where('influencer_id', $influencer_id);
        $this->db->where('direction', 'inbound');
        $this->db->update('email_conversations', array('is_read' => 1));
    }

    public function mark_as_read($id) {
        $this->db->where('id', $id);
        return $this->db->update('email_conversations', array('is_read' => 1));
    }

    public function get_first_outbound_date($influencer_id) {
        $this->db->select('created_at');
        $this->db->where('influencer_id', $influencer_id);
        $this->db->where('direction', 'outbound');
        $this->db->order_by('created_at', 'ASC');
        $this->db->limit(1);
        $query = $this->db->get('email_conversations');
        
        if ($query->num_rows() > 0) {
            return $query->row()->created_at;
        }
        return null;
    }
}
