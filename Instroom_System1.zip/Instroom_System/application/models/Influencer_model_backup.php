<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_DB_query_builder $db
 * @property CI_Loader $load
 */
class Influencer_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_influencers($filters = array(), $limit = null, $offset = null) {
        $this->_apply_filters($filters);

        if ($limit !== null && $offset !== null) {
            $this->db->limit($limit, $offset);
        } elseif ($limit !== null) {
            $this->db->limit($limit);
        }

        $query = $this->db->get('influencers');
        return $query->result();
    }

    public function count_influencers($filters = array()) {
        $this->_apply_filters($filters);
        return $this->db->count_all_results('influencers');
    }

    private function _apply_filters($filters) {
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('username', $filters['search']);
            $this->db->or_like('full_name', $filters['search']);
            $this->db->or_like('platform', $filters['search']);
            $this->db->or_like('niche', $filters['search']);
            $this->db->or_like('notes', $filters['search']);
            $this->db->group_end();
        }

        if (!empty($filters['platform']) && $filters['platform'] != 'Platform') {
            $this->db->where('platform', $filters['platform']);
        }

        if (!empty($filters['niche']) && $filters['niche'] != 'Niche') {
            $this->db->where('niche', $filters['niche']);
        }

        if (!empty($filters['status']) && $filters['status'] != 'Status') {
            $this->db->where('status', $filters['status']);
        }
    }

    public function get_recent_influencers($limit = 5) {
        $this->db->order_by('created_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get('influencers');
        return $query->result();
    }

    public function get_all_influencers() {
        return $this->get_influencers();
    }

    public function search_influencers($search) {
        return $this->get_influencers(['search' => $search]);
    }

    public function get_influencer_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('influencers');
        return $query->row();
    }

    public function insert_influencer($data) {
        return $this->db->insert('influencers', $data);
    }

    public function insert_batch_influencers($data) {
        return $this->db->insert_batch('influencers', $data);
    }

    public function update_influencer($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('influencers', $data);
    }

    public function delete_influencer($id) {
        $this->db->where('id', $id);
        return $this->db->delete('influencers');
    }

    public function delete_influencers_by_ids($ids) {
        $this->db->where_in('id', $ids);
        return $this->db->delete('influencers');
    }

    public function update_influencers_by_ids($ids, $data) {
        $this->db->where_in('id', $ids);
        return $this->db->update('influencers', $data);
    }

    public function delete_all_influencers() {
        return $this->db->empty_table('influencers');
    }
}
