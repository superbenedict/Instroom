<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Campaign_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function create_campaign($data) {
        $this->db->insert('campaigns', $data);
        return $this->db->insert_id();
    }

    public function get_active_campaigns() {
        $this->db->where('status', 'active');
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get('campaigns')->result();
    }

    public function get_all_campaigns() {
        $this->db->order_by('created_at', 'DESC');
        return $this->db->get('campaigns')->result();
    }

    public function assign_employee($campaign_id, $user_id) {
        $data = [
            'campaign_id' => $campaign_id,
            'user_id' => $user_id
        ];
        return $this->db->insert('campaign_assignments', $data);
    }

    public function get_campaign_assignments($campaign_id) {
        $this->db->select('campaign_assignments.*, users.name as employee_name');
        $this->db->from('campaign_assignments');
        $this->db->join('users', 'users.id = campaign_assignments.user_id');
        $this->db->where('campaign_assignments.campaign_id', $campaign_id);
        return $this->db->get()->result();
    }
}
