<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property CI_DB_query_builder|CI_DB_mysqli_driver $db
 * @property CI_Loader $load
 */
class Influencer_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Helper to join tables
    private function _get_base_query() {
        $this->db->select('c.id as id, c.pipeline_status, c.campaign_type, c.product_name, c.order_number, c.product_cost, c.discount_code, c.affiliate_link, c.tracking_link, c.assessment, c.created_at as created_at, c.profile_id, c.account_id'); // Collaboration fields
        $this->db->select('p.full_name, p.first_name, p.last_name, p.email, p.contact_number, p.contact_info, p.location, p.shipping_address, p.notes'); // Profile fields
        $this->db->select('a.platform, a.username, a.profile_image, a.niche, a.followers, a.eng_rate, a.avg_video_views, a.gmv, a.est_post_rate, a.status'); // Account fields
        
        $this->db->from('collaborations c');
        $this->db->join('influencer_profiles p', 'c.profile_id = p.id', 'left');
        $this->db->join('influencer_accounts a', 'c.account_id = a.id', 'left');
    }

    public function get_influencers($filters = array(), $limit = null, $offset = null) {
        $this->_get_base_query();
        $this->_apply_filters($filters);

        if ($limit !== null && $offset !== null) {
            $this->db->limit($limit, $offset);
        } elseif ($limit !== null) {
            $this->db->limit($limit);
        }
        
        // Default sort
        $this->db->order_by('c.created_at', 'DESC');

        $query = $this->db->get();
        return $query->result();
    }

    public function count_influencers($filters = array()) {
        $this->db->from('collaborations c');
        $this->db->join('influencer_profiles p', 'c.profile_id = p.id', 'left');
        $this->db->join('influencer_accounts a', 'c.account_id = a.id', 'left');
        $this->_apply_filters($filters);
        return $this->db->count_all_results();
    }

    private function _apply_filters($filters) {
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('a.username', $filters['search']);
            $this->db->or_like('p.full_name', $filters['search']);
            $this->db->or_like('a.platform', $filters['search']);
            $this->db->or_like('a.niche', $filters['search']);
            $this->db->or_like('p.notes', $filters['search']);
            $this->db->group_end();
        }

        if (!empty($filters['platform']) && $filters['platform'] != 'Platform') {
            $this->db->where('a.platform', $filters['platform']);
        }

        if (!empty($filters['niche']) && $filters['niche'] != 'Niche') {
            $this->db->where('a.niche', $filters['niche']);
        }

        if (!empty($filters['status']) && $filters['status'] != 'Status') {
            $this->db->where('a.status', $filters['status']);
        }
    }

    public function get_influencers_by_ids($ids) {
        $this->_get_base_query();
        $this->db->where_in('c.id', $ids);
        $query = $this->db->get();
        return $query->result();
    }

    public function get_influencer($id) {
        $this->_get_base_query();
        $this->db->where('c.id', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_influencer_by_email($email) {
        $this->_get_base_query();
        $this->db->where('p.email', $email);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function get_influencers_by_pipeline_status($statuses) {
        $this->_get_base_query();
        $this->db->where_in('c.pipeline_status', $statuses);
        $this->db->order_by('c.created_at', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }



    /**
     * Add influencer from Discovery module
     * @param array $data
     * @return int Insert ID
     */
    public function add_discovery_influencer($data) {
        $this->db->insert('influencers', $data);
        return $this->db->insert_id();
    }
    
    public function get_influencer_growth_trend($days = 30) {
        $this->db->select('DATE(created_at) as date, COUNT(*) as count');
        $this->db->from('collaborations');
        $this->db->where('created_at >=', date('Y-m-d', strtotime("-$days days")));
        $this->db->group_by('DATE(created_at)');
        $this->db->order_by('date', 'ASC');
        $query = $this->db->get();
        
        $result = [];
        // Fill in missing dates with 0
        $period = new DatePeriod(
            new DateTime("-$days days"),
            new DateInterval('P1D'),
            new DateTime('+1 day')
        );
        
        $data_map = [];
        foreach ($query->result() as $row) {
            $data_map[$row->date] = $row->count;
        }

        foreach ($period as $key => $value) {
            $date = $value->format('Y-m-d');
            $result[$date] = isset($data_map[$date]) ? $data_map[$date] : 0;
        }
        
        return $result;
    }

    public function get_analytics_stats() {
        $stats = [
            'total_influencers' => 0,
            'platform_counts' => [],
            'total_likes' => 0,
            'total_comments' => 0,
            'total_views' => 0,
            'total_video_views' => 0,
            'cpm' => 0,
            'sales_quantity' => 0,
            'sales_amount' => 0,
            'product_expenditure' => 0,
            'web_clicks' => 0,
            'won_count' => 0,
            'posted_count' => 0,
            'outreach_count' => 0,
            'responded_count' => 0,
            'not_interested_count' => 0,
            'content_pending_count' => 0,
            'inactive_count' => 0,
            'content_saved_count' => 0,
            'pipeline_breakdown' => [],
            'location_breakdown' => [],
            'platform_details' => []
        ];

        // 1. Basic Aggregates
        $this->db->select('
            COUNT(*) as total_influencers,
            SUM(a.gmv) as sales_amount,
            SUM(c.product_cost) as product_expenditure,
            SUM(a.avg_video_views) as total_views,
            SUM(a.followers * (a.eng_rate / 100)) as total_engagements,
            AVG(a.eng_rate) as avg_eng_rate
        ');
        $this->db->from('collaborations c');
        $this->db->join('influencer_accounts a', 'c.account_id = a.id', 'left');
        $row = $this->db->get()->row();
        
        $stats['total_influencers'] = $row->total_influencers;
        $stats['sales_amount'] = $row->sales_amount;
        $stats['product_expenditure'] = $row->product_expenditure;
        $stats['total_views'] = $row->total_views;
        $stats['avg_eng_rate'] = $row->avg_eng_rate;
        
        // Estimates based on Engagement Rate
        $total_engagements = $row->total_engagements;
        $stats['total_likes'] = $total_engagements * 0.95; // Assume 95% of engagement is likes
        $stats['total_comments'] = $total_engagements * 0.05; // Assume 5% of engagement is comments
        
        // Calculate CPM (Cost Per Mille) = (Cost / Views) * 1000
        if ($stats['total_views'] > 0) {
            $stats['cpm'] = ($stats['product_expenditure'] / $stats['total_views']) * 1000;
        }

        $stats['outreach_count'] = $row->total_influencers; // Assuming all are outreach

        // 2. Pipeline Breakdown
        $this->db->select('pipeline_status, COUNT(*) as count');
        $this->db->group_by('pipeline_status');
        $query = $this->db->get('collaborations');
        foreach($query->result() as $row) {
            $stats['pipeline_breakdown'][$row->pipeline_status] = $row->count;
            
            // Map to specific counts
            $status = $row->pipeline_status;
            $won_stages = ['For Order Creation', 'In-Transit', 'Delivered', 'Posted', 'Campaign Completed'];
            $responded_stages = ['Replied', 'In - Progress', 'For Order Creation', 'In-Transit', 'Delivered', 'Posted', 'Campaign Completed', 'Not Interested'];

            if (in_array($status, $won_stages)) $stats['won_count'] += $row->count;
            if (in_array($status, $responded_stages)) $stats['responded_count'] += $row->count;
            if ($status == 'Posted' || $status == 'Campaign Completed') $stats['posted_count'] += $row->count;
            if ($status == 'Not Interested') $stats['not_interested_count'] += $row->count;
            if ($status == 'Content Pending' || $status == 'In-Transit' || $status == 'Delivered') $stats['content_pending_count'] += $row->count;
        }

        // 3. Platform Breakdown
        $this->db->select('platform, COUNT(*) as count');
        $this->db->group_by('platform');
        $query = $this->db->get('influencer_accounts');
        foreach($query->result() as $row) {
            $stats['platform_counts'][$row->platform] = $row->count;
        }

        // 4. Location Breakdown
        $this->db->select('location, COUNT(*) as count');
        $this->db->group_by('location');
        $query = $this->db->get('influencer_profiles');
        foreach($query->result() as $row) {
            $stats['location_breakdown'][$row->location] = $row->count;
        }

        // 5. Detailed Platform Stats
        $this->db->select('a.platform, c.pipeline_status, COUNT(*) as count, SUM(a.gmv) as sales_amount');
        $this->db->from('collaborations c');
        $this->db->join('influencer_accounts a', 'c.account_id = a.id', 'left');
        $this->db->group_by(['a.platform', 'c.pipeline_status']);
        $query = $this->db->get();
        
        $platforms = ['Facebook', 'Instagram', 'TikTok', 'YouTube'];
        foreach ($platforms as $p) {
            $stats['platform_details'][$p] = [
                'total' => 0, 'outreach' => 0, 'responded' => 0, 'not_interested' => 0, 
                'content_pending' => 0, 'posted' => 0, 'web_clicks' => 0,
                'sales_quantity' => 0, 'sales_amount' => 0, 'cvr' => 0, 'won' => 0
            ];
        }

        foreach($query->result() as $row) {
            $p = $row->platform;
            $s = $row->pipeline_status;
            $c = $row->count;
            $gmv = $row->sales_amount;

            if (!in_array($p, $platforms)) continue;

            $stats['platform_details'][$p]['total'] += $c;
            $stats['platform_details'][$p]['outreach'] += $c;
            $stats['platform_details'][$p]['sales_amount'] += $gmv;
            
            $won_stages = ['For Order Creation', 'In-Transit', 'Delivered', 'Posted', 'Campaign Completed'];
            $responded_stages = ['Replied', 'In - Progress', 'For Order Creation', 'In-Transit', 'Delivered', 'Posted', 'Campaign Completed', 'Not Interested'];

            if (in_array($s, $won_stages)) $stats['platform_details'][$p]['won'] += $c;
            if (in_array($s, $responded_stages)) $stats['platform_details'][$p]['responded'] += $c;
            if ($s == 'Posted' || $s == 'Campaign Completed') $stats['platform_details'][$p]['posted'] += $c;
            if ($s == 'Not Interested') $stats['platform_details'][$p]['not_interested'] += $c;
            if ($s == 'Content Pending' || $s == 'In-Transit' || $s == 'Delivered') $stats['platform_details'][$p]['content_pending'] += $c;
        }

        return $stats;
    }

    public function get_recent_influencers($limit = 5) {
        $this->_get_base_query();
        $this->db->order_by('c.created_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }

    public function get_all_influencers() {
        return $this->get_influencers();
    }

    public function search_influencers($search) {
        return $this->get_influencers(['search' => $search]);
    }

    public function get_influencer_by_id($id) {
        $this->_get_base_query();
        $this->db->where('c.id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    public function insert_influencer($data) {
        $this->db->trans_start();

        // 1. Profile Data
        $profile_data = array(
            'full_name' => isset($data['full_name']) ? $data['full_name'] : '',
            'first_name' => isset($data['first_name']) ? $data['first_name'] : '',
            'last_name' => isset($data['last_name']) ? $data['last_name'] : '',
            'email' => isset($data['email']) ? $data['email'] : '',
            'contact_number' => isset($data['contact_number']) ? $data['contact_number'] : '',
            'contact_info' => isset($data['contact_info']) ? $data['contact_info'] : '',
            'location' => isset($data['location']) ? $data['location'] : '',
            'shipping_address' => isset($data['shipping_address']) ? $data['shipping_address'] : '',
            'notes' => isset($data['notes']) ? $data['notes'] : '',
        );

        // Check if profile exists by full_name or email to reuse
        $profile_id = 0;
        if (!empty($profile_data['full_name'])) {
            $this->db->where('full_name', $profile_data['full_name']);
            $q = $this->db->get('influencer_profiles');
            if ($q->num_rows() > 0) {
                $profile_id = $q->row()->id;
                // Optionally update profile? Let's assume yes if data provided
                $this->db->where('id', $profile_id);
                $this->db->update('influencer_profiles', $profile_data);
            }
        }
        
        if ($profile_id == 0) {
            if (!$this->db->insert('influencer_profiles', $profile_data)) {
                log_message('error', 'Insert Profile Failed: ' . json_encode($this->db->error()));
            }
            $profile_id = $this->db->insert_id();
        }

        // 2. Account Data
        $account_id = 0;
        if (isset($data['username']) || isset($data['platform'])) {
            $account_data = array(
                'profile_id' => $profile_id,
                'platform' => isset($data['platform']) ? $data['platform'] : '',
                'username' => isset($data['username']) ? $data['username'] : '',
                'profile_image' => isset($data['profile_image']) ? $data['profile_image'] : '',
                'niche' => isset($data['niche']) ? $data['niche'] : '',
                'followers' => isset($data['followers']) ? $data['followers'] : 0,
                'eng_rate' => isset($data['eng_rate']) ? $data['eng_rate'] : 0,
                'avg_video_views' => isset($data['avg_video_views']) ? $data['avg_video_views'] : 0,
                'gmv' => isset($data['gmv']) ? $data['gmv'] : 0,
                'est_post_rate' => isset($data['est_post_rate']) ? $data['est_post_rate'] : 0,
                'status' => isset($data['status']) ? $data['status'] : 'Active',
            );

            // Check if account exists for this profile
            if (!empty($account_data['username'])) {
                $this->db->where('profile_id', $profile_id);
                $this->db->where('platform', $account_data['platform']);
                $this->db->where('username', $account_data['username']);
                $q = $this->db->get('influencer_accounts');
                if ($q->num_rows() > 0) {
                    $account_id = $q->row()->id;
                    $this->db->where('id', $account_id);
                    $this->db->update('influencer_accounts', $account_data);
                } else {
                    // Try to find by username/platform globally (handle existing account with different profile)
                    $this->db->where('platform', $account_data['platform']);
                    $this->db->where('username', $account_data['username']);
                    $q2 = $this->db->get('influencer_accounts');
                    
                    if ($q2->num_rows() > 0) {
                        $account_id = $q2->row()->id;
                        // Update account with new data AND new profile_id
                        $this->db->where('id', $account_id);
                        $this->db->update('influencer_accounts', $account_data);
                    } else {
                        if (!$this->db->insert('influencer_accounts', $account_data)) {
                            log_message('error', 'Insert Account Failed: ' . json_encode($this->db->error()));
                        }
                        $account_id = $this->db->insert_id();
                    }
                }
            } else {
                 // Insert even without username if platform provided? 
                 // If no username, maybe just skip account creation or create placeholder?
                 // Let's create it if platform is set
                 if (!empty($account_data['platform'])) {
                    $this->db->insert('influencer_accounts', $account_data);
                    $account_id = $this->db->insert_id();
                 }
            }
        }

        // 3. Collaboration Data
        $collab_data = array(
            'profile_id' => $profile_id,
            'account_id' => ($account_id > 0) ? $account_id : NULL,
            'pipeline_status' => isset($data['pipeline_status']) ? $data['pipeline_status'] : 'For Outreach',
            'campaign_type' => isset($data['campaign_type']) ? $data['campaign_type'] : '',
            'product_name' => isset($data['product_name']) ? $data['product_name'] : '',
            'order_number' => isset($data['order_number']) ? $data['order_number'] : '',
            'product_cost' => isset($data['product_cost']) ? $data['product_cost'] : NULL,
            'discount_code' => isset($data['discount_code']) ? $data['discount_code'] : '',
            'affiliate_link' => isset($data['affiliate_link']) ? $data['affiliate_link'] : '',
            'tracking_link' => isset($data['tracking_link']) ? $data['tracking_link'] : '',
            'assessment' => isset($data['assessment']) ? $data['assessment'] : '',
            'created_by' => isset($data['created_by']) ? $data['created_by'] : 1, // Default to Admin (1)
            'created_at' => isset($data['created_at']) ? $data['created_at'] : date('Y-m-d H:i:s')
        );

        if (!$this->db->insert('collaborations', $collab_data)) {
             log_message('error', 'Insert Collaboration Failed: ' . json_encode($this->db->error()));
             return false;
        }
        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();
        return $insert_id;
    }

    public function insert_batch_influencers($data) {
        // Batch insert is tricky with 3 tables. Better to loop insert_influencer
        $this->db->trans_start();
        foreach ($data as $row) {
            $this->insert_influencer($row);
        }
        $this->db->trans_complete();
        return TRUE;
    }

    public function update_influencer($id, $data) {
        // $id is collaboration id
        $collab = $this->get_influencer_by_id($id);
        if (!$collab) return false;

        $this->db->trans_start();

        // Split data
        $profile_cols = ['full_name', 'first_name', 'last_name', 'email', 'contact_number', 'contact_info', 'location', 'shipping_address', 'notes'];
        $account_cols = ['platform', 'username', 'profile_image', 'niche', 'followers', 'eng_rate', 'avg_video_views', 'gmv', 'est_post_rate', 'status'];
        $collab_cols = ['pipeline_status', 'campaign_type', 'product_name', 'order_number', 'product_cost', 'discount_code', 'affiliate_link', 'tracking_link', 'assessment'];

        $profile_data = [];
        $account_data = [];
        $collab_data = [];

        foreach ($data as $key => $value) {
            if (in_array($key, $profile_cols)) $profile_data[$key] = $value;
            if (in_array($key, $account_cols)) $account_data[$key] = $value;
            if (in_array($key, $collab_cols)) $collab_data[$key] = $value;
        }

        if (!empty($profile_data) && $collab->profile_id) {
            $this->db->where('id', $collab->profile_id);
            $this->db->update('influencer_profiles', $profile_data);
        }

        if (!empty($account_data)) {
            if ($collab->account_id) {
                $this->db->where('id', $collab->account_id);
                $this->db->update('influencer_accounts', $account_data);
            } else {
                // If account didn't exist but we are adding account info, we might need to create one?
                // For now, ignore or require insert logic.
                // Or try to create if username is present
                if (!empty($account_data['username']) && $collab->profile_id) {
                     $account_data['profile_id'] = $collab->profile_id;
                     $this->db->insert('influencer_accounts', $account_data);
                     $new_acc_id = $this->db->insert_id();
                     // Link back to collab
                     $this->db->where('id', $id);
                     $this->db->update('collaborations', ['account_id' => $new_acc_id]);
                }
            }
        }

        if (!empty($collab_data)) {
            $this->db->where('id', $id);
            $this->db->update('collaborations', $collab_data);
        }

        $this->db->trans_complete();
        return TRUE;
    }

    public function delete_influencer($id) {
        // Delete collaboration.
        // Optional: Delete profile/account if no other collabs exist?
        // For now, just delete the collab row to maintain history/safety.
        $this->db->where('id', $id);
        return $this->db->delete('collaborations');
    }

    public function delete_influencers_by_ids($ids) {
        $this->db->where_in('id', $ids);
        return $this->db->delete('collaborations');
    }

    public function update_influencers_by_ids($ids, $data) {
        // Only updates collaboration table safely for batch
        // If updating profile/account fields in batch, it's risky as IDs refer to collabs
        // Assuming batch updates are mostly for pipeline_status (collab field)
        $this->db->where_in('id', $ids);
        return $this->db->update('collaborations', $data);
    }

    public function delete_all_influencers() {
        return $this->db->empty_table('collaborations');
    }
}
