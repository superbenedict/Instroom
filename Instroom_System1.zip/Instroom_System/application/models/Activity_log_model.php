<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Activity_log_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Log an activity
    public function log_activity($user_id, $user_name, $action, $details = null) {
        $data = array(
            'user_id' => $user_id,
            'user_name' => $user_name,
            'action' => $action,
            'details' => $details,
            'ip_address' => $this->input->ip_address(),
            'created_at' => date('Y-m-d H:i:s')
        );

        return $this->db->insert('activity_logs', $data);
    }

    // Get all logs (for admin view)
    public function get_logs($limit = 100, $offset = 0) {
        $this->db->order_by('created_at', 'DESC');
        $query = $this->db->get('activity_logs', $limit, $offset);
        return $query->result_array();
    }

    // Get total logs count (for pagination)
    public function get_total_logs() {
        return $this->db->count_all('activity_logs');
    }
    
    // Get recent logs (for dashboard widgets)
    public function get_recent_logs($limit = 5) {
        $this->db->order_by('created_at', 'DESC');
        $query = $this->db->get('activity_logs', $limit);
        return $query->result_array();
    }
}
