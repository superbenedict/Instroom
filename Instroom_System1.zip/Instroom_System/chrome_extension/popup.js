document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const addBtn = document.getElementById('addBtn');
  const statusDiv = document.getElementById('status');
  const fullNameEl = document.getElementById('full-name');
  const handleEl = document.getElementById('username-handle');
  const bioEl = document.getElementById('bio');
  const avatarEl = document.getElementById('avatar');
  const avatarSkeleton = document.getElementById('avatar-skeleton');
  const followersEl = document.getElementById('followers-count');
  const engRateEl = document.getElementById('eng-rate');
  const profileCard = document.querySelector('.profile-card');

  // Helper: Reset UI state
  const resetUI = (message) => {
    fullNameEl.textContent = message;
    handleEl.style.display = 'none';
    document.querySelector('.stats-grid').style.display = 'none';
    document.querySelector('.bio-section').style.display = 'none';
    avatarSkeleton.style.display = 'none';
    addBtn.disabled = true;
  };

  // Get current tab
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url.includes('instagram.com/')) {
    resetUI('Not an Instagram Profile');
    return;
  }

  // Parse Username from URL
  const urlParts = tab.url.split('/');
  const cleanParts = urlParts.filter(p => p.length > 0);
  let username = '';
  
  const domainIndex = cleanParts.findIndex(p => p.includes('instagram.com'));
  if (domainIndex !== -1 && cleanParts[domainIndex + 1]) {
    username = cleanParts[domainIndex + 1];
  }

  if (!username || ['reels', 'explore', 'p', 'stories', 'direct'].includes(username)) {
    resetUI('Please visit a Profile Page');
    return;
  }

  // Set initial UI with Username
  handleEl.textContent = '@' + username;
  fullNameEl.textContent = username; // Temporary until we scrape title
  
  let followersCount = 0;
  let fullName = username;
  let fullBio = '';

  // Try to execute script to get more info (Meta tags)
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scrapeProfileData,
    });

    if (results && results[0] && results[0].result) {
      const data = results[0].result;
      
      // 1. Handle Avatar
      if (data.image) {
        avatarEl.src = data.image;
        avatarEl.onload = () => {
          avatarEl.style.display = 'block';
          avatarSkeleton.style.display = 'none';
        };
      } else {
        avatarSkeleton.style.display = 'block';
      }

      // 2. Handle Name (Title often format: "Name (@username) ...")
      if (data.title) {
        // Extract name before (@username)
        const nameMatch = data.title.split('(@')[0];
        if (nameMatch) {
          fullName = nameMatch.trim();
          fullNameEl.textContent = fullName;
        }
      }

      // 3. Handle Followers
      if (data.followers) {
          followersCount = data.followers;
          followersEl.textContent = Intl.NumberFormat('en-US', { 
            notation: "compact", 
            maximumFractionDigits: 1 
          }).format(followersCount);
          
          if (data.bio) {
             fullBio = data.bio;
             bioEl.textContent = data.bio.substring(0, 150) + (data.bio.length > 150 ? '...' : '');
          }
      } else if (data.description) {
        const parts = data.description.split('Followers');
        if (parts.length > 0) {
          let numStr = parts[0].trim().replace(/,/g, '');
          let multiplier = 1;
          
          if (numStr.toLowerCase().endsWith('k')) {
            multiplier = 1000;
            numStr = numStr.slice(0, -1);
          } else if (numStr.toLowerCase().endsWith('m')) {
            multiplier = 1000000;
            numStr = numStr.slice(0, -1);
          } else if (numStr.toLowerCase().endsWith('b')) {
            multiplier = 1000000000;
            numStr = numStr.slice(0, -1);
          }
          
          const parsed = parseFloat(numStr);
          if (!isNaN(parsed)) {
            followersCount = parsed * multiplier;
            // Format for display (e.g. 1.5M)
            followersEl.textContent = Intl.NumberFormat('en-US', { 
              notation: "compact", 
              maximumFractionDigits: 1 
            }).format(followersCount);
          }
        }
        
        // Bio Text
        bioEl.textContent = data.description.substring(0, 150) + '...';
      }
      
      // Enable Button
      addBtn.disabled = false;
    }
  } catch (e) {
    console.error('Script injection failed', e);
    // Even if script fails, allow adding with basic info
    addBtn.disabled = false;
    avatarSkeleton.style.display = 'none';
  }

  // Button Click Handler
  addBtn.addEventListener('click', async () => {
    addBtn.disabled = true;
    const originalBtnContent = addBtn.innerHTML;
    addBtn.textContent = 'Adding...';
    statusDiv.style.display = 'none';
    statusDiv.className = 'status';

    const payload = {
      platform: 'instagram',
      username: username,
      full_name: fullName,
      profile_url: tab.url,
      bio: fullBio || bioEl.textContent,
      followers: followersCount,
      eng_rate: 'N/A'
    };

    try {
      // Send to Instroom Localhost API
      const response = await fetch('http://localhost/Instroom_System/index.php/api/add_influencer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
         throw new Error(`Server Error: ${response.status}`);
      }

      const text = await response.text();
      let result;
      try {
          result = JSON.parse(text);
      } catch (e) {
          console.error("Failed to parse JSON:", text);
          throw new Error("Invalid Response from Server");
      }

      if (result.status === 'success') {
        statusDiv.textContent = 'Successfully Added!';
        statusDiv.classList.add('success');
        statusDiv.style.display = 'block';
        
        addBtn.innerHTML = `
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Saved
        `;
        addBtn.style.background = '#10B981'; // Green
      } else {
        throw new Error(result.message || 'Error adding influencer');
      }
    } catch (error) {
      console.error(error);
      statusDiv.textContent = error.message;
      statusDiv.classList.add('error');
      statusDiv.style.display = 'block';
      
      // Reset button
      addBtn.disabled = false;
      addBtn.innerHTML = originalBtnContent;
    }
  });
});

// Content Script Function (runs in the page context)
async function scrapeProfileData() {
  const result = {
    image: '',
    title: '',
    description: '',
    followers: 0,
    bio: '',
    debug_log: [] 
  };
  
  const log = (msg) => result.debug_log.push(msg);

  try {
    const urlParts = window.location.pathname.split('/').filter(p => p);
    const username = urlParts[0];
    
    // STRATEGY 1: INTERNAL API (The "Hidden" API)
    try {
        log('Attempting Internal API...');
        const apiUrl = `https://www.instagram.com/api/v1/users/web_profile_info/?username=${username}`;
        const response = await fetch(apiUrl, {
            headers: {
                'x-ig-app-id': '936619500551711',
            }
        });
        
        if (response.ok) {
            const json = await response.json();
            const user = json.data.user;
            
            if (user) {
                log('API Success');
                result.image = user.profile_pic_url_hd || user.profile_pic_url;
                result.title = user.full_name;
                result.description = (user.edge_followed_by.count || 0) + ' Followers';
                result.followers = user.edge_followed_by.count || 0;
                result.bio = user.biography;
                return result; 
            }
        } else {
            log('API Failed: ' + response.status);
        }
    } catch (e) {
        log('API Error: ' + e.message);
    }

    // STRATEGY 2: JSON-LD (Structured Data)
    try {
        const scripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (let script of scripts) {
            try {
                const json = JSON.parse(script.innerText);
                if (json && (json['@type'] === 'Person' || json['@type'] === 'Organization')) {
                    log('Found JSON-LD');
                    if (json.image) result.image = json.image;
                    if (json.name) result.title = json.name;
                    if (json.description) {
                        result.bio = json.description; // JSON-LD description is often the bio
                    }
                    
                    if (json.interactionStatistic) {
                        const interaction = Array.isArray(json.interactionStatistic) 
                            ? json.interactionStatistic.find(i => i.interactionType === 'http://schema.org/FollowAction')
                            : json.interactionStatistic;
                            
                        if (interaction && interaction.userInteractionCount) {
                            result.followers = parseInt(interaction.userInteractionCount);
                            result.description = result.followers.toLocaleString() + ' Followers';
                        }
                    }
                    break;
                }
            } catch(e) {}
        }
    } catch (e) {
        log('JSON-LD Error: ' + e.message);
    }

    // STRATEGY 3: VISIBLE DOM & META TAGS (Combined & Enhanced)
    try {
        // A. Meta Tags (Very Reliable for Stats)
        const metas = document.getElementsByTagName('meta');
        let metaDesc = '';
        let metaTitle = '';
        
        for (let i = 0; i < metas.length; i++) {
            const p = metas[i].getAttribute('property');
            const n = metas[i].getAttribute('name');
            const c = metas[i].getAttribute('content');
            
            if (p === 'og:description' || n === 'description') metaDesc = c;
            if (p === 'og:title') metaTitle = c;
            if (p === 'og:image' && !result.image) result.image = c;
        }

        // Parse Title (Name)
        if (metaTitle && !result.title) {
            // "Name (@username) • Instagram..."
            const parts = metaTitle.split('(@');
            if (parts.length > 1) {
                result.title = parts[0].trim();
            } else {
                // Try split by " on Instagram"
                result.title = metaTitle.split(' on Instagram')[0].trim();
            }
        }

        // Parse Description (Followers)
        // Format: "100M Followers, 10 Following, 500 Posts..."
        if (metaDesc && !result.followers) {
            // Look for number at start
            const match = metaDesc.match(/^([0-9.,]+[KkMmBb]?)\s+Followers/i);
            if (match) {
                let numStr = match[1].replace(/,/g, '');
                let multiplier = 1;
                if (numStr.match(/[Kk]$/)) { multiplier = 1000; numStr = numStr.replace(/[Kk]$/, ''); }
                if (numStr.match(/[Mm]$/)) { multiplier = 1000000; numStr = numStr.replace(/[Mm]$/, ''); }
                if (numStr.match(/[Bb]$/)) { multiplier = 1000000000; numStr = numStr.replace(/[Bb]$/, ''); }
                
                result.followers = parseFloat(numStr) * multiplier;
                result.description = match[0];
                log('Found Meta Followers: ' + result.followers);
            }
        }

        // B. DOM Header (Bio & Fallbacks)
        const header = document.querySelector('header');
        if (header) {
            // Bio - usually the only element with "white-space: pre-wrap" or specific class
            // We can look for the element that contains the text from JSON-LD bio if we have it, 
            // OR just look for the longest text block in the header that isn't name/stats.
            
            // Try to find bio by class (risky, changes) or structure
            // Structure: Header -> Section -> Div -> Div -> Span/Div (Bio)
            // Text often has emojis.
            
            if (!result.bio) {
                // Try to find a div/span with significant text that is NOT the title
                const headerText = header.innerText;
                // This is hard to do generically without class names.
                // Let's rely on JSON-LD for bio as primary fallback.
            }

            // Image Fallback
            if (!result.image) {
                const imgs = header.querySelectorAll('img');
                if (imgs.length > 0) result.image = imgs[0].src;
            }
        }
        
    } catch (e) {
        log('DOM/Meta Error: ' + e.message);
    }

  } catch (e) {
    log('General Error: ' + e.message);
  }

  return result;
}
