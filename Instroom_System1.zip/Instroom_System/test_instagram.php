<?php
// Test Script for Instagram Graph API Integration
// Run via: php test_instagram.php

echo "========================================\n";
echo "Instagram Graph API Connection Test\n";
echo "========================================\n";

// 1. Load Environment Variables
$env_path = __DIR__ . '/.env';
if (!file_exists($env_path)) {
    die("Error: .env file not found at $env_path\n");
}

$lines = file($env_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
foreach ($lines as $line) {
    if (strpos(trim($line), '#') === 0) continue;
    $parts = explode('=', $line, 2);
    if (count($parts) === 2) {
        putenv(trim($parts[0]) . '=' . trim($parts[1]));
    }
}

$token = getenv('FACEBOOK_ACCESS_TOKEN');
$ig_business_id = getenv('IG_BUSINESS_ACCOUNT_ID');

if (!$token) {
    die("Error: FACEBOOK_ACCESS_TOKEN not found in .env\n");
}

echo "Token loaded: " . substr($token, 0, 10) . "...\n";

// 2. Verify Token & Find IG Business ID
echo "\n[Step 1] Verifying Token & Searching for Linked Instagram Accounts...\n";

$url = "https://graph.facebook.com/v18.0/me/accounts?fields=name,instagram_business_account&access_token=" . $token;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['error'])) {
    echo "API Error: " . $data['error']['message'] . "\n";
    exit;
}

$found_ig_id = null;

if (isset($data['data'])) {
    echo "Found " . count($data['data']) . " Facebook Pages:\n";
    foreach ($data['data'] as $page) {
        echo "- Page: " . $page['name'] . " (ID: " . $page['id'] . ")\n";
        if (isset($page['instagram_business_account'])) {
            $found_ig_id = $page['instagram_business_account']['id'];
            echo "  -> LINKED INSTAGRAM ID: " . $found_ig_id . " [SUCCESS]\n";
        } else {
            echo "  -> No linked Instagram Business Account.\n";
        }
    }
} else {
    echo "No pages found.\n";
}

// 3. Check/Verify Configured ID
echo "\n[Step 2] Verifying Configured IG Business ID...\n";
if ($ig_business_id && $ig_business_id !== 'YOUR_IG_BUSINESS_ID') {
    echo "Configured ID in .env: $ig_business_id\n";
    if ($found_ig_id && $found_ig_id != $ig_business_id) {
        echo "WARNING: Configured ID does not match the one found via API ($found_ig_id).\n";
    }
    $target_id = $ig_business_id;
} elseif ($found_ig_id) {
    echo "No valid ID in .env, using found ID: $found_ig_id\n";
    $target_id = $found_ig_id;
    echo "ACTION REQUIRED: Please update IG_BUSINESS_ACCOUNT_ID in .env with this ID.\n";
} else {
    die("Error: No Instagram Business Account ID found. Please link an Instagram Professional account to your Facebook Page.\n");
}

// 4. Test Business Discovery (Search Simulation)
echo "\n[Step 3] Testing Business Discovery (Profile Lookup)...\n";
$target_username = 'nike'; // Test handle
echo "Target: @$target_username\n";

$fields = "business_discovery.username($target_username){username,website,name,ig_id,id,profile_picture_url,biography,follows_count,followers_count,media_count}";
$url = "https://graph.facebook.com/v18.0/{$target_id}?fields=" . urlencode($fields) . "&access_token=" . $token;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['error'])) {
    echo "Discovery Error: " . $data['error']['message'] . "\n";
} elseif (isset($data['business_discovery'])) {
    $u = $data['business_discovery'];
    echo "SUCCESS! Data Retrieved:\n";
    echo "- Username: " . $u['username'] . "\n";
    echo "- Name: " . $u['name'] . "\n";
    echo "- Followers: " . $u['followers_count'] . "\n";
    echo "- Bio: " . substr(str_replace("\n", " ", $u['biography']), 0, 50) . "...\n";
} else {
    echo "Unknown response format.\n";
    print_r($data);
}

echo "\nDone.\n";
