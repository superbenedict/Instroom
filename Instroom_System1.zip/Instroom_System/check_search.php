<?php
// Test script for SociaVault Search Variants
// Run this via CLI: C:\xampp\php\php.exe check_search.php

$sociavault_key = 'sk_live_fb241b9f2b89a689abd47a7ede26766b';
$host = 'api.sociavault.com';
$keyword = 'nike';

$endpoints = [
    "/v1/scrape/instagram/search?query=" . urlencode($keyword),
    "/v1/scrape/instagram/search?q=" . urlencode($keyword),
    "/v1/scrape/instagram/search_users?query=" . urlencode($keyword),
    "/v1/scrape/instagram/users/search?query=" . urlencode($keyword),
    "/v1/scrape/instagram/search?handle=" . urlencode($keyword), // Just in case
];

echo "Testing Search Variants...\n";

foreach ($endpoints as $path) {
    $url = "https://" . $host . $path;
    echo "Testing: $url ... ";

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10, // Short timeout for check
        CURLOPT_HTTPHEADER => [
            "X-API-Key: " . $sociavault_key,
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        ],
        CURLOPT_SSL_VERIFYPEER => false
    ]);

    $response = curl_exec($curl);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    echo "HTTP $http_code\n";
    if ($http_code == 200 || $http_code == 400) {
        echo "Response: " . substr($response, 0, 200) . "\n";
    }
}
